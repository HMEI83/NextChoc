<?php

namespace app\common\model;

use think\Model;

class FailWebhook Extends Model
{
    protected $name = 'fail_webhook';

    protected $autoWriteTimestamp = 'int';

    protected $createTime = 'createtime';

    protected $updateTime = 'updatetime';

    /**
     * 记录日志
     */
    public static function record($remark = "", $paymentType = "", $isSuccess = 0, $eventType = "")
    {
        self::create([
            "request"   => json_encode(request()->param()),
            "remark"    => $remark,
            "payment_type" => $paymentType,
            "event_type"   => $eventType,
            "is_success"   => $isSuccess,
            "createtime"=> request()->time(),
            "updatetime"=> request()->time(),
        ]);
    }
}