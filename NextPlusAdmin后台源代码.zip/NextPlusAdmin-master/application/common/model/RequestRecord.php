<?php

namespace app\common\model;

use think\Model;

/**
 * 请求记录
 */
class RequestRecord Extends Model
{
    // 表名
    protected $name = 'request_record';

    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    protected $createTime = 'createtime';

    protected $updateTime = 'updatetime';

    /**
     * 记录日志
     */
    public static function record()
    {
        self::create([
            'url'       => request()->url(),
            'ip'        => request()->ip(),
            "path"      => request()->path(),
            "headers"   => json_encode(request()->header()),
            "query"     => json_encode(request()->get()),
            "body"     => json_encode(request()->post()),
            "longitude" => 0,
            "latitude"  => 0,
            'uid'       => 0,
            "createtime"=> request()->time(),
            "updatetime"=> request()->time(),
        ]);
    }
}