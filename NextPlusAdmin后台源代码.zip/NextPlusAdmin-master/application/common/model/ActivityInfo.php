<?php

namespace app\common\model;

use think\Model;

class ActivityInfo extends Model
{
    protected $name = 'activity_info';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
}