<?php

namespace app\common\model;

use think\Model;

class GoodsComment extends Model
{
    protected $name = 'goods_comment';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';

    // 追加属性
    protected $append = [
        "create_time_format",
        "update_time_format",
    ];

    public function getCreateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['createtime'] ?? null);

        return datetime($value);
    }

    public function getUpdateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['updatetime'] ?? null);

        return datetime($value);
    }
}