<?php

namespace app\common\enum\balance;

class BalanceChangeTypeEnum
{
    const ADD = "1";
    const REDUCE = "2";

    /**
     * 获取订单状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getBalanceChangeTypeMean($value):string
    {
        switch ($value) {
            case self::ADD:
                return 1;

            case self::REDUCE:
                return 2;

            default:
                return "";
        }
    }
}