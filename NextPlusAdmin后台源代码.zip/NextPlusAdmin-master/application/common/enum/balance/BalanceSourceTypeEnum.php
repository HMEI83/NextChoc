<?php

namespace app\common\enum\balance;

class BalanceSourceTypeEnum
{
    const USER_PAY = "user_pay";
    const WITHDRAW = "withdraw";
    const COMMISSION = "commission";

    /**
     * 获取订单状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getBalanceSourceTypeMean($value):string
    {
        switch ($value) {
            case self::USER_PAY:
                return "user_pay";

            case self::WITHDRAW:
                return "withdraw";

            case self::COMMISSION:
                return "commission";

            default:
                return "";
        }
    }
}