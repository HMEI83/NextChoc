<?php

namespace app\common\enum\order;

/**
 * 订单退款状态
 *
 * Class OrderRefundStatusEnum
 *
 * @package app\common\enum\order
 */
class OrderRefundStatusEnum
{
    const NONE = 0;
    const WAIT = 1;
    const SUCCESS = 2;
    const FAILD = 3;

    /**
     * 获取订单支付状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getOrderRefundStatusMean($value):string
    {
        switch ($value) {
            case self::NONE:
                return "无需退款";

            case self::WAIT:
                return "等待退款";

            case self::SUCCESS:
                return "已退款";

            case self::FAILD:
                return "退款失败";

            default:
                return "";
        }
    }
}