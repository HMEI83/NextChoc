<?php

namespace app\common\enum\order;

/**
 * 订单退款状态
 *
 * Class OrderRefundStatusEnum
 *
 * @package app\common\enum\order
 */
class OrderRefundAuditStatusEnum
{
    const WAIT = 0;
    const SUCCESS = 1;
    const FAILD = 2;
    const NO_AUDIT = 3;

    /**
     * 获取订单支付状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getOrderRefundAuditStatusMean($value):string
    {
        switch ($value) {
            case self::WAIT:
                return "等待审核";

            case self::SUCCESS:
                return "审核通过";

            case self::FAILD:
                return "审核驳回";

            case self::NO_AUDIT:
                return "无需审核";

            default:
                return "";
        }
    }
}