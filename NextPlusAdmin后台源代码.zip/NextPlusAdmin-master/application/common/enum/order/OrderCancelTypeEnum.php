<?php

namespace app\common\enum\order;

class OrderCancelTypeEnum
{
    // 订单取消方式:unpaid_cancel=未支付取消,apply_refund=申請退款,platform_cancel=平台取消,user_cancel=用户取消
    const UNPAID_CANCEL = "unpaid_cancel";
    const USER_CANCEL = "user_cancel";
    const APPLY_REFUND = "apply_refund";
    const PLATFORM_CANCEL = "platform_cancel";

    /**
     * 获取订单状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getOrderCancelTypeMean($value):string
    {
        switch ($value) {
            case self::USER_CANCEL:
                return "用户取消";

            case self::UNPAID_CANCEL:
                return "未支付取消";

            case self::APPLY_REFUND:
                return "申請退款";

            case self::PLATFORM_CANCEL:
                return "平台取消";

            default:
                return "";
        }
    }
}