<?php

namespace app\common\enum\order;

/**
 * 订单状态
 *
 * Class OrderStatusEnum
 *
 * @package app\common\enum\order
 */
class OrderStatusEnum
{
    const WAIT_USER_PAYMENT = 0;
    const USER_HAS_PAID = 1;
    const ORDER_CANCEL = 2;
    const SUCCESS_CHECK = 3;
    const SUCCESS_PACK = 4;

    /**
     * 获取订单状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getOrderPaymentStatusMean($value):string
    {
        switch ($value) {
            case self::WAIT_USER_PAYMENT:
                // return "等待用户付款";
                return "System is processing";

            case self::USER_HAS_PAID:
                return "Waiting for bag";

            case self::ORDER_CANCEL:
                return "Cancel the order";

            case self::SUCCESS_PACK:
                return "Ready";

            case self::SUCCESS_CHECK:
                return "Completed";

            default:
                return "";
        }
    }
}