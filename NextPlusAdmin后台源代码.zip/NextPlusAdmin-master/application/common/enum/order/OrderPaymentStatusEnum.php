<?php

namespace app\common\enum\order;

/**
 * 订单支付状态
 *
 * Class OrderPaymentStatus
 */
class OrderPaymentStatusEnum
{
    const UNPAID = 0;
    const PAID = 1;
    const APPLY_REFUND = 2;

    /**
     * 获取订单支付状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getOrderPaymentStatusMean($value):string
    {
        switch ($value) {
            case self::UNPAID:
                return "unpaid";

            case self::PAID:
                return "paid";

            case self::APPLY_REFUND:
                return "apply refund";

            default:
                return "";
        }
    }
}