<?php

namespace app\common\enum\product;

/**
 * Class ProductEnum
 */
class ProductEnum
{
    const SHELF = 1;
    const NOT_SHELF = 0;

    /**
     * 获取相框上架状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getProductSHELFMean($value):string
    {
        switch ($value) {
            case self::SHELF:
                return "上架";

            case self::NOT_SHELF:
                return "未上架";

            default:
                return "";
        }
    }
}