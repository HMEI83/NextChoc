<?php


namespace app\common\enum\product;

/**
 * Class ProductTypeEnum
 *
 * @package app\common\enum\product
 */
class ProductTypeEnum
{
    const PHOTO_FRAME = 1;
    const PHOTO_THIN = 2;

    /**
     * 获取相框上架状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getProductTypeMean($value):string
    {
        switch ($value) {
            case self::PHOTO_FRAME:
                return "相册";

            case self::PHOTO_THIN:
                return "相薄";

            default:
                return "";
        }
    }
}