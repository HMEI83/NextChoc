<?php

namespace app\common\enum\payment;

/**
 * Class PaymentStatusEnum
 *
 * @package app\common\enum\payment
 */
class PaymentStatusEnum
{
    const PAY_SUCCESS = 1;
    const START_REFUND = 2;
    const AMOUNT_RECEIVED = 3;
    const REFUND_FAIL = 4;

    /**
     * 获取订单状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getPaymentStatusMean($value):string
    {
        switch ($value) {
            case self::PAY_SUCCESS:
                return "支付成功";

            case self::START_REFUND:
                return "开始退款";

            case self::AMOUNT_RECEIVED:
                return "已到账";

            case self::REFUND_FAIL:
                return "退款失败";

            default:
                return "";
        }
    }
}