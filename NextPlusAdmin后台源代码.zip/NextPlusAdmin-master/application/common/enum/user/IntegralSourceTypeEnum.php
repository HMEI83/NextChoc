<?php

namespace app\common\enum\user;

/**
 * Class IntegralSourceTypeEnum
 *
 * @package app\common\enum\user
 */
class IntegralSourceTypeEnum
{
    const ORDER_DONE = "order_done";

    /**
     * 获取用户信用卡状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getIntegralSourceTypeMean($value):string
    {
        switch ($value) {
            case self::ORDER_DONE:
                return "订单结算";

            default:
                return "";
        }
    }
}