<?php

namespace app\common\enum\user;

/**
 * Class CardEnum
 */
class CardEnum
{
    const DISABLE = 0;
    const NORMAL = 1;

    /**
     * 获取用户信用卡状态
     *
     * @param mixed $value
     * @return string
     */
    public static function getCardStatusMean($value):string
    {
        switch ($value) {
            case self::NORMAL:
                return "正常";

            case self::DISABLE:
                return "禁用";

            default:
                return "";
        }
    }
}