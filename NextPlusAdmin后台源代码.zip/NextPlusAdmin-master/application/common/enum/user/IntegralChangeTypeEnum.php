<?php

namespace app\common\enum\user;

/**
 * Class IntegralChangeTypeEnum
 *
 * @package app\common\enum\user
 */
class IntegralChangeTypeEnum
{
    const ADD = 1;
    const REDUCE = 2;
}