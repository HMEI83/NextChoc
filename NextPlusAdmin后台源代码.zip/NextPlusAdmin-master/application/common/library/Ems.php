<?php

namespace app\common\library;

use fast\Random;
use think\Hook;

/**
 * 邮箱验证码类
 */
class Ems
{

    /**
     * 验证码有效时长
     * @var int
     */
    protected static $expire = 60 * 12;

    /**
     * 最大允许检测的次数
     * @var int
     */
    protected static $maxCheckNums = 10;

    /**
     * 获取最后一次邮箱发送的数据
     *
     * @param int    $email 邮箱
     * @param string $event 事件
     * @return  Ems
     */
    public static function get($email, $event = 'default')
    {
        $ems = \app\common\model\Ems::
        where(['email' => $email, 'event' => $event])
            ->order('id', 'DESC')
            ->find();
        Hook::listen('ems_get', $ems, null, true);
        return $ems ? $ems : null;
    }

    /**
     * 发送验证码
     *
     * @param int    $email 邮箱
     * @param int    $code  验证码,为空时将自动生成4位数字
     * @param string $event 事件
     * @return  boolean
     */
    public static function send($email, $code = null, $event = 'default')
    {
        $code = is_null($code) ? Random::numeric(6) : $code;

        $html = self::getHtml($code, request()->domain());
        $time = time();
        $ip = request()->ip();
        $ems = \app\common\model\Ems::create(['event' => $event, 'email' => $email, 'code' => $code, 'ip' => $ip, 'createtime' => $time]);
        if (!Hook::get('ems_send')) {
            //采用框架默认的邮件推送
            Hook::add('ems_send', function ($params) use ($html) {
                $obj = new Email();
                $result = $obj
                    ->to($params->email)
                    ->subject('NextChoc One-time verification code！')
                    ->message($html)
                    ->send();
                return $result;
            });
        }
        $result = Hook::listen('ems_send', $ems, null, true);
        if (!$result) {
            $ems->delete();
            return false;
        }
        return true;
    }

    public static function getHtml($code, $domain)
    {
        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>

    </title>
</head>
<body>

        <table><tr><td width="600">
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%; max-width:600px;" align="center">
            <tbody><tr>
                <td role="modules-container" style="padding:0px 0px 0px 0px; color:#000000; text-align:left;" bgcolor="#FFFFFF" width="100%" align="left"><table class="module preheader preheader-hide" role="module" data-type="preheader" border="0" cellpadding="0" cellspacing="0" width="100%" style="display: none !important; mso-hide: all; visibility: hidden; opacity: 0; color: transparent; height: 0; width: 0;">
                    <tbody><tr>
                        <td role="module-content">
                            <p></p>
                        </td>
                    </tr>
                    </tbody></table><table class="wrapper" role="module" data-type="image" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="5821e531-dcbc-49d2-8be4-3ca400f4266f">
                    <tbody>
                    <tr>
                        <td style="font-size:6px; line-height:10px; padding:0px 0px 0px 0px;" valign="top" align="center">
                            <img class="max-width" border="0" style="display:block; color:#000000; text-decoration:none; font-family:Helvetica, arial, sans-serif; font-size:16px; max-width:35% !important; width:35%; height:auto !important;" width="210" alt="" data-proportionally-constrained="true" data-responsive="true" src="{$domain}/logo.png">
                        </td>
                    </tr>
                    </tbody>
                </table><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="860e804e-b301-40d6-8f4a-5ff871d58ea6" data-mc-module-version="2019-10-22">
                    <tbody>
                    <tr>
                        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: inherit">You have requested a verification code to sign in. To finish signing in, enter the below verification code.</div><div></div></div></td>
                    </tr>
                    </tbody>
                </table><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="272d4283-c9bf-4493-b26d-d006e15f85cc" data-mc-module-version="2019-10-22">
                    <tbody>
                    <tr>
                        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: inherit"><span style="color: #000000; font-family: &quot;arial black&quot;, helvetica, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space-collapse: preserve; text-wrap: wrap; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; float: none; display: inline; font-size: 36px">{$code}</span></div><div></div></div></td>
                    </tr>
                    </tbody>
                </table><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="7f4a6150-b787-4da9-835d-6763bae6ee3c" data-mc-module-version="2019-10-22">
                    <tbody>
                    <tr>
                        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: inherit">Enter the code to continue. It's valid for 15 minutes</div>
                            <div style="font-family: inherit; text-align: inherit"><br></div>
                            <div style="font-family: inherit; text-align: inherit">If you received this in error, simply ignore this email. As this is an automated message please do not reply directly to this email.&nbsp;</div>
                            <div style="font-family: inherit; text-align: inherit"><br></div>
                            <div style="font-family: inherit; text-align: inherit"><span style="color: #000000; font-family: arial, helvetica, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space-collapse: preserve; text-wrap: wrap; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; float: none; display: inline">Thanks,</span></div>
                            <div style="font-family: inherit; text-align: inherit"><br></div>
                            <div style="font-family: inherit; text-align: inherit">The Nextchoc Team</div>
                            <div style="font-family: inherit; text-align: inherit"><br></div>
                            <div style="font-family: inherit; text-align: inherit"><br></div><div></div></div></td>
                    </tr>
                    </tbody>
                </table><table class="module" role="module" data-type="divider" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="c016419c-9d21-43f1-910d-ddf68fa45ed7">
                    <tbody>
                    <tr>
                        <td style="padding:0px 0px 15px 0px;" role="module-content" height="100%" valign="top" bgcolor="">
                            <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" height="1px" style="line-height:1px; font-size:1px;">
                                <tbody>
                                <tr>
                                    <td style="padding:0px 0px 1px 0px;" bgcolor="#000000"></td>
                                </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table><table class="module" role="module" data-type="social" align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="7474f4e0-2a66-4172-9f1b-7128d31a95e8">
                    <tbody>
                    <tr>
                        <td valign="top" style="padding:0px 0px 0px 0px; font-size:6px; line-height:10px;" align="center">
                            <table align="center" style="-webkit-margin-start:auto;-webkit-margin-end:auto;">
                                <tbody><tr align="center"><td style="padding: 0px 5px;" class="social-icon-column">
                                    <a role="social-icon-link" href="https://www.facebook.com/nextchoc" target="_blank" alt="Facebook" title="Facebook" style="display:inline-block; background-color:#3B579D; height:35px; width:35px;">
                                        <img role="social-icon" alt="Facebook" title="Facebook" src="{$domain}/facebook.png" style="height:35px; width:35px;" height="35" width="35">
                                    </a>
                                </td><td style="padding: 0px 5px;" class="social-icon-column">
                                    <a role="social-icon-link" href="https://twitter.com/nextchoc113301" target="_blank" alt="Twitter" title="Twitter" style="display:inline-block; background-color:#7AC4F7; height:35px; width:35px;">
                                        <img role="social-icon" alt="Twitter" title="Twitter" src="{$domain}/twitter.png" style="height:35px; width:35px;" height="35" width="35">
                                    </a>
                                </td><td style="padding: 0px 5px;" class="social-icon-column">
                                    <a role="social-icon-link" href="https://www.instagram.com/nextchoc/" target="_blank" alt="Instagram" title="Instagram" style="display:inline-block; background-color:#7F4B30; height:35px; width:35px;">
                                        <img role="social-icon" alt="Instagram" title="Instagram" src="{$domain}/instagram.png" style="height:35px; width:35px;" height="35" width="35">
                                    </a>
                                </td></tr></tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table><table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" role="module" data-type="columns" style="padding:0px 0px 0px 0px;" bgcolor="#FFFFFF" data-distribution="1,1,1,1">
                    <tbody>
                    <tr role="module-content">
                        <td height="100%" valign="top"><table width="135" style="width:135px; border-spacing:0; border-collapse:collapse; margin:0px 10px 0px 0px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-0">
                            <tbody>
                            <tr>
                                <td style="padding:0px;margin:0px;border-spacing:0;"><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="38e371f2-b3a6-4fb0-9767-62177977be7c" data-mc-module-version="2019-10-22">
                                    <tbody>
                                    <tr>
                                        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: center"><a href="https://nextchoc.com.au/contact-us/" target="_blank"><span style="font-size: 14px">Contact us</span></a></div><div></div></div></td>
                                    </tr>
                                    </tbody>
                                </table></td>
                            </tr>
                            </tbody>
                        </table><table width="135" style="width:135px; border-spacing:0; border-collapse:collapse; margin:0px 10px 0px 10px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-1">
                            <tbody>
                            <tr>
                                <td style="padding:0px;margin:0px;border-spacing:0;"><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="c7f17459-5bfe-43fb-b059-c51bccfd9482" data-mc-module-version="2019-10-22">
                                    <tbody>
                                    <tr>
                                        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: center"><a href="https://nextchoc.com.au/terms-and-conditions/" target="_blank">Terms &amp; Conditions</a></div><div></div></div></td>
                                    </tr>
                                    </tbody>
                                </table></td>
                            </tr>
                            </tbody>
                        </table><table width="135" style="width:135px; border-spacing:0; border-collapse:collapse; margin:0px 10px 0px 10px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-2">
                            <tbody>
                            <tr>
                                <td style="padding:0px;margin:0px;border-spacing:0;"><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="97f86c67-2784-45ed-bdbd-7f6f75067f98" data-mc-module-version="2019-10-22">
                                    <tbody>
                                    <tr>
                                        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: center"><a href="https://nextchoc.com.au/privacy-policy/" target="_blank"><span style="font-size: 14px">Privacy Policy</span></a></div><div></div></div></td>
                                    </tr>
                                    </tbody>
                                </table></td>
                            </tr>
                            </tbody>
                        </table><table width="135" style="width:135px; border-spacing:0; border-collapse:collapse; margin:0px 0px 0px 10px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-3">
                            <tbody>
                            <tr>
                                <td style="padding:0px;margin:0px;border-spacing:0;"><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="a76cb1c3-b280-4bfd-8ad4-48e4059ca7da" data-mc-module-version="2019-10-22">
                                    <tbody>
                                    <tr>
                                        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: center"><a href="https://nextchoc.com.au/" target="_blank">Visit Website</a></div><div></div></div></td>
                                    </tr>
                                    </tbody>
                                </table></td>
                            </tr>
                            </tbody>
                        </table></td>
                    </tr>
                    </tbody>
                </table></td>
            </tr>
            </tbody>
        </table>
</body>
</html>
HTML;

    }

    /**
     * 发送通知
     *
     * @param mixed  $email    邮箱,多个以,分隔
     * @param string $msg      消息内容
     * @param string $template 消息模板
     * @return  boolean
     */
    public static function notice($email, $msg = '', $template = null)
    {
        $params = [
            'email'    => $email,
            'msg'      => $msg,
            'template' => $template
        ];
        if (!Hook::get('ems_notice')) {
            //采用框架默认的邮件推送
            Hook::add('ems_notice', function ($params) {
                $subject = '你收到一封新的邮件！';
                $content = $params['msg'];
                $email = new Email();
                $result = $email->to($params['email'])
                    ->subject($subject)
                    ->message($content)
                    ->send();
                return $result;
            });
        }
        $result = Hook::listen('ems_notice', $params, null, true);
        return $result ? true : false;
    }

    /**
     * 校验验证码
     *
     * @param int    $email 邮箱
     * @param int    $code  验证码
     * @param string $event 事件
     * @return  boolean
     */
    public static function check($email, $code, $event = 'default')
    {
        $time = time() - self::$expire;
        $ems = \app\common\model\Ems::where(['email' => $email, 'event' => $event])
            ->order('id', 'DESC')
            ->find();
        if ($ems) {
            if ($ems['createtime'] > $time && $ems['times'] <= self::$maxCheckNums) {
                $correct = $code == $ems['code'];
                if (!$correct) {
                    $ems->times = $ems->times + 1;
                    $ems->save();
                    return "Verification Code is Incorrect";
                } else {
                    $result = Hook::listen('ems_check', $ems, null, true);
                    return true;
                }
            } else {
                // 过期则清空该邮箱验证码
                // self::flush($email, $event);
                return "Verification Code has expired";
            }
        } else {
            return "Verification Code is Incorrect";
        }
    }

    /**
     * 清空指定邮箱验证码
     *
     * @param int    $email 邮箱
     * @param string $event 事件
     * @return  boolean
     */
    public static function flush($email, $event = 'default')
    {
        \app\common\model\Ems::
        where(['email' => $email, 'event' => $event])
            ->delete();
        Hook::listen('ems_flush');
        return true;
    }
}
