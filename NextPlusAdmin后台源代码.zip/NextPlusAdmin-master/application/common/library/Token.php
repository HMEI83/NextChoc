<?php

namespace app\common\library;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\SignatureInvalidException;
use think\Env;
use DomainException;
use InvalidArgumentException;
use UnexpectedValueException;
use Firebase\JWT\BeforeValidException;
use Firebase\JWT\ExpiredException;

/**
 * Class JwtAuth
 *
 * @package app\common\library
 */
class Token
{
    private $token;

    private $uid;

    private static $instance;

    /**
     * @return \app\common\library\Token
     */
    public static function getInstance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * 生成Token
     *
     * @return $this
     */
    public function encodeToken()
    {
        $secret = config("jwt.secret");
        $algo = config("jwt.algo");
        $ttl = config("jwt.ttl");
        $time = time();
        // 定义载荷
        $payload = [
            'iss' => Env::get("app.app_url"),   // JWT 的发行者
            'aud' => Env::get("app.app_url"),   // JWT 的目标接收者
            'iat' => $time,                            // 发布JWT的时间；可用于确定 JWT 的年龄
            'nbf' => $time,                            // JWT 不能被接受处理的时间
            "exp" => $time + $ttl,                     // 过期时间
            "sub" => $this->uid,                       // JWT 的主题（用户）
        ];

        $this->token = JWT::encode($payload, $secret, $algo);

        return $this;
    }

    /**
     * 解析 Token
     *
     * @return array
     */
    public function decodeToekn()
    {
        $secret = config("jwt.secret");
        $algo = config("jwt.algo");

        try {
            $result = JWT::decode($this->token, new Key($secret, $algo));
            return ["uid" => $result->sub];
        } catch (SignatureInvalidException $e){
            // JWT 签名验证失败
            return [];
        } catch (InvalidArgumentException $e) {
            return [];
        } catch (DomainException $e) {
            // 提供的算法不受支持
            // 提供的密钥无效
            // 在 openSSL 或 libsodium 中抛出的未知错误或libsodium 是必需的，但不可用
            return [];
        } catch (BeforeValidException $e) {
            // 如果 JWT 试图在“nbf”声明之前使用或如果 JWT 试图在“iat”声明之前使用
            return [];
        } catch (ExpiredException $e) {
            // 如果 JWT 试图在“exp”声明之后使用
            return [];
        } catch (UnexpectedValueException $e) {
            // 如果 JWT 格式错误
            // 如果 JWT 缺少算法/使用不支持的算法
            // 提供的 JWT 算法与提供的密钥不匹配
            // 键/键数组中提供的键 ID 为空或无效
            return [];
        }
    }

    // 判断token 是否可用
    public function checkToken()
    {

    }

    // 清除Token
    public function clearToken()
    {

    }

    /**
     * 获取 Token
     *
     * @return string
     */
    public function getToken()
    {
        return (string)$this->token;
    }

    /**
     * 设置Token
     *
     * @param $token
     *
     * @return $this
     */
    public function setToken($token)
    {
        $this->token = $token;
        return $this;
    }

    /**
     * 设置Uid
     *
     * @param $uid
     *
     * @return $this
     */
    public function setUid($uid)
    {
        $this->uid = $uid;
        return $this;
    }
}