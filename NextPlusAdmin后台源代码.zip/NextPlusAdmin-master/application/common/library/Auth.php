<?php

namespace app\common\library;

use app\common\model\User;
use app\common\model\UserRule;
use app\common\model\UserThird;
use fast\Random;
use think\Config;
use think\Db;
use think\Exception;
use think\Request;
use think\Validate;

class Auth
{
    protected static $instance = null;
    protected $_error = '';
    protected $_logined = false;
    protected $_user = null;
    protected $_token = '';
    //Token默认有效时长
    protected $keeptime = 2592000;
    protected $requestUri = '';
    protected $rules = [];
    //默认配置
    protected $config = [];
    protected $options = [];
    protected $allowFields = ['id', 'username', 'nickname', 'mobile', 'avatar', 'score'];

    public function __construct($options = [])
    {
        if ($config = Config::get('user')) {
            $this->config = array_merge($this->config, $config);
        }
        $this->options = array_merge($this->config, $options);
    }

    /**
     *
     * @param array $options 参数
     * @return Auth
     */
    public static function instance($options = [])
    {
        if (is_null(self::$instance)) {
            self::$instance = new static($options);
        }

        return self::$instance;
    }

    /**
     * 获取User模型
     * @return User
     */
    public function getUser()
    {
        return $this->_user;
    }

    /**
     * 兼容调用user模型的属性
     *
     * @param string $name
     * @return mixed
     */
    public function __get($name)
    {
        return $this->_user ? $this->_user->$name : null;
    }

    /**
     * 兼容调用user模型的属性
     */
    public function __isset($name)
    {
        return isset($this->_user) ? isset($this->_user->$name) : false;
    }

    /**
     * 根据Token初始化
     *
     * @param string $token Token
     * @return boolean
     */
    public function init($token)
    {
        if ($this->_logined) {
            return true;
        }
        if ($this->_error) {
            return false;
        }
        $data = Token::getInstance()->setToken($token)->decodeToekn();
        if (empty($data)) {
            return false;
        }
        $user_id = intval($data['uid']);
        if ($user_id > 0) {
            $user = User::get($user_id);
            if (!$user) {
                $this->setError('Account not exist');
                return false;
            }
            if ($user['status'] != 'normal') {
                $this->setError('Account is locked');
                return false;
            }
            $this->_user = $user;
            $this->_logined = true;
            $this->_token = $token;

            return true;
        } else {
            $this->setError('You are not logged in');
            return false;
        }
    }

    /**
     * Email 注册
     *
     * @param $email
     * @param $password
     *
     * @return bool
     */
    public function registerByEmail($email, $otherInfo)
    {
        $ip = request()->ip();
        $time = time();

        $salt = Random::alnum();
        $password = $this->getEncryptPassword($otherInfo['password'], $salt);
        $data = [
            // 无密码
            'password' => $password,
            'email'    => $email,
            "nickname" => $otherInfo['nickname'],
            "username" => $otherInfo['nickname'],
            'level'    => 1,
            'score'    => 0,
            'avatar'   => letter_avatar($otherInfo['nickname']),
        ];
        $params = array_merge($data, [
            'salt'      => $salt,
            'jointime'  => $time,
            'joinip'    => $ip,
            'logintime' => $time,
            'loginip'   => $ip,
            'prevtime'  => $time,
            'status'    => 'normal',
            "device"    => $otherInfo['device'] ?? "",
            "exponent_push_token" => $otherInfo['exponent_push_token'] ?? ""
        ]);

        //账号注册时需要开启事务,避免出现垃圾数据
        Db::startTrans();
        try {
            $user = User::create($params, true);

            $this->_user = User::get($user->id);

            $this->_token = Token::getInstance()->setUid($user->id)->encodeToken()->getToken();
            //设置登录状态
            $this->_logined = true;

            Db::commit();
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            Db::rollback();
            return false;
        }
        return true;
    }

    /**
     * 手机号登录
     *
     * @param $mobile
     * @param $otherInfo
     *
     * @return bool
     */
    public function registerByMobile($mobile, $otherInfo)
    {
        $ip = request()->ip();
        $time = time();

        $salt = Random::alnum();
        $password = $this->getEncryptPassword($otherInfo['password'], $salt);
        $data = [
            'password' => $password,
            'email'    => "",
            "mobile"   => $mobile,
            "nickname" => $otherInfo['nickname'],
            "username" => $otherInfo['nickname'],
            'level'    => 1,
            'score'    => 0,
            'avatar'   => letter_avatar($otherInfo['nickname']),
        ];
        $params = array_merge($data, [
            'salt'      => $salt,
            'jointime'  => $time,
            'joinip'    => $ip,
            'logintime' => $time,
            'loginip'   => $ip,
            'prevtime'  => $time,
            'status'    => 'normal',
            "device"    => $otherInfo['device'] ?? "",
            "exponent_push_token" => $otherInfo['exponent_push_token'] ?? ""
        ]);

        Db::startTrans();
        try {
            $user = User::create($params, true);

            $this->_user = User::get($user->id);

            $this->_token = Token::getInstance()->setUid($user->id)->encodeToken()->getToken();
            //设置登录状态
            $this->_logined = true;

            Db::commit();
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            Db::rollback();
            return false;
        }
        return true;
    }

    /**
     * 验证码登录
     *
     * @param $user
     *
     * @return bool
     */
    public function login($user, $otherInfo)
    {
        $user->exponent_push_token = $otherInfo['exponent_push_token'] ?? "";
        $user->device = $otherInfo['device'] ?? "";
        $user->prevtime = $user->logintime;
        //记录本次登录的IP和时间
        $user->loginip = request()->ip();
        $user->logintime = time();
        //重置登录失败次数
        $user->loginfailure = 0;

        $user->save();

        $this->_token = Token::getInstance()->setUid($user->id)->encodeToken()->getToken();
        $this->_user = $user;
        //设置登录状态
        $this->_logined = true;

        return true;
    }

    /**
     * 邮箱密碼登录
     *
     * @param $account
     * @param $otherInfo
     *
     * @return bool
     * @throws \think\exception\DbException
     */
    public function loginByEmailOrMobilePassword($account, $otherInfo)
    {
        $user = User::where(function ($query) use ($account) {
            $query->where("email", $account)
                ->whereOr("mobile", $account);
        })
            ->find();

        if (!$user) {
            $this->setError(__("Email or phone number does not exist"));
            return false;
        }

        Db::startTrans();
        try {
            // 先查找是否用户是否已经存在
            // 如果不存在，则注册
            // 如果存在，则验证密码是否正确
            // 返回 Token 等信息
            if (empty($user)) {
                $ip = request()->ip();
                $time = time();

                $email = $mobile = "";
                if ( Validate::is($account, "email")) {
                    $email = $account;
                } else {
                    $mobile = $account;
                }

                $salt = Random::alnum();
                $password = $this->getEncryptPassword($otherInfo['password'], $salt);
                $data = [
                    'password' => $password,
                    'email'    => $email,
                    "area_code" => $otherInfo['area_code'] ?? 0,
                    "mobile"   => $mobile,
                    "nickname" => $email ?: $mobile,
                    "username" => $email ?: $mobile,
                    'level'    => 1,
                    'score'    => 0,
                    'avatar'   => letter_avatar($email ?: $mobile),
                    "facebook" => null,
                    "google"   => null,
                    "lng"      => 0,
                    "lat"      => 0,
                    "is_allow_promot_notify"   => 0,
                    "is_allow_push_notify"   => 0,
                ];
                $paramsData = array_merge($data, [
                    'salt'      => $salt,
                    'jointime'  => $time,
                    'joinip'    => $ip,
                    'logintime' => $time,
                    'loginip'   => $ip,
                    'prevtime'  => $time,
                    'status'    => 'normal',
                    "device"    => $otherInfo['device'] ?? "",
                    "exponent_push_token" => $otherInfo['exponent_push_token'] ?? ""
                ]);
                $user = \app\common\model\User::create($paramsData, true);
            } else {
                if ($user->password !== $this->getEncryptPassword($otherInfo['password'], $user->salt)) {
                    $this->setError("Password is incorrect");
                    return false;
                }

                if ($user->status != 'normal') {
                    $this->setError('Account is locked');
                    return false;
                }

                //判断连续登录和最大连续登录
                if ($user->logintime < \fast\Date::unixtime('day')) {
                    $user->successions = $user->logintime < \fast\Date::unixtime('day', -1) ? 1 : $user->successions + 1;
                    $user->maxsuccessions = max($user->successions, $user->maxsuccessions);
                }
            }

            $user->exponent_push_token = $otherInfo['exponent_push_token'] ?? "";
            $user->device = $otherInfo['device'] ?? "";
            $user->prevtime = $user->logintime;
            //记录本次登录的IP和时间
            $user->loginip = request()->ip();
            $user->logintime = time();
            //重置登录失败次数
            $user->loginfailure = 0;

            $user->save();

            $this->_token = Token::getInstance()->setUid($user->id)->encodeToken()->getToken();
            $this->_user = $user;
            //设置登录状态
            $this->_logined = true;

            Db::commit();
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            Db::rollback();
            return false;
        }

        return true;
    }

    /**
     * Facebook 第三方登录
     *
     * @param $fbUser
     * @param $otherInfo
     *
     * @return bool
     */
    public function loginByFacebook($fbUser, $otherInfo)
    {
        if (empty($fbUser)) {
            $this->setError(__("Facebook info access failure"));
            return false;
        }
        if (empty($fbUser['email'])) {
            $this->setError(__("Facebook email access failure"));
            return false;
        }

        $user = User::where('email', $fbUser['email'])->find();
        Db::startTrans();
        try {
            if (empty($user)) {
                $user = User::create([
                    "device"            => $otherInfo['device'] ?? "",
                    "exponent_push_token" => $otherInfo['exponent_push_token'] ?? "",
                    "username"          => $fbUser["name"],
                    "nickname"          => $fbUser["name"],
                    "email"             => $fbUser['email'],
                    "avatar"            => "",
                    "facebook"          => $fbUser["name"],
                    "jointime"          => time(),
                    "logintime"         => time(),
                    "loginip"           => request()->ip(),
                    "status"            => "normal",
                    "register_type"     =>  "email",
                ]);
                $user = User::find($user->id);
            } elseif ($user->facebook != $fbUser['name']) {
                $user->device = $otherInfo['device'] ?? "";
                $user->exponent_push_token = $otherInfo['exponent_push_token'] ?? "";
                $user->facebook = $fbUser['name'];
                $user->save();
            }

            $userThirdInfo = UserThird::where("user_id", $user->id)
                ->where("platform", "facebook")
                ->find();
            if (empty($userThirdInfo)) {
                UserThird::create([
                    "user_id"       => $user->id,
                    "platform"      => "facebook",
                    "apptype"       => "",
                    "unionid"       => "",
                    "openname"      => "",
                    "openid"        => "",
                    "access_token"  => $otherInfo['access_token'],
                    "refresh_token" => "",
                    "expires_in"    => "",
                    "logintime"     => time(),
                    "expiretime"    => "",
                ]);
            }

            $this->_token = Token::getInstance()->setUid($user->id)->encodeToken()->getToken();
            $this->_user = $user;
            //设置登录状态
            $this->_logined = true;

            Db::commit();
            return true;
        } catch (Exception $e) {

            Db::rollback();
            return false;
        }
    }

    /**
     * Google 第三方登录
     *
     * @param $googleUser
     * @param $otherInfo
     *
     * @return bool
     */
    public function loginByGoogle($googleUser, $otherInfo)
    {
        if (empty($googleUser)) {
            $this->setError(__("Google info access failure"));
            return false;
        }
        if (empty($googleUser['email'])) {
            $this->setError(__("Google email access failure"));
            return false;
        }

        $user = User::where('email', $googleUser['email'])->find();
        Db::startTrans();
        try {
            if (empty($user)) {
                $user = User::create([
                    "device"              => $otherInfo['device'] ?? "",
                    "exponent_push_token" => $otherInfo['exponent_push_token'] ?? "",
                    "username"          => $googleUser["name"],
                    "nickname"          => $googleUser["name"],
                    "email"             => $googleUser['email'],
                    "avatar"            => "",
                    "google"            => $googleUser["name"],
                    "jointime"          => time(),
                    "logintime"         => time(),
                    "loginip"           => request()->ip(),
                    "status"            => "normal",
                    "register_type"     =>  "email",
                ]);
                $user = User::find($user->id);
            } elseif ($user->google != $googleUser['name']) {
                $user->device = $otherInfo['device'] ?? "";
                $user->exponent_push_token = $otherInfo['exponent_push_token'] ?? "";
                $user->google = $googleUser['name'];
                $user->save();
            }

            $userThirdInfo = UserThird::where("user_id", $user->id)
                ->where("platform", "google")
                ->find();
            if (empty($userThirdInfo)) {
                UserThird::create([
                    "user_id"       => $user->id,
                    "platform"      => "google",
                    "apptype"       => "",
                    "unionid"       => "",
                    "openname"      => "",
                    "openid"        => "",
                    "access_token"  => $otherInfo['access_token'],
                    "refresh_token" => "",
                    "expires_in"    => "",
                    "logintime"     => time(),
                    "expiretime"    => "",
                ]);
            }

            $this->_token = Token::getInstance()->setUid($user->id)->encodeToken()->getToken();
            $this->_user = $user;
            //设置登录状态
            $this->_logined = true;

            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();

            $this->setError($e->getMessage());
            return false;
        }
    }

    /**
     * 退出
     *
     * @return boolean
     */
    public function logout()
    {
        if (!$this->_logined) {
            $this->setError('You are not logged in');
            return false;
        }
        //设置登录标识
        $this->_logined = false;
        //清除Token
        return true;
    }

    /**
     * 重置密码
     * @param string $newpassword       新密码
     * @param string $oldpassword       旧密码
     * @param bool   $ignoreoldpassword 忽略旧密码
     * @return boolean
     */
    public function changepwd($user, $newpassword, $oldpassword = '', $ignoreoldpassword = false)
    {
        //判断旧密码是否正确
        if ($user->password == $this->getEncryptPassword($oldpassword, $user->salt) || $ignoreoldpassword) {
            Db::startTrans();
            try {
                $salt = Random::alnum();
                $newpassword = $this->getEncryptPassword($newpassword, $salt);
                User::where("id", $user->id)
                    ->update([
                        'loginfailure' => 0,
                        'password' => $newpassword,
                        'salt' => $salt
                    ]);

                Db::commit();
            } catch (Exception $e) {
                Db::rollback();
                $this->setError($e->getMessage());
                return false;
            }
            return true;
        } else {
            $this->setError('Old password is incorrect');
            return false;
        }
    }

    /**
     * 直接登录账号
     * @param int $user_id
     * @return boolean
     */
    public function direct($user_id)
    {
        $user = User::get($user_id);
        if ($user) {
            Db::startTrans();
            try {
                $ip = request()->ip();
                $time = time();

                //判断连续登录和最大连续登录
                if ($user->logintime < \fast\Date::unixtime('day')) {
                    $user->successions = $user->logintime < \fast\Date::unixtime('day', -1) ? 1 : $user->successions + 1;
                    $user->maxsuccessions = max($user->successions, $user->maxsuccessions);
                }

                $user->prevtime = $user->logintime;
                //记录本次登录的IP和时间
                $user->loginip = $ip;
                $user->logintime = $time;
                //重置登录失败次数
                $user->loginfailure = 0;

                $user->save();

                $this->_user = $user;

                $this->_token = Token::getInstance()->setUid($user->id)->encodeToken()->getToken();

                $this->_logined = true;

                Db::commit();
            } catch (Exception $e) {
                Db::rollback();
                $this->setError($e->getMessage());
                return false;
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * 删除一个指定会员
     * @param int $user_id 会员ID
     * @return boolean
     */
    public function delete($user_id)
    {
        $user = User::get($user_id);
        if (!$user) {
            return false;
        }
        Db::startTrans();
        try {
            // 删除会员
            $user->deletetime = time();
            $user->save();

            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->setError($e->getMessage());
            return false;
        }
        return true;
    }

    /**
     * 检测是否是否有对应权限
     * @param string $path   控制器/方法
     * @param string $module 模块 默认为当前模块
     * @return boolean
     */
    public function check($path = null, $module = null)
    {
        if (!$this->_logined) {
            return false;
        }

        $ruleList = $this->getRuleList();
        $rules = [];
        foreach ($ruleList as $k => $v) {
            $rules[] = $v['name'];
        }
        $url = ($module ? $module : request()->module()) . '/' . (is_null($path) ? $this->getRequestUri() : $path);
        $url = strtolower(str_replace('.', '/', $url));
        return in_array($url, $rules) ? true : false;
    }

    /**
     * 判断是否登录
     * @return boolean
     */
    public function isLogin()
    {
        if ($this->_logined) {
            return true;
        }
        return false;
    }

    /**
     * 获取当前Token
     * @return string
     */
    public function getToken()
    {
        return $this->_token;
    }

    /**
     * 获取会员基本信息
     */
    public function getUserinfo()
    {
        $data = $this->_user->toArray();
        $allowFields = $this->getAllowFields();
        return array_intersect_key($data, array_flip($allowFields));
    }

    /**
     * 获取会员组别规则列表
     * @return array
     */
    public function getRuleList()
    {
        if ($this->rules) {
            return $this->rules;
        }
        $group = $this->_user->group;
        if (!$group) {
            return [];
        }
        $rules = explode(',', $group->rules);
        $this->rules = UserRule::where('status', 'normal')->where('id', 'in', $rules)->field('id,pid,name,title,ismenu')->select();
        return $this->rules;
    }

    /**
     * 获取当前请求的URI
     * @return string
     */
    public function getRequestUri()
    {
        return $this->requestUri;
    }

    /**
     * 设置当前请求的URI
     * @param string $uri
     */
    public function setRequestUri($uri)
    {
        $this->requestUri = $uri;
    }

    /**
     * 获取允许输出的字段
     * @return array
     */
    public function getAllowFields()
    {
        return $this->allowFields;
    }

    /**
     * 设置允许输出的字段
     * @param array $fields
     */
    public function setAllowFields($fields)
    {
        $this->allowFields = $fields;
    }

    /**
     * 获取密码加密后的字符串
     * @param string $password 密码
     * @param string $salt     密码盐
     * @return string
     */
    public function getEncryptPassword($password, $salt = '')
    {
        return md5(md5($password) . $salt);
    }

    /**
     * 检测当前控制器和方法是否匹配传递的数组
     *
     * @param array $arr 需要验证权限的数组
     * @return boolean
     */
    public function match($arr = [])
    {
        $request = Request::instance();
        $arr = is_array($arr) ? $arr : explode(',', $arr);
        if (!$arr) {
            return false;
        }
        $arr = array_map('strtolower', $arr);
        // 是否存在
        if (in_array(strtolower($request->action()), $arr) || in_array('*', $arr)) {
            return true;
        }

        // 没找到匹配
        return false;
    }

    /**
     * 设置会话有效时间
     * @param int $keeptime 默认为永久
     */
    public function keeptime($keeptime = 0)
    {
        $this->keeptime = $keeptime;
    }

    /**
     * 渲染用户数据
     * @param array  $datalist  二维数组
     * @param mixed  $fields    加载的字段列表
     * @param string $fieldkey  渲染的字段
     * @param string $renderkey 结果字段
     * @return array
     */
    public function render(&$datalist, $fields = [], $fieldkey = 'user_id', $renderkey = 'userinfo')
    {
        $fields = !$fields ? ['id', 'nickname', 'level', 'avatar'] : (is_array($fields) ? $fields : explode(',', $fields));
        $ids = [];
        foreach ($datalist as $k => $v) {
            if (!isset($v[$fieldkey])) {
                continue;
            }
            $ids[] = $v[$fieldkey];
        }
        $list = [];
        if ($ids) {
            if (!in_array('id', $fields)) {
                $fields[] = 'id';
            }
            $ids = array_unique($ids);
            $selectlist = User::where('id', 'in', $ids)->column($fields);
            foreach ($selectlist as $k => $v) {
                $list[$v['id']] = $v;
            }
        }
        foreach ($datalist as $k => &$v) {
            $v[$renderkey] = isset($list[$v[$fieldkey]]) ? $list[$v[$fieldkey]] : null;
        }
        unset($v);
        return $datalist;
    }

    /**
     * 设置错误信息
     *
     * @param string $error 错误信息
     * @return Auth
     */
    public function setError($error)
    {
        $this->_error = $error;
        return $this;
    }

    /**
     * 获取错误信息
     * @return string
     */
    public function getError()
    {
        return $this->_error ? __($this->_error) : '';
    }
}
