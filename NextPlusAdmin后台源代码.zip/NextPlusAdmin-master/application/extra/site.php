<?php

return array (
  'name' => 'NextPlus',
  'beian' => '',
  'cdnurl' => '',
  'version' => '1.0.1',
  'timezone' => 'Australia/Melbourne',
  'forbiddenip' => '',
  'languages' => 
  array (
    'backend' => 'zh-cn',
    'frontend' => 'zh-cn',
  ),
  'fixedpage' => 'dashboard',
  'categorytype' => 
  array (
    'default' => 'Default',
    'page' => 'Page',
    'article' => 'Article',
    'test' => 'Test',
  ),
  'configgroup' => 
  array (
    'basic' => 'Basic',
    'email' => 'Email',
    'dictionary' => 'Dictionary',
    'user' => 'User',
    'example' => 'Example',
  ),
  'mail_type' => '1',
  'mail_smtp_host' => 'smtp.office365.com',
  'mail_smtp_port' => '587',
  'mail_smtp_user' => 'nextchoc@outlook.com',
  'mail_smtp_pass' => 'Nexttechplus2023',
  'mail_verify_type' => '1',
  'mail_from' => 'nextchoc@outlook.com',
  'attachmentcategory' => 
  array (
    'category1' => 'Category1',
    'category2' => 'Category2',
    'custom' => 'Custom',
  ),
  'company_address' => '這是一個公司地址',
  'company_contact_info' => '這是一個公司聯繫方式',
);
