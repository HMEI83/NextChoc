<?php

use think\Env;

return [

    // 用于加密生成 token 的 secret
    'secret' => Env::get('jwt.JWT_SECRET', ''),

    // token 生存时间（60 * 60 表示有效期为一个小时）
    'ttl' => Env::get('jwt.JWT_TTL', 60 * 60 * 24),

    // 算法
    'algo' => Env::get('jwt.JWT_ALGO', 'HS256'),
];