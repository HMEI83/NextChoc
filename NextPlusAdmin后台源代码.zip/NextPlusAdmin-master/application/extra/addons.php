<?php

return [
    'autoload' => false,
    'hooks' => [
        'config_init' => [
            'summernote',
        ],
    ],
    'route' => [],
    'priority' => [],
    'domain' => '',
];
