<?php

namespace app\api\controller;

use app\admin\model\activity\Activitypush;
use app\common\controller\Api;

use function fast\e;

/**
 * Class ExpoPushRecord
 *
 * @package app\api\controller
 */
class Expopushrecord extends Api
{
    protected $noNeedLogin = ["index"];

    protected $noNeedRight = '*';

    public function index()
    {
        $userId = $this->auth->id;
        $listRows = $this->request->param("listRows", "15");
        if (empty($userId)) {
            $result = Activitypush::field("*")
                ->order("id", "desc")
                ->paginate($listRows);

            foreach ($result as $item) {
                $item->human_date = human_date($item->createtime);
                // $item->body = $item->content;
            }
            $this->success(__("Operation completed"), $result);
        }

        $data = Activitypush::field("*")
            // ->where("user_id", $userId)
            // ->where("successswitch", 1)
            ->order("id", "desc")
            ->paginate($listRows);

        foreach ($data as $item) {
            $item->human_date = human_date($item->createtime);
        }

        $this->success(__("Operation completed"), $data);
    }
}