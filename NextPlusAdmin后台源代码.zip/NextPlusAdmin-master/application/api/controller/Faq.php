<?php

namespace app\api\controller;

use app\common\controller\Api;

/**
 * FAQ
 */
class Faq extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    // FAQ 列表
    public function index()
    {
        $result = \app\admin\model\other\Faq::field("id, answer, question")
            ->select();

        $this->success(__("Operation completed"), $result);
    }
}