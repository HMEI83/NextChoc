<?php

namespace app\api\controller;

use app\admin\model\activity\Banner;
use app\admin\model\Admin;
use app\api\library\Redis;
use app\common\controller\Api;
use app\common\enum\order\OrderStatusEnum;

/**
 * 首页接口
 */
class Index extends Api
{
    protected $noNeedLogin = ['*'];

    protected $noNeedRight = ['*'];

    /**
     * 首页
     *
     */
    public function index()
    {
        $uid = $this->auth->id;
        /**
         * 需要返回给首页的信息：
         * 1. Banner
         * 2. 待取袋的订单
         * 3. 猜你喜欢的商铺
         * 4. 附近的商铺
         * 5. 销量最高的商铺
         */

        $result = [];
        $banner = Banner::field("id, coverimage, content, type")
            ->where("coverimage", "<>", "")
            ->where("category_type", "-")
            ->order("sort", "desc")
            ->limit(6)
            ->select();

        $geoMerchantKey = config("app.geo_merchant_key");
        $merchantKey = config("app.merchant_key");
        $userKey = config("app.user_key");

        $redis = Redis::instance()->redis;

        // 猜你喜欢的商铺
        $relatedMerchant = Admin::field("id, merchantname, merchantaddress, businesshours, score, logo")
            ->where("adminswitch", 0)
            ->where("pid", 0)
            ->where("status", "normal")
            ->orderRaw('rand()')
            ->limit(6)
            ->select();

        // 附近的商铺
        $nearByMerchant = Admin::field("id, merchantname, merchantaddress, businesshours, score, logo")
            ->where("adminswitch", 0)
            ->where("pid", 0)
            ->where("status", "normal")
            ->select();

        foreach ($relatedMerchant as $_relatedMerchant) {
            if (empty($uid)) {
                $_relatedMerchant->distance = 0 . " km";
            } else {
                $_relatedMerchant->distance = round($redis->geoDist($geoMerchantKey, $merchantKey.$_relatedMerchant->id, $userKey.$uid, "km"), 2);

                if ($_relatedMerchant->distance < 1) {
                    $_relatedMerchant->distance = "<1 km";
                } else {
                    $_relatedMerchant->distance = $_relatedMerchant->distance . " km";
                }
            }
        }

        foreach ($nearByMerchant as $merchant) {
            if (empty($uid)) {
                $merchant->distance = 0;
            } else {
                $merchant->distance = round($redis->geoDist($geoMerchantKey, $merchantKey.$merchant->id, $userKey.$uid, "km"), 2);
            }
        }

        $nearByMerchant = collection($nearByMerchant)->toArray();
        $key = "distance";
        usort($nearByMerchant, function($a, $b) use ($key) {
            return $a[$key] - $b[$key];
        });

        foreach ($nearByMerchant as &$merchant) {
            // $merchant['distance'] = $merchant['distance'] . " km";
            if (empty($uid)) {
                $merchant['distance'] = 0 . " km";
            } else {
                if ($merchant['distance'] < 1) {
                    $merchant['distance'] = "<1 km";
                } else {
                    $merchant['distance'] = $merchant['distance'] . " km";
                }
            }
        }

        // 销量最高的商铺
        $topMerchant= \app\admin\model\merchant\Merchant::field("id, merchantname, merchantaddress, businesshours, score, logo, category_id")
            ->with([
                "goodsCategory" => function ($query) {
                    $query->field("id, goods_category_name");
                }
            ])
            ->where("adminswitch", 0)
            ->where("pid", 0)
            ->where("status", "normal")
            ->order("salesvolume", "desc")
            ->select();

        foreach ($topMerchant as $_topMerchant) {
            if (empty($uid)) {
                $_topMerchant->distance = 0 . " km";
            } else {
                $_topMerchant->distance = round($redis->geoDist($geoMerchantKey, $merchantKey.$_topMerchant->id, $userKey.$uid, "km"), 2);

                if ($_topMerchant->distance < 1) {
                    $_topMerchant->distance = "<1 km";
                } else {
                    $_topMerchant->distance = $_topMerchant->distance . " km";
                }
            }
        }

        $pendingOrder = null;
        if (!empty($uid)) {
            $pendingOrder = \app\common\model\Order::field("id, merchant_id, title, check_code, amount, payment_amount, order_no, status, businesshours")
                ->with([
                    "merchant" => function ($query) {
                        $query->field("id, merchantname, businesshours,logo");
                    },
                ])
                ->where("user_id", $uid)
                ->where(function ($query) {
                    $query->where("status", OrderStatusEnum::SUCCESS_PACK);
                })
                ->limit(1)
                ->order("id", "desc")
                ->find();
            if (!empty($pendingOrder)) {
                $pendingOrder->merchant_name = $pendingOrder->merchant->merchantname;
                $pendingOrder->business_hours = $pendingOrder->merchant->businesshours;
                $pendingOrder->logo = cdnurl($pendingOrder->merchant->logo, true);
            }
        }

        $result['banner'] = $banner;
        $result['related_merchant'] = $relatedMerchant;
        $result['near_by_merchant'] = $nearByMerchant;
        $result['top_merchant'] = $topMerchant;
        $result['pending_order'] = $pendingOrder;

        $this->success(__("Operation completed"), $result);
    }
}
