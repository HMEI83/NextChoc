<?php

namespace app\api\controller;

use app\admin\model\activity\Banner;
use app\admin\model\Admin;
use app\admin\model\goods\Category;
use app\admin\model\goods\Goodscategory;
use app\admin\model\merchant\UserFavorite;
use app\api\library\Redis;
use app\common\controller\Api;
use app\admin\model\merchant\Merchant as MerchantModel;
use app\common\enum\order\OrderStatusEnum;
use app\common\library\Log;
use think\Validate;

/**
 * 商铺
 */
class Merchant extends Api
{
    protected $noNeedLogin = ["index", "detail", "radius"];

    protected $noNeedRight = ['*'];

    /**
     * 商铺列表
     *
     * @return void
     * @throws \think\exception\DbException
     */
    public function index()
    {
        $uid = $this->auth->id;
        $sortType = $this->request->param("sort_type");
        $address = $this->request->param("address");
        $keywords = $this->request->param("keywords");
        $listRows = $this->request->param("listRows", "15");

        $query = new \think\db\Query();
        $query->table("fa_admin");
        $query->field("id, merchantname, merchantaddress, businesshours, score, logo, category_id, lng, lat");
        $query->where("adminswitch", 0);
        $query->where("pid", 0);
        $query->where("status", 'normal');

        if (!empty($address)) {
            $query->where("merchantaddress", "like", "%$address%");
        }

        if (!empty($keywords)) {
            $query->where("merchantname", "like", "%$keywords%");
        }

        /**
         * 排序方式：
         * last_minutes：倒计时停止售卖的店铺
         * most_popular：销量最好的店铺
         * best：评分最好的店铺
         * lunch：下午前的盲盒产品
         * super_marker：超市里的甜品店铺
         * favorite：最受用户收藏的店铺
         * guess_for_you：猜你喜欢的商铺
         * near_by: 附近的商铺
         */
        $banner = null;
        switch ($sortType) {
            // 营业时间倒序
            case "last_minutes":
                $banner = Banner::where("category_type", "Last Minute")->find();
                // 店铺结束营业时间
                // 越接近当前时间，越排名靠前
                $query->whereRaw("`closinghours` > CURRENT_TIME()");
                $query->order("closinghours");
                break;

            case "lunch":
                // 店铺开始营业时间，是下午之前的店铺
                $banner = Banner::where("category_type", "Lunch")->find();
                $query->whereRaw("HOUR(`openinghours`) < 12");
                $query->order("openinghours");
                break;

            case "top_seller":
            case "most_popular":
                $banner = Banner::where("category_type", "Most Popular")->find();
                $query->order("salesvolume", "desc");
                break;

            case "super_marker":
                $banner = Banner::where("category_type", "Super markets")->find();
                // 默认超市分类
                $query->where("category_id", "1");
                break;

            case "best":
                $banner = Banner::where("category_type", "Best")->find();
                $query->order("score", "desc");
                break;

            case "favorite":
                $banner = Banner::where("category_type", "Favorite")->find();
                $query->where("collectionquantity", ">", 0);
                $query->order("collectionquantity", "desc");
                break;

            case "guess_for_you":
                $query->orderRaw('rand()');
                break;

            case "near_by":
                if (empty($uid)) {
                    $query->order("id", "desc");
                } else {
                    $user = $this->auth->getUser();
                    $lng = $user->lng;
                    $lat = $user->lat;

                    $query->fieldRaw("(2 * 6378.137* ASIN(SQRT(POW(SIN(PI()*({$lng}-lng)/360),2)+COS(PI()*{$lat}/180)* COS(lat * PI()/180)*POW(SIN(PI()*({$lat}-lat)/360),2)))) as distance");
                    $query->order("distance", "asc");
                }

                break;
        }

        $list = [];
        $data = $query->paginate($listRows);

        $geoMerchantKey = config("app.geo_merchant_key");
        $merchantKey = config("app.merchant_key");
        $userKey = config("app.user_key");
        $redis = Redis::instance()->redis;
        foreach ($data->items() as &$item) {
            if (empty($uid)) {
                $item['distance'] = 0 . " km";
            } else {
                $item['distance'] = round($redis->geoDist($geoMerchantKey, $merchantKey.$item['id'], $userKey.$uid, "km"), 2);
                if ($item['distance'] < 1) {
                    $item['distance'] = "<1 km";
                } else {
                    $item['distance'] = $item['distance'] . " km";
                }
            }

            if ($sortType == "top_seller") {
                $item['category_name'] = Goodscategory::where("id", $item['category_id'])->value("goods_category_name");

                // 查找上個月的銷量
                $item['monthly_sales'] = \app\common\model\Order::where("merchant_id", $item['id'])
                    ->where("status", OrderStatusEnum::SUCCESS_CHECK)
                    ->where("createtime", ">", date("Y-m-d", strtotime("-1 month")))
                    ->count();
                $item['tag'] = "Top seller";
            }

            $isFavorite = UserFavorite::where("merchant_id", $item['id'])->where("user_id", $uid)->value("id");
            $list [] = [
                "merchant_id"      => $item['id'],
                "distance"         => $item['distance'],
                "merchant_address" => $item['merchantaddress'],
                "merchant_name"    => $item['merchantname'],
                "business_hours"   => $item['businesshours'],
                "score"            => $item['score'],
                "logo_format"      => cdnurl($item['logo'], true),
                "is_favorite"      => (int)!empty($isFavorite),
                "category_name"    => $item['category_name'] ?? "",
                "monthly_sales"    => $item['monthly_sales'] ?? 0,
                "tag"              => $item['tag'] ?? "",
                "lng"              => $item['lng'],
                "lat"              => $item['lat'],
            ];
        }

        $result['total'] = $data->total();
        $result['per_page'] = $data->listRows();
        $result['current_page'] = $data->currentPage();
        $result['last_page'] = $data->lastPage();
        $result['banner'] = $banner;
        $result['data'] = $list;
        $this->success(__("Operation completed"), $result);
    }

    /**
     * 返回半径内的商铺
     *
     * @return void
     */
    public function radius()
    {
        $uid = $this->auth->id;
        $keywords = $this->request->param("keywords");
        $params = $this->request->param();

        if (empty($params['lng']) || empty($params['lat'])) {
            $this->error(__("The longitude or dimension cannot be empty"));
        }

        if (!Validate::between($params['lng'], [-180, 180]) || !Validate::between($params['lat'], [-90, 90])) {
            $this->error(__('Please give a reasonable latitude and longitude'));
        }

        if (empty($params['radius'])) {
            $this->error(__("The radius cannot be empty"));
        }

        if (!is_numeric($params['radius'])) {
            $this->error(__("The radius must be a number"));
        }

        $redis = Redis::instance()->redis;
        $geoMerchantKey = config("app.geo_merchant_key");
        $merchantKey = config("app.merchant_key");
        $userKey = config("app.user_key");

        $merchantIds = $redis->geoRadius($geoMerchantKey, $params['lng'], $params['lat'], $params['radius'], 'km');
        if (empty($merchantIds)) {
            $this->success();
        }

        $ids = [];
        foreach ($merchantIds as $merchantId) {
            if (false !== strpos($merchantId, "merchant")) {
                $pos = strpos($merchantId, ":");
                $ids[] = substr($merchantId, $pos + 1);
            }
        }

        if (empty($ids)) {
            $this->success();
        }

        // 附近的商铺
        $nearByMerchant = \app\admin\model\merchant\Merchant::field("id, merchantname, merchantaddress, businesshours, score, logo, category_id, lng, lat")
            ->where("adminswitch", 0)
            ->where("pid", 0)
            ->where(function ($query) use ($keywords) {
                $query->where("merchantname", "like", "%$keywords%");
            })
            ->where("id", "in", $ids)
            ->select();

        foreach ($nearByMerchant as $merchant) {
            if (empty($uid)) {
                $merchant->distance = 0;
            } else {
                $merchant->distance = round($redis->geoDist($geoMerchantKey, $merchantKey.$merchant->id, $userKey.$uid, "km"), 2);
            }
        }

        $nearByMerchant = collection($nearByMerchant)->toArray();
        $key = "distance";
        usort($nearByMerchant, function($a, $b) use ($key) {
            return $a[$key] - $b[$key];
        });

        foreach ($nearByMerchant as &$merchant) {
            $item['category_name'] = Goodscategory::where("id", $merchant['category_id'])->value("goods_category_name");

            // 查找上個月的銷量
            $item['monthly_sales'] = \app\common\model\Order::where("merchant_id", $merchant['id'])
                ->where("status", OrderStatusEnum::SUCCESS_CHECK)
                ->where("createtime", ">", date("Y-m-d", strtotime("-1 month")))
                ->count();
            $item['tag'] = "Top seller";

            $isFavorite = UserFavorite::where("merchant_id", $merchant['id'])->where("user_id", $uid)->value("id");
            $merchant['logo_format']  = cdnurl($merchant['logo'], true);
            $merchant['is_favorite']  = (int)!empty($isFavorite);
            $merchant['category_name'] = $item['category_name'] ?? "";
            $merchant['monthly_sales'] = $merchant['monthly_sales'] ?? 0;
            $merchant['tag'] = $item['tag'] ?? "";

            if ($merchant['distance'] < 1) {
                $merchant['distance'] = "<1 km";
            } else {
                $merchant['distance'] = $merchant['distance'] . " km";
            }
        }

        $this->success(__("Operation completed"), $nearByMerchant);
    }

    // 收藏列表
    public function favoriteList()
    {
        $uid = $this->auth->id;

        $data = UserFavorite::where("user_id", $uid)
            ->with([
                "goods" => function ($query) {
                    return $query->field("id, merchantname, merchantaddress, businesshours, score, logo, lng, lat");
                }
            ])
            ->order("id", "desc")
            ->paginate();

        $redis = Redis::instance()->redis;
        $geoMerchantKey = config("app.geo_merchant_key");
        $merchantKey = config("app.merchant_key");
        $userKey = config("app.user_key");

        $list = [];
        foreach ($data as $item) {
            if (empty($uid)) {
                $item['distance'] = 0 . " km";
            } else {
                $item['distance'] = round($redis->geoDist($geoMerchantKey, $merchantKey.$item['merchant_id'], $userKey.$uid, "km"), 2);
                if ($item['distance'] < 1) {
                    $item['distance'] = "<1 km";
                } else {
                    $item['distance'] = $item['distance'] . " km";
                }
            }

            if (!empty($item->goods)) {
                $list [] = [
                    "merchant_id"      => $item['merchant_id'],
                    "distance"         => $item['distance'],
                    "merchant_address" => $item->goods->merchantaddress,
                    "merchant_name"    => $item->goods->merchantname,
                    "business_hours"   => $item->goods->businesshours,
                    "score"            => $item->goods->score,
                    "logo_format"      => cdnurl($item->goods->logo, true),
                    "lng"              => $item->goods->lng,
                    "lat"              => $item->goods->lat,
                ];
            }
        }

        $result['total'] = $data->total();
        $result['per_page'] = $data->listRows();
        $result['current_page'] = $data->currentPage();
        $result['last_page'] = $data->lastPage();
        $result['data'] = $list;
        $this->success(__("Operation completed"), $result);
    }

    /**
     * 商铺详情
     *
     * @return void
     */
    public function detail()
    {
        /**
         * 需要哪些信息？
         * 1. 商铺的基本信息
         * 2. 盲盒基本信息
         */
        $goodsCategoryTwoId = $this->request->param("goods_category_two_id", "0");

        $merchant = MerchantModel::find($this->request->param("merchant_id"));
        if (empty($merchant)) {
            $this->error(__("Merchant does not exist"));
        }

        $isFavorite = UserFavorite::where("merchant_id", $merchant->id)
            ->where("user_id", $this->auth->id)
            ->value("id");

        // 商品信息
        // 获取二级分类列表
        $categories = Category::field("id as goods_category_two_id, goods_category_id as goods_category_one_id, goods_category_name as goods_category_one_name")
            ->where("status", 1)
            ->where("goods_category_id", $merchant->category_id)
            ->order("sort", "desc")
            ->select();

        $goods = \app\admin\model\goods\Goods::field("id, goods_category_two_id, goodsname, coverimage, count, price, discountprice, allergyinfo, description ")
            ->where(function ($query) use ($goodsCategoryTwoId) {
                if (!empty($goodsCategoryTwoId)) {
                    $query->where("goods_category_two_id", $goodsCategoryTwoId);
                }
            })
            ->where("admin_id", $merchant->id)
            ->where("goods_category_one_id", $merchant->category_id)
            ->where("shelfswitch", 1)
            ->order("sort", "desc")
            ->select();

        // 分组
        $grouped = [];
        foreach ($goods as $item) {
            $grouped[$item->goods_category_two_id][] = [
                "goods_id"       => $item->id,
                "goods_name"     => $item->goodsname,
                "cover_image"    => cdnurl($item->coverimage, true),
                "count"          => $item->count,
                "price"          => $item->price,
                "discount_price" => $item->discountprice,
                "allergy_info"   => $item->allergyinfo,
                "description"    => $item->description
            ];
        }

        foreach ($categories as $category) {
            $category->goods = $grouped[$category->goods_category_two_id] ?? [];
        }

        $merchantCategoryName = Category::where("id", $merchant->category_id)->value("goods_category_name");;
        $result["categories"] = $categories;

        // 判断当前时间，是否在商铺营业时间内
        $isClosed = 1;
        $currentDate = date("Y-m-d");
        $closinghours = $currentDate . " " . $merchant->closinghours;
        $openinghours = $currentDate . " " . $merchant->openinghours;
        $time = time();

        if (strtotime($openinghours) < $time && $time < strtotime($closinghours)) {
            $isClosed = 0;
        }

        $result['merchant'] = [
            "merchant_id"       => $merchant->id,
            "merchant_name"     => $merchant->merchantname,
            "merchant_address"  => $merchant->merchantaddress,
            "merchant_category_name" => $merchantCategoryName,
            "business_hours"    => $merchant->businesshours,
            "score"             => $merchant->score,
            "logo_format"       => cdnurl($merchant->logo, true),
            "mobile"            => $merchant->mobile,
            "allergy_info"      => $merchant->allergyinfo,
            "lng"               => $merchant->lng,
            "lat"               => $merchant->lat,
            "is_favorite"       => (int)!empty($isFavorite),
            "is_closed"         => (int)$isClosed,
        ];

        $this->success(__("Operation completed"), $result);
    }

    /**
     * 商铺收藏
     *
     * @return void
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function favorite()
    {
        $merchantId = $this->request->param("merchant_id");
        if (empty($merchantId)) {
            $this->error(__("Merchant ID cannot be empty"));
        }

        $result = UserFavorite::where("merchant_id", $merchantId)
            ->where("user_id", $this->auth->id)
            ->find();
        if (!empty($result)) {
            $this->error(__("The merchant already exists, please do not repeat the collection"));
        }

        UserFavorite::create([
            "user_id"    => $this->auth->id,
            "merchant_id" => $merchantId
        ]);

        MerchantModel::where("id", $merchantId)
            ->inc('collectionquantity', 1)
            ->update();

        $this->success();
    }

    /**
     * 商铺取消收藏
     *
     * @return void
     */
    public function uhFavorite()
    {
        $merchantId = $this->request->param("merchant_id");
        if (empty($merchantId)) {
            $this->error(__("Merchant ID cannot be empty"));
        }

        UserFavorite::where("merchant_id", $merchantId)
            ->where("user_id", $this->auth->id)
            ->delete();

        MerchantModel::where("id", $merchantId)
            ->dec('collectionquantity', 1)
            ->update();

        $this->success();
    }
}