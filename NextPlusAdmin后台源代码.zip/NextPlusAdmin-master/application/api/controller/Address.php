<?php

namespace app\api\controller;

use app\admin\model\user\Address as AddressModel;
use app\api\validate\user\AddressValidate;
use app\common\controller\Api;
use think\Db;

/**
 * 用户地址
 *
 * Class Address
 *
 * @package app\api\controller
 */
class Address extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    /**
     * 用户地址列表
     */
    public function index()
    {
        $userId = $this->auth->id;
        $data = AddressModel::where("user_id", $userId)
            ->order("defaultswitch", "desc")
            ->order("createtime", "desc")
            ->select();
        $result = [];
        foreach ($data as $item) {
            $result[] = [
                "id"                 => $item->id,
                "user_id"            => $item->user_id,
                "name"               => $item->name,
                "mobile"             => $item->mobile,
                "location"           => $item->location,
                "is_default"         => $item->defaultswitch,
                "create_time_format" => $item->create_time_format,
                "update_time_format" => $item->update_time_format,
            ];
        }

        $this->success(__("Operation completed"), $result);
    }

    /**
     * 新增地址
     */
    public function create()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, AddressValidate::class. "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $isDefault = 0;
        $address = AddressModel::where("user_id", $userId)->select();
        if (empty($address)) {
            $isDefault = 1;
        }

        AddressModel::create([
            "user_id"       => $userId,
            "mobile"        => $params["mobile"],
            "name"          => $params["name"],
            "location"      => $params["location"],
            "defaultswitch" => $isDefault,
        ]);

        $this->success();
    }

    /**
     * 更新用户地址
     */
    public function update()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, AddressValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }
        $target = AddressModel::where("id", $params["id"])
            ->where("user_id", $userId)
            ->find();

        if (empty($target)) {
            $this->error(__("No results were found"));
        }

        $target->mobile = $params["mobile"];
        $target->name = $params["name"];
        $target->location = $params['location'];
        $target->save();

        $this->success();
    }

    /**
     * 删除用户地址
     */
    public function delete()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, AddressValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $target = AddressModel::where("id", $params["id"])
            ->where("user_id", $userId)
            ->find();

        if (empty($target)) {
            $this->error(__("No results were found"));
        }

        if ($target->defaultswitch) {
            $addressIds = AddressModel::where("id", "<>", $params['id'])
                ->where("user_id", $userId)
                ->column("id");

            if (!empty($addressIds)) {
                $id = array_pop($addressIds);
                AddressModel::where("id", $id)
                    ->update([
                        "defaultswitch" => 1,
                    ]);
            }
        }

        $target->delete();
        $this->success();
    }

    /**
     * 设置默认地址
     */
    public function setDefault()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, AddressValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }
        $target = AddressModel::where("id", $params["id"])
            ->where("user_id", $userId)
            ->find();

        if (empty($target)) {
            $this->error(__("No results were found"));
        }

        Db::startTrans();
        try {
            AddressModel::where("id", "<>", $params["id"])
                ->where("user_id", $userId)
                ->update([
                    "defaultswitch" => $target->defaultswitch
                ]);

            $target->defaultswitch ^= 1;
            $target->save();

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();

            $this->error();
        }

        $this->success();
    }
}