<?php

namespace app\api\controller;

use app\api\library\Redis;
use app\api\service\GoogleFirebaseService;
use app\api\validate\user\UserValidate;
use app\common\controller\Api;
use app\common\enum\user\CardEnum;
use app\common\library\Auth;
use app\common\library\Ems;
use app\common\library\Sms;
use app\common\model\HobbySports;
use app\common\model\SportsArea;
use app\common\model\UserInfo;
use Facebook\Facebook;
use fast\Random;
use think\Config;
use think\Db;
use think\Env;
use think\Log;
use think\Validate;

/**
 * 会员接口
 */
class User extends Api
{
    protected $noNeedLogin = ['register', 'resetpwd', 'changemobile', 'third', "registerByEmail", "loginByCode", "verifyCode", "resetPasswordByMobile", "resetPasswordByEmail", "facebookLogin", "googleLogin", "registerByMobile", "twoStepVerification", "loginByEmailOrMobilePassword", "loginByEmailOrMobileCode", "selectMobileExists", "updateLocation", "selectEmailExists"];
    protected $noNeedRight = '*';
    protected $redis = null;

    public function _initialize()
    {
        parent::_initialize();

        if (!Config::get('fastadmin.usercenter')) {
            $this->error(__('User center already closed'));
        }
        $this->redis = Redis::instance()->redis;
    }

    /**
     * 会员中心
     */
    public function index()
    {
        $userInfo = $this->getUserInfo();

        $this->success(__("Operation completed"), $userInfo);
    }

    /**
     * @return array
     */
    private function getUserInfo()
    {
        $user = $this->auth->getUser();
        $userInfo = UserInfo::where('user_id', $this->auth->id)->find();

        $userInfo = [
            "id"       => $user->id,
            "username" => $user->username,
            "nickname" => $user->nickname,
            "email"    => $user->email,
            "area_code"    => $user->area_code,
            "mobile"   => $user->mobile,
            "avatar"   => $user->avatar,
            "score"    => $user->score,
            "facebook" => $user->facebook,
            "google"   => $user->google,
            "lng"      => $user->lng,
            "lat"      => $user->lat,
            "is_set_password" => (int)!empty($user->password),
            "is_allow_promot_notify"   => $user->is_allow_promot_notify,
            "is_allow_push_notify"   => $user->is_allow_push_notify,
            "primary_account"        => $user->register_type,
        ];

        /*$userInfo['cards'] = CardMode::field("id, user_id, number, date, name, brand, country, createtime, updatetime, defaultswitch as is_default")
            ->where("user_id", $user->id)
            ->where("status", CardEnum::NORMAL)
            ->order("defaultswitch", "desc")
            ->select();

        $userInfo['address'] = AddressMode::field("id, name, mobile, location, createtime, updatetime, defaultswitch as is_default")
            ->where("user_id", $user->id)
            ->order("defaultswitch", "desc")
            ->select();*/

        return $userInfo;
    }

    /**
     * 手机号注册
     */
    public function registerByMobile()
    {
        /**
         * 注册逻辑：
         * 1. 用户填写注册表单
         * 2. 确认注册
         */
        $mobile = $this->request->post('mobile');
        $params = $this->request->param();
        $message = $this->validate($params, UserValidate::class . "." . "registerByMobile");
        if (true !== $message) {
            $this->error($message);
        }

        if ($mobile && \app\common\model\User::getByMobile($mobile)) {
            $this->error(__('Mobile already exists'));
        }

        $_result = Sms::check($mobile, $params['code'], "register");
        if ($_result !== true) {
            $this->error(__($_result));
        }

        $result = $this->auth->registerByMobile($mobile, $params);
        if ($result) {
            $data = [
                'userinfo' => $this->getUserInfo(),
                "token"    => $this->auth->getToken(),
            ];
            $this->success(__('Sign up successful'), $data);
        }

        $this->error($this->auth->getError());
    }

    /**
     * 邮箱注册
     */
    public function registerByEmail()
    {
        /**
         * 注册逻辑：
         * 1. 用户输入email，获取验证码
         * 2. 验证验证码是否正确以及未失效
         * 3. 用户输入登录密码
         * 4. 确认注册
         */
        $email = $this->request->post('email');
        $code = $this->request->post('code');
        $params = $this->request->param();
        $message = $this->validate($params, UserValidate::class . "." . "registerByEmail");
        if (true !== $message) {
            $this->error($message);
        }

        if ($email && \app\common\model\User::getByEmail($email)) {
            $this->error(__('Email is already in use'));
        }

        $_result = Ems::check($email, $code, 'register');
        if ($_result !== true) {
            $this->error(__($_result));
        }

        $result = $this->auth->registerByEmail($email, $params);
        if ($result) {
            $data = [
                'userinfo' => $this->getUserInfo(),
                "token"    => $this->auth->getToken(),
            ];
            $this->success(__('Sign up successful'), $data);
        }

        $this->error($this->auth->getError());
    }

    /**
     * 邮箱或手机号验证码登录
     *
     * @return void
     */
    public function loginByEmailOrMobileCode()
    {
        /**
         * 登录逻辑：
         * 1. 手机号或者邮箱，都可以验证码进行登录
         * 2. 如果是邮箱，则需要发送 Email
         * 3. 如果是手机，则需要通过 Firebase 发送短信
         * 2. 第二步 FireBase 短信验证
         */
        $account = $this->request->param('account');
        $code = $this->request->param('code');
        $params = $this->request->param();
        if (empty($params['validation_type'])) {
            $this->error(__("The validation type is required"));
        }

        if (!in_array($params['validation_type'], [
            "email_validation",
            "firebase_validation",
        ])) {
            $this->error(__("The validation type does not exist"));
        }

        $message = $this->validate($params, UserValidate::class . "." . "loginByEmailOrMobileCode");
        if (true !== $message) {
            $this->error($message);
        }

        /*$user = \app\common\model\User::where(function ($query) use ($account) {
            $query->where("email", $account)
                ->whereOr("mobile", $account);
        })
            ->find();
        if (!$user) {
            $this->error(__('Email or phone number does not exist'));
        }*/

        // 验证 Code
        if ($params['validation_type'] === "email_validation") {
            $_result = Ems::check($account, $code, 'emaillogin');
            if ($_result !== true) {
                $this->error(__($_result));
            }
            // Ems::flush($account, 'emaillogin');
        } else {
            /*$googleFirebase = new GoogleFirebaseService();

            if (!$googleFirebase->checkSms($code)) {
                $this->error(__('FireBase Uid is incorrect'));
            }*/

            $_result = Sms::check($account, $params['code'], "emaillogin");

            if ($_result !== true) {
                $this->error(__($_result));
            }
        }

        // 先验证 Code 是否通过
        // 查找是否用户是否已经存在
        // 如果不存在，则注册
        // 返回 Token 等信息
        $user = \app\common\model\User::where(function ($query) use ($account) {
            $query->where("email", $account)
                ->whereOr("mobile", $account);
        })
            ->find();
        if (empty($user)) {
            $ip = request()->ip();
            $time = time();

            $email = $mobile = "";
            if ( Validate::is($account, "email")) {
                $email = $account;
            } else {
                $mobile = $account;
            }

            // $salt = Random::alnum();
            // $password = $this->getEncryptPassword($params['password'], $salt);
            $data = [
                'password' => "",
                'email'    => $email,
                "area_code" => $params['area_code'] ?? null,
                "mobile"   => $mobile,
                "nickname" => $email ?: $mobile,
                "username" => $email ?: $mobile,
                'level'    => 1,
                'score'    => 0,
                'avatar'   => letter_avatar($email ?: $mobile),
                "facebook" => null,
                "google"   => null,
                "lng"      => 0,
                "lat"      => 0,
                "is_allow_promot_notify"   => 0,
                "is_allow_push_notify"   => 0,
                "register_type" => $params['validation_type'] === "email_validation" ? "email" : "mobile",
            ];
            $paramsData = array_merge($data, [
                'salt'      => "",
                'jointime'  => $time,
                'joinip'    => $ip,
                'logintime' => $time,
                'loginip'   => $ip,
                'prevtime'  => $time,
                'status'    => 'normal',
                "device"    => $params['device'] ?? "",
                "exponent_push_token" => $params['exponent_push_token'] ?? ""
            ]);
            $user = \app\common\model\User::create($paramsData, true);
        }

        $result = $this->auth->login($user, $params);
        if ($result) {
            $userinfo = $this->getUserInfo();
            $data = [
                'userinfo'           => $userinfo,
                "token"              => $this->auth->getToken(),
            ];
            $this->success(__('Logged in successful'), $data);
        }

        $this->error($this->auth->getError());
    }

    /**
     * 邮箱或手机号密码登录
     *
     * @return void
     * @throws \think\exception\DbException
     */
    public function loginByEmailOrMobilePassword()
    {
        /**
         * 登录逻辑：
         * 1. 邮箱或手机号登录
         * 2. 验证密码是否正确
         */
        $account = $this->request->post("account");
        $params = $this->request->param();

        $message = $this->validate($params, UserValidate::class . "." . "loginByEmailOrMobilePassword");
        if (true !== $message) {
            $this->error($message);
        }

        $result = $this->auth->loginByEmailOrMobilePassword($account, $params);

        if ($result) {
            $userInfo = $this->getUserInfo();
            $data = [
                'userinfo' => $userInfo,
                "token"    => $this->auth->getToken()
            ];
            $this->success(__('Logged in successful'), $data);
        }

        $this->error(__($this->auth->getError()));
    }

    /**
     * 退出登录
     * @ApiMethod (POST)
     */
    public function logout()
    {
        if (!$this->request->isPost()) {
            $this->error(__('Invalid parameters'));
        }
        $this->auth->logout();
        $this->success(__('Logout successful'));
    }

    /**
     * 修改会员个人信息
     *
     * @ApiMethod (POST)
     * @param string $avatar   头像地址
     * @param string $username 用户名
     * @param string $nickname 昵称
     * @param string $bio      个人简介
     */
    public function profile()
    {
        $user = $this->auth->getUser();
        $nickname = $this->request->post('nickname');
        $email = $this->request->post('email');
        $mobile = $this->request->post('mobile');
        $areaCode = $this->request->post('area_code', null);

        if ($email) {
            $exists = \app\common\model\User::where('email', $email)
                ->where('id', '<>', $this->auth->id)
                ->find();
            if ($exists) {
                $this->error(__('Username already exists'));
            }
            $user->email = $email;
        }

        if ($mobile) {
            $exists = \app\common\model\User::where('mobile', $mobile)
                ->where('id', '<>', $this->auth->id)
                ->find();
            if ($exists) {
                $this->error(__('Mobile already exists'));
            }
            $user->area_code = $areaCode;
            $user->mobile = $mobile;
        }
        $user->nickname = $nickname;
        $user->save();
        $this->success();
    }

    /**
     * 修改邮箱
     */
    public function changeEmail()
    {
        $user = $this->auth->getUser();
        $email = $this->request->post('email');
        $code = $this->request->post('code');
        if (!$email || !$code) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::is($email, "email")) {
            $this->error(__('Email is incorrect'));
        }
        if (\app\common\model\User::where('email', $email)->where('id', '<>', $user->id)->find()) {
            $this->error(__('Email already exists'));
        }
        $_result = Ems::check($email, $code, 'changeemail');
        if ($_result !== true) {
            $this->error(__($_result));
        }
        $verification = $user->verification;
        $verification->email = 1;
        $user->verification = $verification;
        $user->email = $email;
        $user->save();

        Ems::flush($email, 'changeemail');
        $this->success(__("Operation completed"));
    }

    /**
     * 修改基本资料
     */
    public function changeUserInfo()
    {
        $user = $this->auth->getUser();
        $params = $this->request->param();

        $user->nickname = $params['nickname'];
        $user->username = $params['username'];
        $user->mobile = $params['mobile'];
        $user->save();

        $this->success();
    }

    /**
     * 修改手机号
     *
     * @ApiMethod (POST)
     * @param string $mobile  手机号
     * @param string $captcha 验证码
     */
    public function changemobile()
    {
        $user = $this->auth->getUser();
        $mobile = $this->request->post('mobile');
        $captcha = $this->request->post('captcha');
        if (!$mobile || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error(__('Mobile is incorrect'));
        }
        if (\app\common\model\User::where('mobile', $mobile)->where('id', '<>', $user->id)->find()) {
            $this->error(__('Mobile already exists'));
        }
        $_result = Sms::check($mobile, $captcha, 'changemobile');
        if ($_result !== true) {
            $this->error($_result);
        }
        $verification = $user->verification;
        $verification->mobile = 1;
        $user->verification = $verification;
        $user->mobile = $mobile;
        $user->save();

        Sms::flush($mobile, 'changemobile');
        $this->success();
    }

    /**
     * 第三方登录
     *
     * @ApiMethod (POST)
     * @param string $platform 平台名称
     * @param string $code     Code码
     */
    public function third()
    {
        $url = url('user/index');
        $platform = $this->request->post("platform");
        $code = $this->request->post("code");
        $config = get_addon_config('third');
        if (!$config || !isset($config[$platform])) {
            $this->error(__('Invalid parameters'));
        }
        $app = new \addons\third\library\Application($config);
        //通过code换access_token和绑定会员
        $result = $app->{$platform}->getUserInfo(['code' => $code]);
        if ($result) {
            $loginret = \addons\third\library\Service::connect($platform, $result);
            if ($loginret) {
                $data = [
                    'userinfo'  => $this->auth->getUserinfo(),
                    'thirdinfo' => $result
                ];
                $this->success(__('Logged in successful'), $data);
            }
        }
        $this->error(__('Operation failed'), $url);
    }

    /**
     * 验证验证码
     */
    public function verifyCode()
    {
        $account = $this->request->param('account');
        $code = $this->request->param('code');
        $params = $this->request->param();

        if (empty($params['validation_type'])) {
            $this->error(__("The validation type is required"));
        }

        if (!in_array($params['validation_type'], [
            "email_validation",
            "firebase_validation",
        ])) {
            $this->error(__("The validation type does not exist"));
        }

        $event = $params['event'] ?? "changepwd";
        $message = $this->validate($params, UserValidate::class . "." . "loginByEmailOrMobileCode");
        if (true !== $message) {
            $this->error($message);
        }

        // 修改用户信息無需驗證
        if ($event !== "changeinfo") {
            $user = \app\common\model\User::where(function ($query) use ($account) {
                $query->where("email", $account)
                    ->whereOr("mobile", $account);
            })
                ->find();
            if (!$user) {
                $this->error(__('Email or phone number does not exist'));
            }
        }

        // 验证 Code
        if ($params['validation_type'] === "email_validation") {
            $_result = Ems::check($account, $code, $event);
            if ($_result !== true) {
                $this->error(__($_result));
            }
            // Ems::flush($account, 'changepwd');
        } else {
            $_result = Sms::check($account, $code, $event);
            if ($_result !== true) {
                $this->error(__($_result));
            }

            /*$googleFirebase = new GoogleFirebaseService();
            if (!$googleFirebase->checkSms($code)) {
                $this->error(__('FireBase Uid is incorrect'));
            }*/
        }

        $this->success();
    }

    /**
     * 通过邮箱重置密码
     */
    public function resetPasswordByEmail()
    {
        $email = $this->request->post("email");
        $password = $this->request->post("password");
        // $newPassword = $this->request->post("new_password");
        $confirmPassword = $this->request->post("confirm_password");

        if (empty($email)) {
            $this->error(__("Email can not be empty"));
        }

        if (!$password || !$confirmPassword) {
            $this->error(__("Password can not be empty"));
        }

        if (!Validate::make()->check(['password' => $password], ['password' => 'require|regex:\S{6,30}'])) {
            $this->error(__('Password must be 6 to 30 characters'));
        }

        if ($password != $confirmPassword) {
            $this->error(__("Passwords don't match"));
        }

        if (!Validate::is($email, "email")) {
            $this->error(__('Email is incorrect'));
        }
        $user = \app\common\model\User::getByEmail($email);
        if (!$user) {
            $this->error(__('User not found'));
        }

        $result = $this->auth->changepwd($user, $password, '', true);
        if ($result) {
            $this->success(__('Reset password successful'));
        }

        $this->error($this->auth->getError());
    }

    /**
     * 重置密码
     */
    public function resetPassword()
    {
        $password = $this->request->post("password", "");
        $newPassword = $this->request->post("new_password");
        $confirmPassword = $this->request->post("confirm_password");

        $user = $this->auth->getUser();
        $ignoreOldPassword = false;
        $oldPassword = "";
        if (empty($user->password)) {
            $ignoreOldPassword = true;
        } else {
            if (empty($password)) {
                $this->error(__('Old password can not be empty'));
            }
            $oldPassword = $password;
        }

        if (!$newPassword || !$confirmPassword) {
            $this->error(__('Password can not be empty'));
        }

        if (!Validate::make()->check(['password' => $newPassword], ['password' => 'require|regex:\S{6,30}'])) {
            $this->error(__('Password must be 6 to 30 characters'));
        }

        if ($newPassword != $confirmPassword) {
            $this->error(__("Passwords don't match"));
        }

        $result = $this->auth->changepwd($user, $newPassword, $oldPassword, $ignoreOldPassword);
        if ($result) {
            $this->success(__('Reset password successful'));
        }

        $this->error($this->auth->getError());
    }

    public function selectMobileExists()
    {
        $mobile = $this->request->get("mobile");
        $user = \app\common\model\User::getByMobile($mobile);

        $this->success(__("Operation completed"),[
            "is_exists" => (int)isset($user),
        ]);
    }

    public function selectEmailExists()
    {
        $email = $this->request->get("email");
        $user = \app\common\model\User::getByEmail($email);

        $this->success(__("Operation completed"),[
            "is_exists" => (int)isset($user),
        ]);
    }

    /**
     * 通过手机号重置密码
     */
    public function resetPasswordByMobile()
    {
        $mobile = $this->request->post("mobile");
        $password = $this->request->post("password");
        // $newPassword = $this->request->post("new_password");
        $confirmPassword = $this->request->post("confirm_password");

        if (empty($mobile)) {
            $this->error(__("Mobile can not be empty"));
        }

        if (!$password || !$confirmPassword) {
            $this->error(__("Password can not be empty"));
        }

        if (!Validate::make()->check(['password' => $password], ['password' => 'require|regex:\S{6,30}'])) {
            $this->error(__('Password must be 6 to 30 characters'));
        }

        if ($password != $confirmPassword) {
            $this->error(__("Passwords don't match"));
        }

        $user = \app\common\model\User::getByMobile($mobile);
        if (!$user) {
            $this->error(__('User not found'));
        }

        $result = $this->auth->changepwd($user, $password, '', true);
        if ($result) {
            $this->success(__('Reset password successful'));
        }

        $this->error($this->auth->getError());
    }

    /**
     * Facebook 第三方登录
     */
    public function facebookLogin()
    {
        /**
         * 1. 用户点击 Facebook 登录，客户端跳转 Facebook 登录授权
         * 2. 授权成功之后，携带 code 以及 state，重定向回登录页
         * 3. 客户端根据 code 以及 state，换取临时 accessToken
         * 4. 客户端将 accessToken 发送给服务端，服务端请求 Facebook Api 获取用户信息
         *
         * 如何解决请求 facebook api 超时的问题？是否能设置代理？
         * 本地调试时，可以修改 Facebook SDK 源码，手动将代理加上
         * 源码位置：vendor/facebook/graph-sdk/src/Facebook/HttpClients/FacebookCurlHttpClient.php 97 line
         * 添加内容：CURLOPT_PROXY => "127.0.0.1:7890",
         */
        $accessToken = $this->request->param("access_token");
        $params = $this->request->param();
        if (empty($accessToken)) {
            $this->error(__("Access token require"));
        }

        try {
            $fb = new Facebook([
                'app_id' => Env::get('facebook.APP_ID'),
                'app_secret' => Env::get('facebook.APP_SECRET'),
                'default_graph_version' => 'v16.0',
            ]);
            // 是否需要将临时 Token 替换成长期有效的Token？
            // $fb->getOAuth2Client()->getLongLivedAccessToken($accessToken);

            // 设置Access Token
            $fb->setDefaultAccessToken($accessToken);

            // 从Facebook 获取用户对象
            $response = $fb->get('/me?fields=name,email');
            $fbUser = $response->getDecodedBody();

            $result = Auth::instance()->loginByFacebook($fbUser, $params);
            if (!$result) {
                Log::error("登录失败：". $this->auth->getError());
                $this->error(__("Logged in failed"));
            }
        } catch(\Facebook\Exceptions\FacebookResponseException $e) {
            Log::error('Graph returned an error: ' . $e->getMessage());
            $this->error(__("Logged in failed"));
        } catch(\Facebook\Exceptions\FacebookSDKException $e) {
            Log::error('Facebook SDK returned an error: ' . $e->getMessage());
            $this->error(__("Logged in failed"));
        } catch (\Exception $e) {
            Log::error("登录失败：". $e->getMessage());
            $this->error(__("Logged in failed"));
        }

        $userinfo = $this->getUserInfo();
        $data = [
            'userinfo'           => $userinfo,
            "token"              => $this->auth->getToken(),
        ];
        $this->success(__("Logged in successful"), $data);
    }

    /**
     * Google 第三方登录
     */
    public function googleLogin()
    {
        /**
         * 1. 用户点击 Google 登录，客户端跳转 Google 登录授权
         * 2. 授权成功之后，携带 code 以及 state，重定向回登录页
         * 3. 客户端根据 code 以及 state，换取临时 accessToken
         * 4. 客户端将 accessToken 发送给服务端，服务端请求 Google Api 获取用户信息
         */
        $accessToken = $this->request->param("access_token");
        $params = $this->request->param();
        if (empty($accessToken)) {
            $this->error(__("Access token require"));
        }

        try {
            $userinfo_endpoint = 'https://openidconnect.googleapis.com/v1/userinfo';
            $userinfo_response = file_get_contents($userinfo_endpoint, false, stream_context_create([
                'http' => [
                    'method' => 'GET',
                    'header' => 'Authorization: Bearer ' . $accessToken
                ]
            ]));
            $googleUser = json_decode($userinfo_response, true);

            $result = Auth::instance()->loginByGoogle($googleUser, $params);
            if (!$result) {
                Log::error("登录失败：". $this->auth->getError());
                $this->error(__("Logged in failed"));
            }
        } catch (\Exception $e) {
            Log::error("登录失败：". $e->getMessage());
            $this->error(__("Logged in failed"));
        }

        $userinfo = $this->getUserInfo();
        $data = [
            'userinfo'           => $userinfo,
            "token"              => $this->auth->getToken(),
        ];
        $this->success(__("Logged in successful"), $data);
    }

    /**
     * @return void
     * @throws \think\exception\DbException
     */
    public function getSportsInfo()
    {
        $hobbySports = HobbySports::field("key, value")->select();
        $sportsArea = SportsArea::field("key, value")->select();

        $result = [
            "hobby_sports" => $hobbySports,
            "sports_area"  => $sportsArea
        ];

        $this->success("Operation completed", $result);
    }

    /**
     * 完善会员信息
     *
     * @return void
     */
    public function submitUserInfo()
    {
        $params = $this->request->param();
        $message = $this->validate($params, UserValidate::class . "." . "submitUserInfo");
        if (true !== $message) {
            $this->error($message);
        }

        Db::startTrans();
        try {
            $userId = $this->auth->id;
            $userInfo = UserInfo::where("user_id", $userId)->find();

            $user = \app\common\model\User::where("id", $userId)->find();
            $user->username = $params['username'];
            $user->nickname = $params['nickname'];
            $user->mobile = $params['mobile'];
            $user->is_auth_success = 1;
            $user->save();

            $params['user_id'] = $userId;
            if (empty($userInfo)) {
                UserInfo::create($params, true);
            } else {

                $userInfo->mobile = $params['mobile'];
                $userInfo->username = $params['username'];
                $userInfo->nickname = $params['nickname'];
                $userInfo->gender = $params['gender'];
                $userInfo->hobby_sport = $params['hobby_sport'];
                $userInfo->area = $params['area'];
                $userInfo->address = $params['address'];
                $userInfo->id_card_image = $params['id_card_image'] ?? "";
                $userInfo->self_portrait_image = $params['self_portrait_image'] ?? "";
                $userInfo->save();
            }
            Db::commit();
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            Db::rollback();
            $this->error();
        }

        $this->success();
    }

    // 上报用户位置
    public function updateLocation()
    {
        $params = $this->request->param();
        $userId = $this->auth->id;

        if (empty($userId)) {
            $this->success();
        }

        if (empty($params['lng']) || empty($params['lat'])) {
            $this->error("The longitude or dimension cannot be empty");
        }

        if (!Validate::between($params['lng'], [-180, 180]) || !Validate::between($params['lat'], [-90, 90])) {
            $this->error(__('Please give a reasonable latitude and longitude'));
        }

        if (empty($params['location'])) {
            $this->error(__("The location info cannot be empty"));
        }

        $user = $this->auth->getUser();
        $user->lng = $params['lng'];
        $user->lat = $params['lat'];
        $user->location = $params['location'];
        $user->save();

        $geoMerchantKey = config("app.geo_merchant_key");
        $userKey = config("app.user_key");

        $this->redis->geoAdd($geoMerchantKey, $params['lng'], $params['lat'], $userKey.$userId);
        $this->success();
    }

    /**
     * 设置允许促销通知
     *
     * @return void
     */
    public function setAllowPromotNotify()
    {
        $user = $this->auth->getUser();
        $user->is_allow_promot_notify ^= 1;
        $user->save();

        $this->success();
    }

    /**
     * 设置允许推送通知
     *
     * @return void
     */
    public function setAllowPushNotify()
    {
        $user = $this->auth->getUser();
        $user->is_allow_push_notify ^= 1;
        $user->save();

        $this->success();
    }

    /**
     * 获取密码加密后的字符串
     * @param string $password 密码
     * @param string $salt     密码盐
     * @return string
     */
    private function getEncryptPassword($password, $salt = '')
    {
        return md5(md5($password) . $salt);
    }
}
