<?php

namespace app\api\controller;

use app\admin\model\activity\Coupon;
use app\admin\model\goods\Goods;
use app\admin\model\order\Evaluate;
use app\admin\model\order\OrderRefund as OrderRefundModel;
use app\api\service\OrderService;
use app\api\service\payment\PaymentContext;
use app\api\service\payment\PaymentFactory;
use app\api\validate\order\OrderValidate;
use app\common\controller\Api;
use app\common\enum\order\OrderCancelTypeEnum;
use app\common\enum\order\OrderPaymentStatusEnum;
use app\common\enum\order\OrderRefundAuditStatusEnum;
use app\common\enum\order\OrderRefundStatusEnum;
use app\common\enum\order\OrderStatusEnum;
use app\common\model\Order as OrderModel;
use app\common\model\OrderGoods;
use app\common\model\OrderGoods as OrderGoodsModel;
use app\common\model\ShoppingCart as ShoppingCartModel;
use think\Db;
use think\Exception;
use think\Log;

class Order extends Api
{
    protected $noNeedLogin = ["stripeWebhook", "paypalExecute", "payPalWebhook", "getPendingOrder", "evaluationList", "autoCheck", "autoCancel"];

    protected $noNeedRight = '*';

    /**
     * 获取准备订单
     *
     * @return void
     */
    public function getPendingOrder()
    {
        $uid = $this->auth->id;

        $pendingOrders = \app\common\model\Order::field("id, merchant_id, title, check_code, amount, payment_amount, order_no, status, businesshours, coupon_code, coupon_price")
            ->with([
                "merchant" => function ($query) {
                    $query->field("id, merchantname, businesshours,logo");
                },
            ])
            ->where("user_id", $uid)
            ->where(function ($query) {
                $query->where("status", OrderStatusEnum::SUCCESS_PACK);
            })
            ->order("id", "desc")
            ->select();

        foreach ($pendingOrders as $pendingOrder) {
            $pendingOrder->merchant_name = $pendingOrder->merchant->merchantname;
            $pendingOrder->business_hours = $pendingOrder->merchant->businesshours;
            $pendingOrder->logo = cdnurl($pendingOrder->merchant->logo, true);
        }

        $this->success(__("Operation completed"), $pendingOrders);
    }

    /**
     * 用户订单列表
     */
    public function index()
    {
        $userId = $this->auth->id;
        $listRows = $this->request->param("listRows", 15);

        $orders = OrderModel::where("user_id", $userId)
            ->where("status", "<>", OrderStatusEnum::WAIT_USER_PAYMENT)
            ->order("id", "desc")
            ->paginate($listRows);

        $result = [];
        foreach ($orders as $order) {
            $isAllowCancel = 0;
            if ($order->status == OrderStatusEnum::USER_HAS_PAID) {
                // 两个小时内可以申请退款
                $isAllowCancel = $order->createtime + 60 * 60 * 2 < time() ? 0 : 1;
            }
            $result[] = [
                "id"                   => $order->id,
                "merchant_id"          => $order->merchant_id,
                "user_id"              => $order->user_id,
                "title"                => $order->title,
                "description"          => $order->description,
                "image"                => cdnurl($order->image, true),
                "check_code"           => $order->check_code,
                "amount"               => $order->amount,
                "payment_amount"       => $order->payment_amount,
                "coupon_code"          => $order->coupon_code,
                "coupon_price"         => $order->coupon_price,
                "order_no"             => $order->order_no,
                "status"               => $order->status,
                "businesshours"        => $order->businesshours,
                "status_mean"          => OrderStatusEnum::getOrderPaymentStatusMean($order->status),
                "payment_status"       => $order->payment_status,
                "payment_status_mean"  => OrderPaymentStatusEnum::getOrderPaymentStatusMean($order->payment_status),
                "create_time_format"   => datetime($order->createtime),
                "goods_count"          => OrderGoodsModel::where("order_id", $order->id)->sum("count"),
                "is_evaluate"          => $order->is_evaluate,
                "is_allow_cancel"      => $isAllowCancel,
            ];
        }
        $result2['total'] = $orders->total();
        $result2['per_page'] = $orders->listRows();
        $result2['current_page'] = $orders->currentPage();
        $result2['last_page'] = $orders->lastPage();
        $result2['data'] = $result;
        $this->success(__("Operation completed"), $result2);
    }

    /**
     * 订单详情
     */
    public function detail()
    {
        $userId = $this->auth->id;
        $orderId = $this->request->param("order_id");
        $order = OrderModel::where([
            'id' => $orderId,
            'user_id' => $userId
        ])
            ->find();

        if (empty($order)) {
            $this->error(__("The order does not exist, please refresh the page"));
        }

        $isAllowCancel = 0;
        if ($order->status == OrderStatusEnum::USER_HAS_PAID) {
            $isAllowCancel = $order->createtime + 60 * 60 * 2 < time() ? 0 : 1;
        }
        $orderInfo = [
            "id"                   => $order->id,
            "merchant_id"          => $order->merchant_id,
            "user_id"              => $userId,
            "order_no"             => $order->order_no,
            "image"                => cdnurl($order->image, true),
            "title"                => $order->title,
            "description"          => $order->description,
            "check_code"           => $order->check_code,
            "amount"               => $order->amount,
            "payment_amount"       => $order->payment_amount,
            "coupon_price"         => $order->coupon_price,
            "payment_type"         => $order->payment_type,
            "payment_time_format"  => datetime($order->payment_time),
            "cancel_time_format"   => datetime($order->cancel_time),
            "pack_time_format"     => datetime($order->pack_time),
            "check_time_format"    => datetime($order->check_time),
            "status"               => $order->status,
            "businesshours"        => $order->businesshours,
            "status_mean"          => OrderStatusEnum::getOrderPaymentStatusMean($order->status),
            "payment_status"       => $order->payment_status,
            "payment_status_mean"  => OrderPaymentStatusEnum::getOrderPaymentStatusMean($order->payment_status),
            "create_time_format"   => datetime($order->createtime),
            "is_evaluate"          => $order->is_evaluate,
            "is_allow_cancel"      => $isAllowCancel,
        ];

        $goods = OrderGoodsModel::field("id, goods_name, cover_image, price, count")->where("order_id", $order->id)->select();
        $orderInfo['goods'] = $goods;

        $orderInfo['merchant'] = \app\admin\model\merchant\Merchant::field("id, lng, lat, merchantname, merchantaddress, businesshours, mobile")
            ->find($order->merchant_id);
        $orderInfo['order_evaluate_info'] = Evaluate::where("order_id", $order->id)->find();

        $this->success(__("Operation completed"), $orderInfo);
    }

    /**
     * 计算折扣码价格
     */
    public function useCouponCode()
    {
        $params = $this->request->param();
        $message = $this->validate($params, OrderValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $goodsParams = $this->request->request("goods");
        if (empty($goodsParams)) {
            // 盲盒信息不存在，請重新提交
            $this->error(__("Blind box information does not exist, please resubmit"));
        }

        $goodsInfo = json_decode(htmlspecialchars_decode($goodsParams, ENT_QUOTES), true);
        if (empty($goodsInfo)) {
            // 购物车信息必须是合法的 JSON 字符串
            $this->error(__("Cart information must be a valid JSON string"));
        } else {
            foreach ($goodsInfo as $_goodsInfo) {
                $rule = [
                    'goods_id'      => 'require',
                    'goods_name'    => 'require',
                    'cover_image'   => 'require',
                    'discount_price'         => 'require',
                    'count'         => 'require',
                ];

                $message = $this->validate($_goodsInfo, $rule);
                if (true !== $message) {
                    $this->error($message);
                }

                $_goods = \app\admin\model\goods\Goods::find($_goodsInfo['goods_id']);
                if (empty($_goods)) {
                    $this->error(__("Blind box does not exist"));
                }
            }
        }

        // 计算购物车金额
        $goodsInfo = json_decode(json_encode($goodsInfo));
        $_amount = (new Cart())->calculatePrice($goodsInfo);

        $coupon = Coupon::where("code", $params['coupon_code'])
            ->find();

        if (empty($coupon)) {
            $this->error(__("Coupon does not exist"));
        } elseif ($coupon->is_used) {
            $this->error(__("The coupon has been used"));
        } elseif ($coupon->expiretime < time()) {
            $this->error(__("Coupon expired"));
        } else {
            if ($coupon->discount_amount > $_amount) {
                $this->error(__("The discount amount cannot be greater than the payment amount"));
            }

            if ($coupon->used_amount > $_amount) {
                $this->error(__("Coupon doesn't meet the minimum spend"));
            }
            $_paymentAmount = bcsub($_amount, $coupon->discount_amount, 2);
        }

        $result = [
            "amount" => $_amount,
            "payment_amount" => $_paymentAmount,
        ];

        $this->success("Operation completed", $result);
    }

    /**
     * 创建订单
     */
    public function create()
    {
        /**
         * 1. 验证请求参数
         * 2. 创建订单、创建订单商品、创建订单地址、删除购物车记录
         * 3. 请求第三方支付，创建待支付订单
         * 4. 返回订单信息、支付信息给客户端
         */
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, OrderValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $goodsParams = $this->request->request("goods");
        if (empty($goodsParams)) {
            // 盲盒信息不存在，請重新提交
            $this->error(__("Blind box information does not exist, please resubmit"));
        }

        $merchant = \app\admin\model\merchant\Merchant::find($params['merchant_id']);
        $isClosed = 1;
        $currentDate = date("Y-m-d");
        $closinghours = $currentDate . " " . $merchant->closinghours;
        $openinghours = $currentDate . " " . $merchant->openinghours;
        $time = time();

        if (strtotime($openinghours) < $time && $time < strtotime($closinghours)) {
            $isClosed = 0;
        }
        if ($isClosed) {
            $this->error(__("The merchant is closed"));
        }

        $numbers = 0;
        $description = "";
        $goodsInfo = json_decode(htmlspecialchars_decode($goodsParams, ENT_QUOTES), true);
        if (empty($goodsInfo)) {
            // 购物车信息必须是合法的 JSON 字符串
            $this->error(__("Cart information must be a valid JSON string"));
        } else {

            foreach ($goodsInfo as $_goodsInfo) {
                $rule = [
                    'goods_id'      => 'require',
                    'goods_name'    => 'require',
                    'cover_image'   => 'require',
                    'discount_price'         => 'require',
                    'count'         => 'require',
                ];

                $message = $this->validate($_goodsInfo, $rule);
                if (true !== $message) {
                    $this->error($message);
                }

                $_goods = \app\admin\model\goods\Goods::find($_goodsInfo['goods_id']);
                if (empty($_goods)) {
                    $this->error(__("Blind box does not exist"));
                }

                if ($_goods->count < $_goodsInfo['count']) {
                    $this->error(__("The number of surprise boxes are not enough"));
                }

                $description = $description . " " . $_goodsInfo['goods_name'];
                $numbers += $_goodsInfo["count"];
            }
        }

        $amount = $params["amount"];
        $paymentAmount = number_format($params["payment_amount"], 2, '.', '');

        $paymentInfo = $goods = $orderInfo = [];
        /*$cartsRecord =
            ShoppingCartModel::where("id", "in", explode(",", $cartIds))
                ->select();*/

        /*if (empty($cartsRecord)) {
            $this->error(__("Cart not found, Please add shopping cart first"));
        }*/

        // 计算购物车金额
        $goodsInfo = json_decode(json_encode($goodsInfo));
        $_amount = (new Cart())->calculatePrice($goodsInfo);

        $_paymentAmount = $_amount;
        if (!empty($params['coupon_code'])) {
            $coupon = Coupon::where("code", $params['coupon_code'])
                ->find();

            if (empty($coupon)) {
                $this->error(__("Coupon does not exist"));
            } elseif ($coupon->is_used) {
                $this->error(__("The coupon has been used"));
            } elseif ($coupon->expiretime < time()) {
                $this->error(__("Coupon expired"));
            } else {
                if ($coupon->discount_amount > $_amount) {
                    $this->error(__("The discount amount cannot be greater than the payment amount"));
                }

                if ($coupon->used_amount > $_amount) {
                    $this->error(__("Coupon doesn't meet the minimum spend"));
                }

                $_paymentAmount = bcsub($_amount, $coupon->discount_amount, 2);
                $orderInfo['coupon_code'] = $coupon->code;
                $orderInfo['coupon_price'] = $coupon->discount_amount;
            }
        }

        if (bccomp($_paymentAmount, $paymentAmount) != 0) {
            $this->error(__("The amount is abnormal, please resubmit the order"));
        }

        $orderInfo = [
            "user_id"        => $userId,
            "merchant_id"    => $params['merchant_id'],
            // "cart_ids"       => $cartIds,
            "cart_ids"       => 0,
            "order_no"       => order_no($userId),
            "check_code"     => generate_check_code(),
            "amount"         => $amount,
            "payment_amount" => $paymentAmount,
            "coupon_code"    => $coupon->code ?? "",
            "coupon_price"   => $coupon->discount_amount ?? 0,
            "payment_type"   => $params['payment_type'],
            "payment_status" => OrderPaymentStatusEnum::UNPAID,
            "status"         => OrderStatusEnum::WAIT_USER_PAYMENT,
            "businesshours"  => $merchant->businesshours,
            "image"          => $merchant->logo,
            // "title"          => $merchant->merchantname . "-". $numbers . " Blind box",
            "title"          => $merchant->merchantname,
            "description"    => trim($description),
            "commissionrate" => $merchant->commissionrate,
            "commission"     => 0,
        ];

        Db::startTrans();
        try {
            if (!empty($params['coupon_code'])) {
                // 更新優惠券為已經使用
                Coupon::where("code", $params['coupon_code'])
                    ->update([
                        "is_used" => 1,
                    ]);
            }

            $order = OrderModel::create($orderInfo);
            $paymentStrategy = PaymentFactory::strategy($params["payment_type"]);
            $paymentInfo = (new PaymentContext($paymentStrategy))->pay($order->toArray(), $params);

            if (!empty($paymentInfo['third_order_no'])) {
                $order->third_order_no = $paymentInfo['third_order_no'];
                $order->save();

                unset($paymentInfo['third_order_no']);
            }
            foreach ($goodsInfo as $record) {
                $goods[] = [
                    "merchant_id"    => $params['merchant_id'],
                    "order_id"       => $order->id,
                    "user_id"     => $userId,
                    "goods_id"    => $record->goods_id,
                    "goods_name"  => $record->goods_name,
                    "cover_image" => cdnurl($record->cover_image, true),
                    "price"       => $record->discount_price,
                    "count"       => $record->count,
                ];
            }

            (new OrderGoodsModel())->saveAll($goods);
            /*ShoppingCartModel::where("id", "in", $cartIds)
                ->update([
                    "deletetime" => time()
                ]);*/

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            Log::error("订单创建失败：" . $e->getMessage() . $e->getFile().$e->getLine());

            $this->error(__("Order creation failed").$e->getMessage());
        }

        $this->success(__("Operation completed"), [
            "order_id"       => $order->id,
            "payment_amount" => $paymentAmount,
            "payment_type"   => $params['payment_type'],
            "payment_info"   => $paymentInfo,
        ]);
    }

    /**
     * Stripe 支付回调
     */
    public function stripeWebhook()
    {
        $paymentStrategy = PaymentFactory::strategy("stripe");
        $payload = @file_get_contents('php://input');
        $headers = $this->request->header();
        $result = (new PaymentContext($paymentStrategy))->webhook($payload, $headers);
        if (!$result) {
            return response('', 400);
        }

        return response('', 200);
    }

    /**
     * Paypal 同步支付回调（订单支付确认）
     */
    public function paypalExecute()
    {
        $params = $this->request->param();
        $paymentStrategy = PaymentFactory::strategy("paypal");
        $result = (new PaymentContext($paymentStrategy))->execute($params);

        header("Content-type:text/html;charset=utf-8");
        switch ($result) {
            case "fail":
                Log::log("PayPal 支付失敗");
                Log::error("PayPal 支付失敗");
                $html = "<h2>Payment failure</h2>";
                break;
            case "cancel":
                Log::log("PayPal 支付取消");
                Log::error("PayPal 支付取消");
                $html = "<h2>Cancel payment</h2>";
                break;
            default :
                Log::log("PayPal 支付成功");
                Log::error("PayPal 支付成功");
                $html = "<h2>Payment success</h2>";
                break;
        }

        echo $html;die();
    }

    /**
     * Paypal 支付回调
     */
    public function paypalWebhook()
    {
        $paymentStrategy = PaymentFactory::strategy("paypal");
        $payload = @file_get_contents('php://input');
        $header = $this->request->header();
        $result = (new PaymentContext($paymentStrategy))->webhook($payload, $header);
        if (!$result) {
            return response('', 400);
        }

        return response('', 200);
    }

    /**
     * 申请退款
     *
     * @return void
     */
    public function applyRefund()
    {
        $uid = $this->auth->id;
        $orderId = $this->request->param("order_id");

        $order = \app\common\model\Order::where("user_id", $uid)
            ->find($orderId);

        if (empty($order)) {
            $this->error(__("The order does not exist, please refresh the page"));
        }

        // 两个小时内允许退款
        if ($order->createtime + 60 * 60 * 2 < time()) {
            $this->error(__("The order has been created for more than two hour and cannot be canceled"));
        }

        Db::startTrans();
        try {
            $paymentStrategy = PaymentFactory::strategy($order->payment_type);
            $result = (new PaymentContext($paymentStrategy))->refund($order->toArray());

            if ($result !== true) {

                Log::error("退款失败：" . $result);
                $this->error(__("Refund failed"));
            }

            $order->status = OrderStatusEnum::ORDER_CANCEL;
            $order->payment_status = OrderPaymentStatusEnum::APPLY_REFUND;
            $order->cancel_time = time();
            $order->cancel_type = OrderCancelTypeEnum::USER_CANCEL;
            $order->is_refund = 1;
            $order->save();

            // 更新店鋪盲盒庫存
            $orderGoods = OrderGoods::where("order_id", $order->id)->select();
            foreach ($orderGoods as $_orderGoods) {
                $goods = Goods::find($_orderGoods->goods_id);

                $goods->count += $_orderGoods->count;
                $goods->save();
            }

            OrderRefundModel::create([
                "order_id"     => $orderId,
                "user_id"      => $uid,
                "merchant_id"  => $order->merchant_id,
                "status"       => OrderRefundAuditStatusEnum::NO_AUDIT,
                "refundtime"   => time(),
                "refundstatus" => OrderRefundStatusEnum::SUCCESS,
            ]);

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();

            Log::error("退款失敗：". $e->getMessage());
            $this->error();
        }

        $this->success();
    }

    // 订单评价
    public function submitEvaluation()
    {
        $user = $this->auth->getUser();

        $params = $this->request->param();
        $rule = [
            'order_id'        => 'require|number',
            'score'           => 'require|number|min:1|max:5',
        ];

        $message = $this->validate($params, $rule);
        if (true !== $message) {
            $this->error($message);
        }

        $order = \app\common\model\Order::find($params['order_id']);
        if (empty($order)) {
            $this->error(__("The order does not exist, please refresh the page"));
        }

        if ($order->is_evaluate) {
            $this->error(__("Order has been evaluated, please do not repeat operation"));
        }

        if ($order->status != OrderStatusEnum::SUCCESS_CHECK) {
            $this->error(__("The order has not been check, please refresh and try again"));
        }

        Db::startTrans();
        try {
            $order->is_evaluate = 1;
            $order->save();

            // 如果评价数量超过十笔，计算平均分
            $merchant = \app\admin\model\merchant\Merchant::find($order->merchant_id);
            $count = Evaluate::where("merchant_id", $order->merchant_id)->count();
            if ($count >= 10) {
                $score = Evaluate::where("merchant_id", $order->merchant_id)->avg("score");
                $merchant->score = $score;
                $merchant->save();
            }

            Evaluate::create([
                "user_id"     => $user->id,
                "merchant_id" => $order->merchant_id,
                "nickname"    => $user->nickname,
                "order_id"    => $params['order_id'],
                "score"       => $params['score'],
                "content"     => $params['content'] ?? "",
            ]);

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();

            $this->error();
        }

        $this->success();
    }

    // 评价列表
    public function evaluationList()
    {
        $merchantId = $this->request->param("merchant_id");
        if (empty($merchantId)) {
            $this->error(__("Merchant Id Not Empty"));
        }

        $result = Evaluate::where("merchant_id", $merchantId)
            ->order("id", "desc")
            ->paginate();

        $this->success(__("Operation completed"), $result);
    }

    /**
     * @return void
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function autoCheck()
    {
        /**
         * 自動核檢
         * 1. 找出所有是Ready 状态的订单
         * 2. 标记未已核验状态
         */
        $orders = \app\common\model\Order::where(function ($query) {
            $query->where("status", OrderStatusEnum::SUCCESS_PACK);
        })
            // ->whereTime("createtime", "today")
            ->select();

        foreach ($orders as $order) {
            $order->is_auto_check = 1;
            $order->status = OrderStatusEnum::SUCCESS_CHECK;
            $order->check_time = time();
            $order->save();
        }

        $this->success();
    }

    public function autoCancel()
    {
        /**
         * 自动取消：
         * 1. 找出所有待打包的订单
         * 2. 如果创建时间已经超过两小时
         * 3. 自动取消
         */

        $orders = \app\common\model\Order::where(function ($query) {
            $query->where("status", OrderStatusEnum::USER_HAS_PAID);
        })
            ->select();

        foreach ($orders as $order) {
            if ($order->createtime + 2 * 3600 < time()) {
                Db::startTrans();
                try {
                    $paymentStrategy = PaymentFactory::strategy($order->payment_type);
                    $result = (new PaymentContext($paymentStrategy))->refund($order->toArray());

                    if ($result !== true) {
                        Log::error("退款失败：" . $result);
                        $this->error(__("Refund failed"));
                    }

                    $order->status = OrderStatusEnum::ORDER_CANCEL;
                    $order->payment_status = OrderPaymentStatusEnum::APPLY_REFUND;
                    $order->cancel_time = time();
                    $order->cancel_type = OrderCancelTypeEnum::APPLY_REFUND;
                    $order->is_refund = 1;
                    $order->save();

                    // 更新店鋪盲盒庫存
                    $orderGoods = OrderGoods::where("order_id", $order->id)->select();
                    foreach ($orderGoods as $_orderGoods) {
                        $goods = Goods::find($_orderGoods->goods_id);

                        $goods->count += $_orderGoods->count;
                        $goods->save();
                    }

                    OrderRefundModel::create([
                        "order_id"     => $order->id,
                        "user_id"      => $order->user_id,
                        "merchant_id"  => $order->merchant_id,
                        "status"       => OrderRefundAuditStatusEnum::NO_AUDIT,
                        "refundtime"   => time(),
                        "refundstatus" => OrderRefundStatusEnum::SUCCESS,
                    ]);

                    Db::commit();
                    echo "取消成功：" . $order->id;
                } catch (\Exception $e) {
                    Db::rollback();

                    Log::error("退款失敗：". $e->getMessage());
                    echo "退款失敗：" . $e->getMessage();
                    // $this->error();
                }
            }
        }

        $this->success();
    }
}