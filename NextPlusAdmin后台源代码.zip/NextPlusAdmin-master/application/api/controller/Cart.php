<?php

namespace app\api\controller;

use app\admin\model\activity\Coupon;
use app\api\validate\order\CartValidate;
use app\common\controller\Api;
use app\common\model\ShoppingCart as ShoppingCartsModel;

class Cart extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    /**
     * 购物车列表
     */
    public function index()
    {
        $merchantId = $this->request->param("merchant_id");
        $params = $this->request->param();
        $message = $this->validate($params, CartValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $userId = $this->auth->id;
        $data = ShoppingCartsModel::where("user_id", $userId)
            ->select();

        $result = [];
        foreach ($data as $item) {
            $result["list"][] = [
                "id"            => $item->id,
                "merchant_id"   => $item->merchant_id,
                "goods_name"    => $item->goods_name,
                "price"         => $item->price,
                "goods_id"      => $item->goods_id,
                "count"         => $item->count,
                "cover_image"   => cdnurl($item->cover_image, true),
            ];
        }

        $result["merchant"] = \app\admin\model\merchant\Merchant::field("id, lng, lat, merchantname, merchantaddress, businesshours, mobile")
            ->find($merchantId);
        $this->success(__("Operation completed"), $result);
    }

    /**
     * 添加购物车
     */
    public function create()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, CartValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $target = ShoppingCartsModel::where("goods_id", $params['goods_id'])
            ->where("user_id", $userId)
            ->find();
        if (!empty($target)) {
            // 如果已经存在了，数量加一
            $target->count += 1;
            $target->save();

            $this->success();
        }

        // 默认选购数量为一
        ShoppingCartsModel::create([
            "merchant_id"   => $params['merchant_id'],
            "user_id"       => $userId,
            "price"         => $params['price'],
            "goods_id"      => $params["goods_id"],
            "goods_name"    => $params["goods_name"],
            "cover_image"   => $params["cover_image"],
            "count"         => 1,
        ]);

        $this->success();
    }

    /**
     * 移除购物车
     */
    public function delete()
    {
        $userId = $this->auth->id;
        $cartIds = $this->request->param("ids");
        $data = ShoppingCartsModel::where("user_id", $userId)
            ->where("id", "in",$cartIds)
            ->select();

        if (empty($data)) {
            $this->error(__("Cart not found, Please add shopping cart first"));
        }

        ShoppingCartsModel::where("user_id", $userId)
            ->where("id", "in", $cartIds)
            ->update([
                "deletetime" => time(),
            ]);
        $this->success();
    }

    /**
     * 获取产品价格
     */
    public function getGoodsPrice()
    {
        $userId = $this->auth->id;
        $ids = $this->request->param("ids", 0);
        $code = $this->request->param("coupon_code", "");
        $deductionPrice = 0;

        if (empty($ids)) {
            $this->success(__("Operation completed"), [
                "price" => 0,
                "deduction_price" => 0,
            ]);
        }

        $carts = ShoppingCartsModel::where("id", "in", $ids)
            ->where("user_id", $userId)
            ->select();

        if (empty($carts)) {
            $this->error(__("Cart not found, Please add shopping cart first"));
        }

        $totalPrice = $this->calculatePrice($carts);

        if (!empty($code)) {
            $coupon = Coupon::where("code", $code)->find();

            if (empty($coupon)) {
                $this->error(__("Coupon not found"));
            } elseif ($coupon->is_used) {
                $this->error(__("The coupon has been used"));
            }  elseif ($coupon->expiretime < time()) {
                $this->error(__("Coupon expired"));
            } else {
                $deductionPrice = $coupon->discount_amount;
                if ($totalPrice > $coupon->used_amount) {
                    $totalPrice = bcsub($totalPrice, $deductionPrice, 2);
                } else {
                    $this->error(__("Coupon doesn't meet the minimum spend"));
                }
            }
        }

        $this->success(__("Operation completed"), [
            "price"           => $totalPrice,
            "deduction_price" => $deductionPrice,
        ]);
    }

    /**
     * 计算总价
     *
     * @param $carts
     *
     * @return int|string
     */
    public function calculatePrice($carts)
    {
        $totalPrice = 0;
        foreach ($carts as $item) {
            // 計算折扣價
            $price = bcmul($item->discount_price, $item->count);
            $totalPrice = bcadd($price, $totalPrice, 2);
        }

        return $totalPrice;
    }

    /**
     * 更新商品数量
     */
    public function updateGoodsCount()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, CartValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        if ("update" === $params['type'] && empty($params['count'])) {
            $this->error("Update count not empty");
        }

        $target = ShoppingCartsModel::where("user_id", $userId)
            ->where("id", $params['id'])
            ->find();

        if (empty($target)) {
            $this->error(__("Cart not found, Please add shopping cart first"));
        }

        switch ($params['type']) {
            case "inc":
                $target->count += 1;
                $target->save();
                break;
            case "dec":
                $target->count -= 1;
                $target->save();
                break;

            case "update":
                $target->count = (int)$params['count'];
                $target->save();
                break;
        }

        $this->success();
    }
}