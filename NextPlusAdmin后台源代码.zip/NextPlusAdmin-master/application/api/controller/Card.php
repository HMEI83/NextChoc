<?php

namespace app\api\controller;

use app\admin\model\user\Card as CardModel;
use app\api\validate\user\CardValidate;
use app\common\controller\Api;
use app\common\enum\user\CardEnum;
use think\Db;

/**
 * 用户卡包
 *
 * Class Card
 *
 * @package app\api\controller
 */
class Card extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    /**
     * 卡包列表
     *
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function index()
    {
        $userId = $this->auth->id;
        $data = CardModel::where("user_id", $userId)
            ->where("status", CardEnum::NORMAL)
            ->order("defaultswitch", "desc")
            ->order("createtime", "desc")
            ->select();
        $result = [];
        foreach ($data as $item) {
            $result[] = [
                "id"                 => $item->id,
                "user_id"            => $item->user_id,
                "number"             => $item->number,
                "date"               => $item->date,
                "name"               => $item->name,
                "brand"              => $item->brand,
                "is_default"         => $item->defaultswitch,
                "create_time_format" => $item->create_time_format,
                "update_time_format" => $item->update_time_format,
            ];
        }

        $this->success(__("Operation completed"), $result);
    }

    /**
     * 添加信用卡
     */
    public function create()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();

        $message = $this->validate($params, CardValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $exists = CardModel::where("number", $params['number'])
            ->where("user_id", $userId)
            ->find();
        if (!empty($exists)) {
            $this->error(__("Card number already exists"));
        }

        $isDefault = 0;
        $cards = CardModel::where("user_id", $userId)->select();
        if (empty($cards)) {
            $isDefault = 1;
        }

        $data = $params;
        $data['defaultswitch'] = $isDefault;
        $data['user_id'] = $userId;
        $data['status'] = CardEnum::NORMAL;
        CardModel::create($data, true);
        $this->success();
    }

    /**
     * 编辑信用卡
     */
    public function update()
    {
        $params = $this->request->param();
        $userId = $this->auth->id;

        $message = $this->validate($params, CardValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $exists = CardModel::where("number", $params['number'])
            ->where("id", "<>", $params['id'])
            ->where("user_id", "=", $userId)
            ->find();
        if (!empty($exists)) {
            $this->error(__("Card number already exists"));
        }

        $card = CardModel::where("id", $params['id'])
            ->where("user_id", $userId)
            ->find();
        if (!$card) {
            $this->error(__("No results were found"));
        }

        $card->name = $params['name'];
        $card->number = $params['number'];
        $card->date = $params['date'];
        $card->save();

        $this->success();
    }

    /**
     * 删除信用卡
     */
    public function delete()
    {
        $params = $this->request->param();
        $userId = $this->auth->id;

        $message = $this->validate($params, CardValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $card = CardModel::where("id", $params['id'])
            ->where("user_id", $userId)
            ->find();
        if (!$card) {
            $this->error(__("No results were found"));
        }

        if ($card->defaultswitch) {
            $cardIds = CardModel::where("id", "<>", $params['id'])
                ->where("user_id", $userId)
                ->column("id");

            if (!empty($cardIds)) {
                $id = array_pop($cardIds);
                CardModel::where("id", $id)
                    ->update([
                        "defaultswitch" => 1,
                    ]);
            }
        }

        $card->deletetime = time();
        $card->save();
        $this->success();
    }

    /**
     * 设置默认信用卡
     */
    public function setDefault()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, CardValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }
        $card = CardModel::where("id", $params["id"])
            ->where("user_id", $userId)
            ->find();

        if (empty($card)) {
            $this->error(__("No results were found"));
        }

        Db::startTrans();
        try {
            CardModel::where("id", "<>", $params["id"])
                ->where("user_id", $userId)
                ->update([
                    "defaultswitch" => $card->defaultswitch,
                ]);

            $card->defaultswitch ^= 1;
            $card->save();

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();

            $this->error();
        }

        $this->success();
    }
}