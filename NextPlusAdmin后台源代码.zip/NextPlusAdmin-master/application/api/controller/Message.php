<?php

namespace app\api\controller;

use app\common\controller\Api;

class Message extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    // 消息列表
    public function index()
    {
        $userId = $this->auth->id;
        $messages = \app\common\model\Message::where("user_id", $userId)
            ->order("id", "desc")
            ->select();

        $this->success("Operation completed", $messages);
    }

    /**
     * 标记已读
     */
    public function make_read()
    {
        \app\common\model\Message::where('user_id', $this->auth->id)->update([
            "is_read" => 1,
        ]);

        $this->success(__('Operation completed'));
    }
}