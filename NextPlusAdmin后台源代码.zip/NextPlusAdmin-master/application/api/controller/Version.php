<?php

namespace app\api\controller;

use app\common\controller\Api;

class Version extends Api
{
    protected $noNeedLogin = ["check"];

    protected $noNeedRight = ['*'];

    // 版本检测
    public function check()
    {
        $params = $this->request->param();
        $rule = [
            'platform'        => 'require',
            'version'         => 'require',
        ];

        $message = $this->validate($params, $rule);
        if (true !== $message) {
            $this->error($message);
        }

        $version = \app\common\model\Version::where('platform', $params['platform'])
            ->order('id', 'desc')
            ->limit(1)
            ->find();

        //匹配信息
        $isUpdate = 0;
        $url = '';
        $versionLog = '';
        $isForce = 0;
        $ver = '';
        if ($version) {
            $versionLog = $version->content;
            $isForce = $version->enforceswitch;
            $ver = $version->newversion;
            if ($params['version'] < $version->newversion) {
                // 新版本信息
                $isUpdate = 1;
                $url = $version->downloadurl;
            } else {

            }
        }
        $result = [
            'is_update'    => $isUpdate,
            'url'          => $url,
            'version_log'  => $versionLog,
            'is_force'     => $isForce,
            'version'      => $ver,
        ];

        $this->success(__("Operation completed"), $result);
    }
}