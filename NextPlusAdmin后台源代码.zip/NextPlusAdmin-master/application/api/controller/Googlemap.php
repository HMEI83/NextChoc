<?php

namespace app\api\controller;

use app\common\controller\Api;
use think\Request;
use think\Validate;

use function fast\e;

/**
 * Google Map
 */
class GoogleMap extends Api
{
    protected $noNeedLogin = ["latlng2placeId", "latlng2placeIdForBaidu"];

    protected $noNeedRight = '*';

    /**
     * @var mixed Google Map Key
     */
    private $googleMapKey;

    /**
     * @var mixed
     */
    private $queryAutoCompleteUrl;

    /**
     * @link https://developers.google.com/maps/documentation/geocoding?hl=zh-cn
     * @var mixed 地理编码 API
     */
    private $geocodeUrl;

    /**
     * @var mixed Redis User Key
     */
    private $userKey;

    public function __construct(Request $request = null)
    {
        $this->queryAutoCompleteUrl = config("google_map_api.query_autocomplete");
        $this->googleMapKey = config('google_map_api.key');
        $this->geocodeUrl = config("google_map_api.geocode_url");

        parent::__construct($request);
    }

    /**
     * 地址搜索自动补全
     *
     * @return void
     */
    public function queryAutoCompleted()
    {
        $keywords = $this->request->get('keywords');
        if (empty($keywords)) {
            $this->error(__("Keyword cannot be empty"));
        }

        $url = $this->queryAutoCompleteUrl;
        $params = [
            "input" => $keywords,
            "language" => "en",
            "key" => $this->googleMapKey,
        ];
        $url .= "?" . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
        $result = curl_get($url);

        if (empty($result)) {
            $this->error(__('Google interface call failed'));
        }

        $result = json_decode($result, true);
        $data = [];
        if (isset($result['status']) && $result['status'] == 'OK') {
            $data = $result['predictions'];
        }

        $this->success(__('Operation completed'), $data);
    }

    /**
     * 地点ID逆编码
     */
    public function placeId2latlng()
    {
        $placeId = $this->request->get("place_id");
        if (empty($placeId)) {
            $this->error(__("Place Id cannot be empty"));
        }

        $geocodeUrl = $this->geocodeUrl . "?place_id={$placeId}&key=" . $this->googleMapKey;
        $result = json_decode(curl_get($geocodeUrl), true);
        if (isset($result['error'])) {
            $this->error($result['error']['message']);
        }

        if (isset($result['results'][0])) {
            $this->success("Operation completed", [
                "lat" => $result['results'][0]['geometry']['location']['lat'],
                "lng" => $result['results'][0]['geometry']['location']['lng'],
            ]);
        }
        $this->error(__("Inverse encoding of latitude and longitude failed"));
    }

    /**
     * 经纬度逆编码
     */
    public function latlng2placeId()
    {
        $params = $this->request->get();
        if (empty($params['lng']) || empty($params['lat'])) {
            $this->error(__('Lack of latitude and longitude'));
        }
        if (!Validate::between($params['lng'], [-180, 180])
            || !Validate::between($params['lat'], [-90, 90])
        ) {
            $this->error(__('The latitude and longitude are out of operation range'));
        }

        $geocodeUrl = $this->geocodeUrl
            . "?latlng={$params['lat']},{$params['lng']}&key="
            . $this->googleMapKey;
        $result = json_decode(curl_get($geocodeUrl), true);
        if (isset($result['error'])) {
            $this->error($result['error']['message']);
        }

        if (isset($result['results'])) {
            $this->success("Operation completed", $result['results']);
        }
        $this->error(__("Inverse encoding of latitude and longitude failed"));
    }

    /**
     * 经纬度逆编码
     */
    public function latlng2placeIdForBaidu()
    {
        $params = $this->request->get();
        if (empty($params['lng']) || empty($params['lat'])) {
            $this->error(__('Lack of latitude and longitude'));
        }
        if (!Validate::between($params['lng'], [-180, 180])
            || !Validate::between($params['lat'], [-90, 90])
        ) {
            $this->error(__('The latitude and longitude are out of operation range'));
        }

        $data = [
            "ak" => "Spf8bl78j95wMfRHxMd4RWR6Th4edGNP",
            "output" => "json",
            "coordtype" => "wgs84ll",
            "location" => "{$params['lat']},{$params['lng']}",
        ];
        $geocodeUrl = "https://api.map.baidu.com/reverse_geocoding/v3/?" . http_build_query($data);
        $result = json_decode(curl_get($geocodeUrl), true);

        if ($result['status'] != 0) {
            $this->error(__("Baidu interface call failed"));
        }

        $formattedAddress = $result['result']['formatted_address'];
        // 使用 explode 函数将字符串按逗号分割成数组
        $addressParts = explode(',', $formattedAddress);
        // 获取数组长度
        $length = count($addressParts);
        // 判断数组长度是否大于等于2
        if ($length >= 2) {
            // 从右往左截取第二个逗号左边的内容
            $result['result']['formatted_address_short'] = implode(',', array_slice($addressParts, 0, $length - 2));
        } else {
            // 如果数组长度小于2，则直接使用原始的 formatted_address
            $result['result']['formatted_address_short'] = $formattedAddress;
        }

        $this->success(__("Operation completed"), $result['result']);
    }


}