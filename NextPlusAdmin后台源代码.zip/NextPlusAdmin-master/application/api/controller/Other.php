<?php

namespace app\api\controller;

use app\common\controller\Api;
use think\Config;

class Other extends Api
{
    protected $noNeedLogin = ["getHandbook", "getPlatformInfo"];

    protected $noNeedRight = '*';

    // 獲取隱私政策/服務條款
    public function getHandbook()
    {
        $id = $this->request->param("id");
        if (empty($id)) {
            $this->error("id 不能為空");
        }

        $result = \app\admin\model\other\Handbook::find($id);

        $this->success(__("Operation successful"), $result);
    }

    // 獲取平台信息
    public function getPlatformInfo()
    {
        $result["company_address"] = Config::get("site")['company_address'];
        $result["company_contact_info"] = Config::get("site")['company_contact_info'];

        $this->success(__("Operation successful"), $result);
    }
}