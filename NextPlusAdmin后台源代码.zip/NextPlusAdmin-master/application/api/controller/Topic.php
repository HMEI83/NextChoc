<?php

namespace app\api\controller;

use app\api\validate\topic\TopicValidate;
use app\common\controller\Api;
use app\admin\model\topic\Comment;
use app\admin\model\topic\Topic as TopicModel;

/**
 * Class Topic
 *
 * @package app\api\controller
 */
class Topic extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    // 话题列表
    public function index()
    {
        /**
         * 话题列表有三种展示逻辑：
         * 1. 最新话题：所有帖子按发布时间倒序排序
         * 2. 我的话题：我的话题按发布时间倒序排序
         * 3. 最热门：所有帖子按热度值倒序排序
         */
        $sortType = $this->request->param("sort_type");
        if (empty($sortType)) {
            $this->error(__("Sort type require"));
        }

        $userId = $this->auth->id;
        $order = "desc";
        $sort = "createtime";
        $where["hiddenswitch"] = ["=", "0"];
        switch ($sortType) {
            case "latest_topic":

                break;
            case "my_topic";
                $where["user_id"] = ["=", $userId];
                break;

            case "hot_topic";
                $sort = "heat";
                break;
        }

        $data = TopicModel::where($where)
            ->order($sort, $order)
            ->select();

        $result = [];
        foreach ($data as $item) {
            $recentCommentsUser = "-";
            // todo 待优化
            $commentUser = Comment::where("topic_id", $item->id)
                ->order("id", "desc")
                ->limit(1)
                ->find();
            if (!empty($commentUser)) {
                $recentCommentsUser = \app\admin\model\User::where("id", $commentUser->user_id)->value("username");
            }
            $result[] = [
                "id"                    => $item->id,
                "user_id"               => $item->user_id,
                "username"              => $item->username,
                "title"                 => $item->title,
                "content"               => $item->content,
                "comment_count"         => $item->commentcount,
                "view_count"            => $item->viewcount,
                "create_time_format"    => $item->create_time_format,
                "update_time_format"    => $item->update_time_format,
                "human_date"            => human_date($item->createtime),
                // 最近评论用户
                "recent_comments_user"  => $recentCommentsUser,
                "status"                => $item->status,
            ];
        }

        $this->success(__("Operation completed"), $result);
    }

    /**
     * 评论详情
     */
    public function detail()
    {
        $id = $this->request->param("id");
        $userId = $this->auth->id;
        $target = TopicModel::with([
            'hasComment' => function ($query) {
                $query->field(["*"]);
            },
        ])
            ->find($id);

        $target->viewcount += 1;
        $target->save();

        $redis = new \app\api\library\Redis();
        $prefix = "topic:".$id;
        $comments = [];
        foreach ($target->hasComment as $comment) {
            $value = "comment:".$comment->id."user:".$userId;

            $content = $comment->content;
            if (!empty($comment->at_user_id)) {
                $atUser = \app\common\model\User::find($comment->at_user_id);

                $content = "@$atUser->username " . $comment->content;
            }
            $comments[] = [
                "id"                 => $comment->id,
                // 是否是自己的评论
                "is_self"            => (int)($userId == $comment->user_id),
                "user_id"            => $comment->user_id,
                "username"           => $comment->username,
                "topic_id"           => $comment->topic_id,
                "content"            => $content,
                "like_count"         => $comment->likecount,
                // 当前评论是否点过赞
                "is_like"            => (int)$redis->sIsMember($prefix, $value),
                "create_time_format" => $comment->create_time_format,
                "update_time_format" => $comment->update_time_format,
                "status"                => $comment->status
            ];
        }

        $result = [
            "id"                 => $target->id,
            "user_id"            => $target->user_id,
            "username"           => $target->username,
            "title"              => $target->title,
            "content"            => $target->content,
            "comment_count"      => $target->commentcount,
            "view_count"         => $target->viewcount,
            "create_time_format" => $target->create_time_format,
            "update_time_format" => $target->update_time_format,
            "human_date"         => human_date($target->createtime),
            "comments"           => $comments,
            "status"                => $target->status
        ];

        $this->success(__("Operation completed"), $result);
    }

    /**
     * 创建话题
     */
    public function create()
    {
        $userId = $this->auth->id;
        $user = $this->auth->getUser();
        $params = $this->request->param();
        $message = $this->validate($params, TopicValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        TopicModel::create([
            "user_id" => $userId,
            "username" => $user->username,
            "title" => $params['title'],
            "content" => $params["content"],
        ]);

        $this->success();
    }

    /**
     * 更新话题
     */
    public function update()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, TopicValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $target = TopicModel::where("user_id", $userId)->find($params["id"]);
        if (empty($target)) {
            $this->error(__("No results were found"));
        }

        $target->title = $params['title'];
        $target->content = $params['content'];
        $target->save();

        $this->success();
    }

    /**
     * 删除话题
     */
    public function delete()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $target = TopicModel::where("user_id", $userId)->find($params["id"]);
        if (empty($target)) {
            $this->error(__("No results were found"));
        }

        $target->delete();
        $this->success();
    }
}