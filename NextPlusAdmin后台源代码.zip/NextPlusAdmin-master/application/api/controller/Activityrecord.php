<?php

namespace app\api\controller;

use app\api\library\Redis;
use app\common\controller\Api;
use app\common\model\HobbySports;
use app\common\model\SportsArea;
use app\common\model\UserInfo;
use think\Db;
use think\Request;
use think\Validate;

class Activityrecord extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    protected $redis = null;

    public function __construct(Request $request = null)
    {
        $this->redis = Redis::instance()->redis;

        parent::__construct($request);
    }

    // 附近的会员
    public function nearby()
    {
        /**
         * 1. 获取我当前的位置
         * 2. 找出附近 N 公里之内的会员
         * 3. 根据他们的坐标，在地图上标记出来
         * 4. 点击标记点，展示会员信息
         */
        $params = $this->request->param();

        if (empty($params['lng']) || empty($params['lat'])) {
            $this->error(__("The longitude or dimension cannot be empty"));
        }

        if (!Validate::between($params['lng'], [-180, 180]) || !Validate::between($params['lat'], [-90, 90])) {
            $this->error(__('Please give a reasonable latitude and longitude'));
        }

        // 附近五公里的用户
        $userIds = $this->redis->geoRadius("themonk_user_location", $params['lng'], $params['lat'], 100, 'km');

        $users = \app\admin\model\User::field("id, lng, lat")
            ->where("id", "<>", $this->auth->id)
            ->where("id", "in", $userIds)
            // 完善了信息才用户才会返回
            ->where("is_auth_success", 1)
            ->select();

        $result = [];
        foreach ($users as $user) {
            $result[] = [
                "user_id" => $user->id,
                "lng" => $user->lng,
                "lat" => $user->lat
            ];
        }

        $this->success(__("Operation completed"), $result);
    }

    // 今日邀约记录
    public function index()
    {
        $userId = $this->auth->id;
        $type = $this->request->param('type');

        // 区分我的邀约、我被邀约
        $data = \app\common\model\ActivityRecord::where(function ($query) use ($type) {
                if ($type === "today") {
                    $query->where("date", date("Y-m-d"));
                }
            })
            ->where(function ($query) use ($userId) {
                $query->where("user_id", $userId)
                    ->whereOr("invitee_id", $userId);
            })
            ->order("time", "desc")
            ->select();

        $hobbySports = collection(HobbySports::select())->column("value", "key");
        foreach ($data as $item) {
            $gender = UserInfo::where("user_id", $item->user_id)->value("gender");

            $item->gender = $gender === "man" ? "男" : "女";
            $item->sport = $hobbySports[$item->sport];
            // 是否是我的邀请:1.我的邀请，0.邀请我的
            $item->is_my_invited = (int)($item->user_id == $userId);
            // 是否评价
            $item->is_evaluation = (int)!empty($item->evaluation);
        }

        $this->success(__("Operation completed"), $data);
    }

    // 邀约详情
    public function detail()
    {
        $userId = $this->request->param("invitee_id");

        if (empty($userId)) {
            $this->error(__("Invitee id cannot be empty"));
        }
        $result = [];

        // 被邀请者，一定是完善了信息，才会出现
        $user = \app\common\model\User::find($userId);
        $userInfo = \app\common\model\UserInfo::where("user_id", $userId)->find();

        $activityRecords = \app\common\model\ActivityRecord::field("sport, handle")
            ->where("invitee_id", $userId)
            ->select();

        $hobbySports = collection(HobbySports::select())->column("value", "key");
        $sportArea = collection(SportsArea::select())->column("value", "key");
        $result["user_info"] = [
            "hobby_sport"     => collection(explode(",", $userInfo->hobby_sport))->each(function ($item) use ($hobbySports) {
                return $hobbySports[$item];
            }),
            "area"            => collection(explode(",", $userInfo->area))->each(function ($item) use ($sportArea) {
                return $sportArea[$item];
            }),
            "gender"          => $userInfo->gender === "man" ? "男" : "女",
            "username"        => $userInfo->username,
            "score"           => $user->score,
            "user_id"         => $user->id,
        ];

        // 按运动分组，统计各状态数量
        $grouped = [];
        foreach ($activityRecords as $activityRecord) {
            $grouped[$activityRecord->sport][] = [
                "sport"  => $activityRecord->sport,
                "handle" => $activityRecord->handle,
            ];
        }

        foreach ($grouped as $value) {
            $acceptCount = 0;
            $refuseCount = 0;
            collection($value)->each(function ($value) use (&$acceptCount, &$refuseCount) {
                if ($value['handle'] === "accept") {
                    $acceptCount += 1;
                } elseif ($value['handle'] === "refuse") {
                    $refuseCount += 1;
                }
            });

            $result["activity_records"][] = [
                "sport"        => $hobbySports[$activityRecord->sport],
                "accept_count" => $acceptCount,
                "refuse_count" => $refuseCount,
            ];
        }

        $this->success(__("Operation completed"), $result);
    }

    // 评分（邀请者给被邀请者评分）
    public function evaluation()
    {
        // 判断一下是否在合理的时间范围内
        $params = $this->request->param();
        $message = $this->validate($params, \app\api\validate\ActivityRecord::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $score = (int)$params['score'];
        if ($score > 5 or $score < 1) {
            $this->error(__("Score must be between 1 and 5c"));
        }

        $activityRecord = \app\common\model\ActivityRecord::find($params['id']);
        if (empty($activityRecord)) {
            $this->error(__("Activity record not found"));
        }

        if ($activityRecord->handle != "accept") {
            $this->error(__("You can only rate activities you accept"));
        }

        // 只能给自己创建的活动进行评分
        if ($activityRecord->user_id != $this->auth->id) {
            $this->error(__("You can only rate activities you create"));
        }

        Db::startTrans();
        try {
            $activityRecord->score = $params['score'];
            $activityRecord->save();

            // 计算被邀请者的平均得分
            $avgScore = round(\app\common\model\ActivityRecord::where('invitee_id', $activityRecord->invitee_id)
                ->where('handle', "accept")
                ->where("score", "<>", 0)
                ->avg('score'));

            \app\common\model\User::where("id", $activityRecord->invitee_id)
                ->update([
                    "score" => $avgScore,
                ]);

            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            $this->error(__("Operation failed"));
        }

        $this->success();
    }

    // 创建邀约
    public function create()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, \app\api\validate\ActivityRecord::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $user = $this->auth->getUser();
        if (!$user->is_auth_success) {
            $this->error(__("Please improve the user information first"));
        }

        Db::startTrans();
        try {
            // 判断时间段内是否已经存在邀约

            $inviteeUserInfo = \app\common\model\User::find($params['invitee_id']);

            $data = [
                "user_id" => $userId,
                "sport"   => $params['sport'],
                "date"    => $params['date'],
                "time"    => $params['time'],
                "waiting_time" => $params['waiting_time'] . " hours",
                'address' => $params['address'],
                "invitee_id" => $params['invitee_id'],
                "invitee_username" => $inviteeUserInfo['username'],
                "handle"   => "waiting",
            ];

            $activityRecord = \app\common\model\ActivityRecord::create($data);
            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            $this->error(__("Failed to create an offer"));
        }

        $this->success();
    }

    // 轮询查找是否存在邀约记录
    public function select()
    {
        $userId = $this->auth->id;
        $result = \app\common\model\ActivityRecord::where("invitee_id", $userId)
            ->order("date", "asc")
            ->order("time", "asc")
            ->where("handle", "waiting")
            ->select();

        $this->success(__("Operation completed"), $result);
    }

    // 接受/拒绝邀约
    public function handle()
    {
        $params = $this->request->param();
        $message = $this->validate($params, \app\api\validate\ActivityRecord::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        if (!in_array($params['type'], ["accept", "refuse"])) {
            $this->error(__("Invalid parameter"));
        }

        $activityRecord = \app\common\model\ActivityRecord::find($params['id']);
        if (empty($activityRecord)) {
            $this->error(__("Activity record not found"));
        }

        if ($activityRecord->handle != "waiting") {
            // 你只能对等待的活动进行操作
            $this->error(__("You can only operate on activities that wait"));
        }

        $activityRecord->handle = $params['type'];
        $activityRecord->save();
        $this->success();
    }
}