<?php

namespace app\api\controller;

use app\api\validate\GoodsValidate;
use app\common\controller\Api;
use app\common\model\ActivityInfo;
use app\common\model\GoodsComment;

class Goods extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    /**
     * 商品列表
     */
    public function index()
    {
        $sortType = $this->request->param("sort_type");
        $type = $this->request->param("type", 0);

        $order = "desc";
        $sort = "createtime";

        switch ($sortType) {
            // 最新产品
            case "new_goods":
                break;

            // 最受欢迎
            case "hot_goods";
                $sort = "order_count";
                break;

            // 最新推广
            case "new_promotion";
                $sort = "sort";
                break;
        }

        $data = \app\admin\model\Goods::order($sort, $order)
            ->where(function ($query) use ($type) {
                if (!empty($type)) {
                    $query->where("type", $type);
                }
            })
            ->select();

        // 分组
        $grouped = [
            "fitness_equipment" => [],
            "course" => [],
            "activity_info" => [
                "title"       => "最新優惠",
                "description" => "每次購物滿 $500 可減 $20",
                "link"        => "https://www.baidu.com",
            ],
        ];
        $map = [
            1 => "fitness_equipment",
            2 => "course",
        ];
        foreach ($data as $item) {
            $grouped[$map[$item->type]][] = $item;
        }

        $this->success("Operation completed", $grouped);
    }

    /**
     * 商品详情
     */
    public function detail()
    {
        $id = $this->request->param("id");
        $params = $this->request->param();
        $message = $this->validate($params, GoodsValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $goods = \app\admin\model\Goods::with("hasComment")
            ->where("id", $id)
            ->find();

        if (empty($goods)) {
            $this->error("Goods not found");
        }

        $this->success("Operation completed", $goods);
    }

    /**
     * 发表评论
     *
     * @return void
     */
    public function comment()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, GoodsValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        GoodsComment::create([
            "goods_id" => $params['id'],
            "user_id"  => $userId,
            "content"  => $params['content'],
        ]);

        $this->success();
    }
}