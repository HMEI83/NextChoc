<?php

namespace app\api\controller;

use app\admin\command\Addon;
use app\admin\model\balnace\Systembalancelog;
use app\admin\model\User;
use app\common\controller\Api;
use fast\Date;
use Google\Auth\OAuth2;
use GuzzleHttp\Psr7\Request;
use think\console\Command;
use think\Env;
use think\exception\HttpResponseException;
use think\Hook;
use think\Log;
use Facebook\FacebookRequest;
use think\Response;

use Automattic\WooCommerce\Client;
use Contributte\Invoice\Preview\PreviewFactory;
use Contributte\Invoice\Templates\ParaisoTemplate;
use Contributte\Invoice\Data\Account;
use Contributte\Invoice\Data\Company;
use Contributte\Invoice\Data\Customer;
use Contributte\Invoice\Data\Order;
use Contributte\Invoice\Data\PaymentInformation;
use Contributte\Invoice\Data\Timestamps;
use Konekt\PdfInvoice\InvoicePrinter;


/**
 * 示例接口
 */
class Demo extends Api
{

    //如果$noNeedLogin为空表示所有接口都需要登录才能请求
    //如果$noNeedRight为空表示所有接口都需要验证权限才能请求
    //如果接口已经设置无需登录,那也就无需鉴权了
    //
    // 无需登录的接口,*表示全部
    protected $noNeedLogin = ["*"];
    // 无需鉴权的接口,*表示全部
    protected $noNeedRight = ['test2'];

    /**
     * 测试方法
     *
     * @ApiTitle    (测试名称)
     * @ApiSummary  (测试描述信息)
     * @ApiMethod   (POST)
     * @ApiRoute    (/api/demo/test/id/{id}/name/{name})
     * @ApiHeaders  (name=token, type=string, required=true, description="请求的Token")
     * @ApiParams   (name="id", type="integer", required=true, description="会员ID")
     * @ApiParams   (name="name", type="string", required=true, description="用户名")
     * @ApiParams   (name="data", type="object", sample="{'user_id':'int','user_name':'string','profile':{'email':'string','age':'integer'}}", description="扩展数据")
     * @ApiReturnParams   (name="code", type="integer", required=true, sample="0")
     * @ApiReturnParams   (name="msg", type="string", required=true, sample="返回成功")
     * @ApiReturnParams   (name="data", type="object", sample="{'user_id':'int','user_name':'string','profile':{'email':'string','age':'integer'}}", description="扩展数据返回")
     * @ApiReturn   ({
         'code':'1',
         'msg':'返回成功'
        })
     */
    public function test()
    {



        $header = $this->request->header();

        var_dump($header);
        exit();

        $gateway = new \Braintree\Gateway([
            // 'accessToken' => Env::get("paypal.ACCESS_TOKEN"),
            "merchantId" => Env::get("paypal.MERCHANT_ID"),
            "publicKey" => Env::get("paypal.PUBLIC_KEY"),
            "privateKey" => Env::get("paypal.PRIVATE_KEY"),
            "environment" => "sandbox",
        ]);
        // 服务器生成客户端令牌
        // $clientToken = $gateway->clientToken()->generate();

        // 接受来自客户端的paymentMethodNonce，表示客户端的付款授权
        // $nonce = $this->request->param("payment_method_nonce");
        $params = $this->request->param();

        $result = $gateway->transaction()->sale([
            "amount" => "123",
            // 'merchantAccountId' => 'USD',
            "paymentMethodNonce" => "fake-valid-nonce",
            // 'deviceData' => $params['device_data'],
            "options" => [
                "submitForSettlement" => true,
                /*"paypal" => [
                    // "customField" => $params["PayPal custom field"],
                    // "description" => $params["Description for PayPal email receipt"]
                ],*/
            ]
        ]);
        if ($result->success) {
            // $this->success('操作成功', $result->transaction->id);
            return json([
                'success' => $result->success,
                "result"  => $result
            ]);
        } else {
            $this->error("操作失败", $result->message);
        }


        // $this->success('返回成功', $this->request->param());
    }

    /**
     * 无需登录的接口
     *
     */
    public function test1()
    {

        $stripe = new \Stripe\StripeClient(
            'sk_test_51MZ9eKLvi7RvipiD9UMssJHolFBPP0fbuXBMOuXM1sNpE1l44lcQWColupr2gRnbmggyi27Zdb3XgBYB2kcxXQFu006WsBEOI9'
        );
        // 创建一个新的 Customer 对象
        //$customer = $stripe->customers->create();

        $result = $stripe->customers->createSource(
            // $customer->id,
            "cus_NW3lOItYIhbPQ1",
            [
                'source' => "tok_visa"
            ]
        );

        /*$result = $stripe->customers->createSource(
        // $customer->id,
            "cus_NW3lOItYIhbPQ1",
            [
                'source' => "tok_visa",
            ]
        );*/

        $this->success('返回成功', $result);
    }

    /**
     * 需要登录的接口
     *
     */
    public function test2()
    {
        // Replace with your own client ID and secret obtained from the Google API Console
        $client_id = '902486661089-v5i5f1m51u2bb45dap3g9i59p911mdpk.apps.googleusercontent.com';
        $client_secret = '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';

        /*// Replace with the redirect URI that you registered in the Google API Console
        $redirect_uri = 'https://yourdomain.com/callback.php';

        // Google OAuth 2.0 endpoint for exchanging an authorization code for an access token
        $token_endpoint = 'https://oauth2.googleapis.com/token';

        // Get the authorization code from the query parameters
        $code = $_GET['code'];


        $response = file_get_contents($token_endpoint, false, stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/x-www-form-urlencoded',
                'content' => http_build_query([
                    'client_id' => $client_id,
                    'client_secret' => $client_secret,
                    'redirect_uri' => $redirect_uri,
                    'grant_type' => 'authorization_code',
                    'code' => $code
                ])
            ]
        ]));


        // Parse the access token and other information from the response
        $data = json_decode($response, true);
        $access_token = $data['access_token'];
        $expires_in = $data['expires_in'];
        $refresh_token = $data['refresh_token'];*/

        $userinfo_endpoint = 'https://openidconnect.googleapis.com/v1/userinfo';
        $userinfo_response = file_get_contents($userinfo_endpoint, false, stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => 'Authorization: Bearer ' . $access_token
            ]
        ]));
        $userinfo_data = json_decode($userinfo_response, true);


        echo 'Hello, ' . $userinfo_data['name'] . '! Your email address is ' . $userinfo_data['email'] . '.';

        // $this->success(__("Operation completed"), ['action' => $users]);
    }

    public function timezone()
    {
        var_dump(date("Y-m-d H:i:s", time()));
        var_dump(date_default_timezone_get());
        var_dump(strtotime("2023-09-01 00:00:00"));
        exit();
    }

    /**
     * 需要登录且需要验证有相应组的权限
     *
     */
    public function test3()
    {
        $string = iconv("UTF-8", "ISO-8859-1//TRANSLIT", "hello");
        // $string = mb_convert_encoding("你好", "UTF-8", "ISO-8859-1");
        $this->success("ok", $string);



        /*$woocommerce = new Client(
            'http://43.139.12.144',
            'ck_93970d93541e59ba90f239557fea1435ed9077f6',
            'cs_833885b0abd6023ffa119c7fbc2a9aa3ec8dfa07',
            [
                "wp_api"  => true,
                'version' => 'wc/v3',
            ]
        );*/

        $invoice = new InvoicePrinter();


        /* Header settings */
        $invoice->setLogo(ROOT_PATH."/public/firebase/logo.png");   // logo 位置
        $invoice->setColor("#007fff");      // pdf 颜色
        $invoice->setType("Sale Invoice");    // 发票类型
        $invoice->setReference("INV-55033645");   // 发票单号
        $invoice->setDate(date('M dS ,Y',time()));   // 账单日期
        $invoice->setTime(date('h:i:s A',time()));   // 账单时间
        $invoice->setDue(date('M dS ,Y',strtotime('+3 months')));    // 到期日期
        // 设置来源，
        $invoice->setFrom(array("Seller Name", "志程食品批發有限公司", "新界屯門業旺路8號聯昌中心", "14樓1401,1403室 , 送貨時間：9:00-5:00"));
        $invoice->setTo(array("Purchaser Name", "浩俊國際貿易有限公司","新界荃灣柴灣角街30-32號京華工廠貨倉大廈"," , 12樓A室"));

        // $invoice->setFrom(array("Seller Name","Sample Company Name","128 AA Juanita Ave","Glendora , CA 91740"));
        // $invoice->setTo(array("Purchaser Name","Sample Company Name","128 AA Juanita Ave","Glendora , CA 91740"));

        // 设置 item
        $invoice->addItem("10KG日本(熟)9售-八爪鱼足刺身(2箱1扎)","天荣物流 嘉威 112417*9p",1,0,82.00,0,82.00);
        $invoice->addItem("OCEAN KING”澳南美白嫂仁31-40 (QF)","天荣物流 嘉威 114367*",2,0,25.20,0,50.40);
        $invoice->addItem('OCEAN KING”澳南美白媛仁71-90 (QF)',"天荣物流 嘉威 114008*08D",2,0,22.80,0,45.60);


        // $invoice->addItem("AMD Athlon X2DC-7450","2.4GHz/1GB/160GB/SMP-DVD/VB",6,0,580,0,3480);


        $invoice->addTotal("Total",178.00, true);

        $invoice->addBadge("Payment Paid");

        $invoice->addTitle("Important Notice");

        $invoice->addParagraph("No item will be replaced or refunded if you don't have the invoice with you.");

        $invoice->setFooternote("浩俊國際貿易有限公司");

        $invoice->render('example1.pdf','D');


        // $result = $woocommerce->get("/orders");
        $data = [
            "billing" => [
                "first_name" => "TEST",
                "last_name" => "TEST",
                "company" => "TEST",
                "address_1" => "广东省深圳市",
                "address_2" => "",
                "city" => "深圳市",
                "state" => "CN20",
                "postcode" => "518000",
                "country" => "CN",
                "email" => "616959862@qq.com",
                "phone" => "18814492044"
            ],
            "shipping" => [
                "first_name" => "TEST",
                "last_name" => "TEST",
                "company" => "TEST",
                "address_1" => "广东省深圳市",
                "address_2" => "",
                "city" => "深圳市",
                "state" => "CN20",
                "postcode" => "518000",
                "country" => "CN",
                "phone" => ""
            ],
            "payment_method" => "cod",
            "payment_method_title" => "货到付款",
            "transaction_id" => "",
            "customer_ip_address" => "172.17.0.3",
            "customer_user_agent" => "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
            "created_via" => "checkout",
            "customer_note" => "",
            "date_paid" => null,
            "date_completed" => null,
            "cart_hash" => "",
        ];


        // $result = $woocommerce->post('orders', $data);

        // 获取订单列表
        // $orders = $woocommerce->get('orders');


        // header('Content-Type: application/pdf; charset=utf-8');
        // echo $template->renderToPdf($order);

        // $this->success("ok", $result);
    }

    public function test4()
    {
        $result = Date::unixtime("day", 0, "end");
        var_dump($result);
        exit();

        $startMonth = Date::unixtime('month', 0);
        $endMonth = Date::unixtime('month', 0, "end");

        // 获取过去一周的订单数量
        $totalOrders = \app\admin\model\order\Order::field("count(*) as count, FROM_UNIXTIME(createtime, '%Y-%m-%d') as date")
            // ->where("status", OrderStatusEnum::USER_HAS_PAID)
            ->where('createtime', 'between', ["1511819200", $endMonth])
            ->group("date")
            ->select();

        // 平台盈利
        $totalBalance = Systembalancelog::field("sum(amount) as amount, FROM_UNIXTIME(createtime, '%Y-%m-%d') as date")
            ->where('createtime', 'between', ["1511819200", $endMonth])
            ->group("date")
            ->select();

        // 将每一天的日期存储在数组中
        $month = array();
        for ($i = $startMonth; $i <= $endMonth; $i += 60 * 60 * 24) {
            $month[] = date('Y-m-d', $i);
        }
        var_dump($month);
        exit();

        // 输出数组
        print_r($days_array);

        exit();


        $startMonth = Date::unixtime('month', 0);
        $endMonth = Date::unixtime('month', 0, "end");

        $gotoWork = \app\admin\model\order\Order::field("count(*) as count, FROM_UNIXTIME(createtime, '%Y-%m-%d') as date")
            // ->where("status", OrderStatusEnum::USER_HAS_PAID)
            ->where('createtime', 'between', [$startMonth, $endMonth])
            ->group("date")
            ->select();
        var_dump($gotoWork);
        exit();

        $users = User::field("exponent_push_token")
            ->where("is_allow_promot_notify", 1)
            ->where("exponent_push_token", "<>", "")
            ->column("exponent_push_token", "id");

        foreach ($users as $uid => $token) {
            var_dump($uid);
            var_dump($token);
        }

        exit();
        $keys = array_keys($users);
        $value = array_values($users);

        var_dump($value);
        exit();


        // Stripe 提现

        // 设置 Stripe API 密钥
        \Stripe\Stripe::setApiKey('sk_test_51MZ9eKLvi7RvipiD9UMssJHolFBPP0fbuXBMOuXM1sNpE1l44lcQWColupr2gRnbmggyi27Zdb3XgBYB2kcxXQFu006WsBEOI9');

        // 创建 Stripe Connect 账户
        $account = \Stripe\Account::create([
            // 账户类型
            'type' => 'custom',
            // 国家
            'country' => 'US',
            // 邮箱
            'email' => 'test3@example.com',
            // 需要的功能
            'requested_capabilities' => ['card_payments', 'transfers'],
        ]);

        // 将 Connect 账户与 Stripe_Customer 关联
        $customer = \Stripe\Customer::create([
            'email' => 'test3@example.com',
            // 用于测试的信用卡令牌
            // 'source' => 'tok_visa',
            // 关联 Stripe Customer
            'metadata' => [
                'account_id' => $account->id,
            ],
        ]);

        // 创建与银行账户相关的令牌
        $bankToken = \Stripe\Token::create([
            // 添加银行卡信息
            'bank_account' => [
                // 国家
                'country' => 'US',
                // 货币
                'currency' => 'usd',
                // 持卡人名称
                'account_holder_name' => 'Test3 User',
                // 持卡人类型：个人
                'account_holder_type' => 'individual',
                // 银行账户的路由转接号码
                'routing_number' => '110000000',
                // 银行帐户的帐号，采用字符串形式。 必须是支票账户。
                'account_number' => '003123456789',
            ],
        ]);

        // 将银行账户提现方法添加到 Connect 账户中
        $bankAccount = $account->external_accounts->create([
            'external_account' => $bankToken->id,
        ]);

        // 通过 Api 同意协议
        $stripe = new \Stripe\StripeClient('sk_test_51MZ9eKLvi7RvipiD9UMssJHolFBPP0fbuXBMOuXM1sNpE1l44lcQWColupr2gRnbmggyi27Zdb3XgBYB2kcxXQFu006WsBEOI9');

        $result = $stripe->accounts->update(
            $account->id,
            [
                'tos_acceptance' => [
                    'date' => time(),
                    'ip' => $this->request->ip(),
                ],
            ]
        );

        $this->success(__("ok"), $result);
        exit();




        $result = strpos("user:13", "merchant");
        var_dump($result);
        exit();

        $result = Systembalancelog::order("id", "desc")->find();
        $this->success("ok1", $result);


        $result = generate_check_code();
        echo $result;
        exit();


        $access_token = "your_access_token";
        $client_key = "your_client_key";
        $client_certificate = "your_client_certificate";
        $merchant_id = "your_merchant_id";
        $payment_amount = "10.00";
        $payment_currency = "AUD";
        $payment_reference = "your_payment_reference";

        $request_body = array(
            "data" => array(
                "type"          => "payment",
                "attributes"    => array(
                    "amount"    => $payment_amount,
                    "currency"  => $payment_currency,
                    "reference" => $payment_reference
                ),
                "relationships" => array(
                    "merchant" => array(
                        "data" => array(
                            "id"   => $merchant_id,
                            "type" => "merchant"
                        )
                    )
                )
            )
        );

        $request_body_json = json_encode($request_body);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.commbank.com.au/cds-au/v1/payments");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $request_body_json);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Authorization: Bearer " . $access_token,
            "x-cds-client-key: " . $client_key,
            "x-cds-client-certificate: " . $client_certificate,
            "Content-Type: application/json"
        ));

        $response = curl_exec($ch);
        curl_close($ch);

        echo $response;
    }

    public function test5()
    {
        // 通过 Api 同意协议
        $stripe = new \Stripe\StripeClient('sk_test_51MZ9eKLvi7RvipiD9UMssJHolFBPP0fbuXBMOuXM1sNpE1l44lcQWColupr2gRnbmggyi27Zdb3XgBYB2kcxXQFu006WsBEOI9');

        $result = $stripe->accounts->update(
            'acct_1NZ6TUPvAA2Cbyur',
            [
                'tos_acceptance' => [
                    'date' => time(),
                    'ip' => "58.62.166.250",
                ],
            ]
        );

        $this->success("ok", $result);
    }

    public function test6()
    {


        $stripe = new \Stripe\StripeClient('sk_test_51MZ9eKLvi7RvipiD9UMssJHolFBPP0fbuXBMOuXM1sNpE1l44lcQWColupr2gRnbmggyi27Zdb3XgBYB2kcxXQFu006WsBEOI9');

        // $this->success("ok", $stripe->balance);

        $result = $stripe->payouts->create(
            [
                'amount' => 1000,
                'currency' => 'hkd',
            ],
            ['stripe_account' => 'acct_1NYnpnPpj2JeQXrn']
        );

        $this->success("ok", $result);
    }
}
