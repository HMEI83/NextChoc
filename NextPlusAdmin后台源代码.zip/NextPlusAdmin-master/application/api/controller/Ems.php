<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\common\library\Ems as Emslib;
use app\common\model\User;
use think\Hook;

/**
 * 邮箱验证码接口
 */
class Ems extends Api
{
    protected $noNeedLogin = '*';
    protected $noNeedRight = '*';

    public function _initialize()
    {
        parent::_initialize();
    }

    public function emailTest()
    {
        $str = $this->request->param("str");
        $domain = $this->request->domain();

        $url = $domain. "/$str";
        return view("emailtest")->assign("url", $url);
    }

    /**
     * 发送验证码
     *
     * @ApiMethod (POST)
     * @param string $email 邮箱
     * @param string $event 事件名称
     */
    public function send()
    {
        $email = $this->request->post("email");
        $event = $this->request->post("event");
        $event = $event ? $event : 'register';

        if (empty($email)) {
            $this->error(__("The email cannot be empty"));
        }

        $last = Emslib::get($email, $event);
        if ($last && time() - $last['createtime'] < 60) {
            $this->error(__('Please try again later'));
        }
        if ($event) {
            $userinfo = User::getByEmail($email);
            if ($event == 'register' && $userinfo) {
                //已被注册
                $this->error(__('The email have been registered'));
            } elseif (in_array($event, ['changeemail']) && $userinfo) {
                //被占用
                $this->error(__('The email have been occupied'));
            } elseif (in_array($event, ['changepwd', 'resetpwd']) && !$userinfo) {
                //未注册
                $this->error(__('The email is not yet registered'));
            }
        }
        $ret = Emslib::send($email, null, $event);
        if ($ret) {
            $this->success();
        } else {
            $this->error();
        }
    }

    /**
     * 检测验证码
     *
     * @ApiMethod (POST)
     * @param string $email   邮箱
     * @param string $event   事件名称
     * @param string $captcha 验证码
     */
    public function check()
    {
        $email = $this->request->post("email");
        $event = $this->request->post("event");
        $event = $event ? $event : 'register';
        $captcha = $this->request->post("captcha");

        if ($event) {
            $userinfo = User::getByEmail($email);
            if ($event == 'register' && $userinfo) {
                //已被注册
                $this->error(__('The email have been registered'));
            } elseif (in_array($event, ['changeemail']) && $userinfo) {
                //被占用
                $this->error(__('The email have been occupied'));
            } elseif (in_array($event, ['changepwd', 'resetpwd']) && !$userinfo) {
                //未注册
                $this->error(__('The email is not yet registered'));
            }
        }
        $ret = Emslib::check($email, $captcha, $event);
        if ($ret === true) {
            $this->success();
        } else {
            $this->error(__($ret));
        }
    }
}
