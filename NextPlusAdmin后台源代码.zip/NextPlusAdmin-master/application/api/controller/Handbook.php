<?php

namespace app\api\controller;

use app\common\controller\Api;

/**
 * 手冊表
 */
class Handbook extends Api
{
    protected $noNeedLogin = ["index"];

    protected $noNeedRight = '*';

    public function index()
    {

    }
}