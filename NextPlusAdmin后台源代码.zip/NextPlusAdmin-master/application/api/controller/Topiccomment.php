<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\api\validate\topic\TopicCommentValidate;
use app\admin\model\topic\Topic as TopicModel;
use app\admin\model\topic\Comment as TopicCommentModel;

/**
 * Class TopicComment
 *
 * @package app\api\controller
 */
class Topiccomment extends Api
{
    protected $noNeedLogin = [];

    protected $noNeedRight = '*';

    // 评论列表
    public function index()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();

        // 暂时一次返回所有评论
        $comments = TopicCommentModel::where("topic_id", $params["topic_id"])
            ->select();

        $redis = new \app\api\library\Redis();
        $prefix = "topic:".$params['topic_id'];
        $result = [];
        foreach ($comments as $comment) {
            $value = "comment:".$comment->id."user:".$userId;

            $content = $comment->content;
            if (!empty($comment->at_user_id)) {
                $atUser = \app\common\model\User::find($comment->at_user_id);

                $content = "@$atUser->username " . $comment->content;
            }
            $result[] = [
                "id"                 => $comment->id,
                // 是否是自己的评论
                "is_self"            => (int)($userId == $comment->user_id),
                "user_id"            => $comment->user_id,
                "username"           => $comment->username,
                "topic_id"           => $comment->topic_id,
                "content"            => $content,
                "like_count"         => $comment->likecount,
                // 当前评论是否点过赞
                "is_like"            => (int)$redis->sIsMember($prefix, $value),
                "create_time_format" => $comment->create_time_format,
                "update_time_format" => $comment->update_time_format,
                "status"                => $comment->status
            ];
        }

        $this->success(__("Operation completed"), $result);
    }

    // 发表评论
    public function create()
    {
        $userId = $this->auth->id;
        $user = $this->auth->getUser();
        $params = $this->request->param();
        $message = $this->validate($params, TopicCommentValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $atUserId = $params['at_user_id'] ?? 0;
        TopicModel::where("id", $params["topic_id"])
            ->inc('commentcount')
            ->update();

        TopicCommentModel::create([
            "user_id"       => $userId,
            "username"      => $user->username,
            "at_user_id"    => $atUserId,
            "topic_id"      => $params["topic_id"],
            "content"       => $params["content"],
        ]);

        $this->success();
    }

    // 修改评论
    public function update()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, TopicCommentValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $target = TopicCommentModel::where("user_id", $userId)
            ->where("id", $params['id'])
            ->find();
        if (empty($target)) {
            $this->error(__("No results were found"));
        }

        $target->content = $params['content'];
        $target->save();
        $this->success();
    }

    /**
     * 删除评论
     */
    public function delete()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, TopicCommentValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $target = TopicCommentModel::where("user_id", $userId)
            ->where("id", $params['id'])
            ->find();
        if (empty($target)) {
            $this->error(__("No results were found"));
        }

        $target->delete();
        $this->success();
    }

    // 评论点赞
    public function like()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, TopicCommentValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $redis = new \app\api\library\Redis();
        // 使用集合记录
        // 点赞记录  topic:4 comment:3:user:7
        $topic = TopicCommentModel::find($params['id']);

        $prefix = "topic:".$topic->topic_id;
        $value = "comment:".$params['id']."user:".$userId;

        if ($redis->sIsMember($prefix, $value)) {
            $this->error("请勿重复点赞");
        }

        $redis->sAdd($prefix, $value);
        $topic->likecount += 1;
        $topic->save();

        $this->success();
    }

    // 评论取消点赞
    public function unlike()
    {
        $userId = $this->auth->id;
        $params = $this->request->param();
        $message = $this->validate($params, TopicCommentValidate::class . "." . __FUNCTION__);
        if (true !== $message) {
            $this->error($message);
        }

        $redis = new \app\api\library\Redis();
        // 使用集合记录
        // 点赞记录  topic:4 comment:3:user:7
        $topic = TopicCommentModel::find($params['id']);

        $prefix = "topic:".$topic->topic_id;
        $value = "comment:".$params['id']."user:".$userId;

        if (!$redis->sIsMember($prefix, $value)) {
            $this->error("请勿重复取消点赞");
        }

        $redis->sRem($prefix, $value);
        $topic->likecount -= 1;
        $topic->save();

        $this->success();
    }
}