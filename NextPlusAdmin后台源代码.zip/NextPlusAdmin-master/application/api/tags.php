<?php

use app\api\behavior\ExpoPush;
use app\api\behavior\RequestRecord;

return [
    // 应用结束
    'app_end'      => [
        RequestRecord::class,
    ],

    // 订单完成
    /*"order_done"    => [
        ExpoPush::class,
    ],*/
];