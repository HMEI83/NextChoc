<?php

namespace app\api\behavior;

use think\Log;

class RequestRecord
{
    public function run()
    {
        //只记录POST请求的日志
        if (request()->isPost()) {
            // 记录请求记录
            \app\common\model\RequestRecord::record();
        }
    }
}