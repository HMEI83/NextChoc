<?php

namespace app\api\behavior;

use app\api\service\expo\push\ExpoPushService;

/**
 * Class Expo
 *
 * @package app\api\behavior
 */
class ExpoPush
{
    /**
     * 订单完成
     *
     * @param $params
     */
    public function orderDone($params)
    {
        $config = config('site.push_order_done');

        (new ExpoPushService())->push($config['title'] ?? "", $config['body'] ?? "", $params);
    }

    /**
     * 相片上传完成
     *
     * @param $params
     */
    public function photoUploadDone($params)
    {
        $config = config('site.push_photo_upload_done');

        (new ExpoPushService())->push($config['title'] ?? "", $config['body'] ?? "", $params);
    }
}