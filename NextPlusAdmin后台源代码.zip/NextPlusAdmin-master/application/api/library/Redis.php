<?php

namespace app\api\library;

use think\Env;

/**
 * Class Redis
 *
 * @package app\api\library
 */
class Redis
{
    protected static $instance = null;

    public $redis;

    public function __construct()
    {
        $password = Env::get("redis.pwd");
        $host = Env::get("redis.host");
        $port = Env::get("redis.port");

        $this->redis = new \Redis;
        $this->redis->connect($host, $port);
        if (!empty($password)) {
            $this->redis->auth($password);
        }
    }

    /**
     * @return \app\api\library\Redis
     */
    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param $method
     * @param $args
     *
     * @return false|mixed
     */
    public function __call($method, $args)
    {
        return call_user_func_array([$this->redis, $method], $args);
    }
}