<?php

namespace app\api\library;

use think\Env;

class PRedis
{
    public $predis;

    protected static $instance = null;

    public function __construct()
    {
        $password = Env::get("redis.pwd");
        $host = Env::get("redis.host");
        $port = Env::get("redis.port");

        $this->predis = new \Predis\Client([
            'scheme' => 'tcp',
            'host'   => Env::get('redis.host'),
            'port'   => Env::get('redis.port'),
        ]);
    }

    /**
     * @return \app\api\library\PRedis
     */
    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * @param $method
     * @param $args
     *
     * @return false|mixed
     */
    public function __call($method, $args)
    {
        return call_user_func_array([$this->predis, $method], $args);
    }
}