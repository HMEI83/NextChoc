<?php

if (!function_exists("order_no")) {

    /**
     * 创建订单号
     *
     * @param $userId
     * @return string
     */
    function order_no($userId): string
    {
        return date('YmdHis') . mt_rand(100000, 999999) . $userId;
    }
}

if (!function_exists("generate_check_code")) {

    /**
     * 生成核销码
     *
     * @return string
     */
    function generate_check_code(): string
    {
        $letters = range('A', 'Z'); // 生成 A 到 Z 的字母数组
        $numbers = range(0, 9); // 生成 0 到 9 的数字数组
        shuffle($letters); // 打乱字母数组的顺序
        shuffle($numbers); // 打乱数字数组的顺序
        $string = $letters[0] . $letters[1]; // 取出前两个字母
        $string .= $numbers[0] . $numbers[1]; // 取出前两个数字
        $string .= $letters[2] . $letters[3]; // 取出后两个字母
        return $string;
    }
}

if (!function_exists('curl_get')) {

    /**
     * @param $url
     * @param $header
     *
     * @return bool|string
     */
    function curl_get($url, $header = [])
    {
        header('Content-type:text/html;charset=utf-8');
        $ch = curl_init();

        // 开发环境设置代理
        // $env = Env::get("app.app_env");
        // if ($env === "development") {
        // curl_setopt($ch, CURLOPT_PROXY, "http://127.0.0.1:7890");
        // }
        curl_setopt($ch, CURLOPT_URL, $url); //设置访问的url地址
        //curl_setopt($ch, CURLOPT_HEADER, 1); //是否显示头部信息
        curl_setopt($ch, CURLOPT_TIMEOUT, 5); //设置超时
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); //用户访问代理 User-Agent
        curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_HOST']); //设置 referer
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); //跟踪301
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //返回结果
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        //这个是重点，加上这个便可以支持http和https下载
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
}