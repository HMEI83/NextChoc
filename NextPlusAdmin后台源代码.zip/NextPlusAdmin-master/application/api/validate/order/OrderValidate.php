<?php

namespace app\api\validate\order;

use think\Validate;

class OrderValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'amount'         => 'require|regex:^[0-9]+(\.[0-9]{1,2})?$',
        'payment_amount' => 'require|regex:^[0-9]+(\.[0-9]{1,2})?$',
        "payment_type"   => 'require',
        "address_id"     => "require|number",
        "merchant_id"    => "require|number",
        "cart_ids"       => "require",
    ];

    /**
     * 提示消息
     */
    protected $message = [

    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'create' => [
            "amount",
            "payment_amount",
            "payment_type",
            "merchant_id",
        ],
        "useCouponCode" => [
            'coupon_code',
        ]
    ];

    /**
     * OrderValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'amount'             => __('amount'),
            'payment_type'       => __("Payment type"),
            'address_id'         => __('Address id'),
            'cart_ids'           => __('Cart ids'),
            'payment_amount'     => __('Payment amount'),
            "coupon_code"        => __("Coupon code"),
            "merchant_id"        => __("Merchant Id"),
        ];
        parent::__construct($rules, $message, $field);
    }
}