<?php

namespace app\api\validate\order;

use think\Validate;

class CartValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        "id"            => "require",
        "ids"           => "require",
        // 'price'        => 'require|regex:^[0-9]+(\.[0-9]{1,2})?$',
        "goods_id"      => 'require|number',
        "goods_name"    => "require",
        "cover_image"   => "require",
        "type"          => "require",
        "merchant_id"   => 'require|number',
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'index' => [
            "merchant_id"
        ],
        'create' => [
            "goods_id",
            "goods_name",
            "cover_image",
            "merchant_id",
        ],
        'delete' => [
            "ids"
        ],
        'updateGoodsCount'    => [
            "id",
            "type"
        ]
    ];

    /**
     * CartValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'cover_image'     => __("Cover image"),
            'goods_name'      => __("Goods name"),
            'goods_id'        => __("Goods id"),
            'merchant_id'     => __("Merchant id"),
            'price'           => __('Price'),
            'id'              => __('Cart id'),
            'ids'             => __('Cart id'),
            "type"            => __("Type"),
        ];
        parent::__construct($rules, $message, $field);
    }
}