<?php

namespace app\api\validate\user;

use think\Validate;

/**
 * Class AddressValidate
 *
 * @package app\api\validate\user
 */
class AddressValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'location' => 'require|min:5|max:64',
        'mobile'   => 'require',
        'name'     => 'require|max:25',
        'id'       => 'require|number',
    ];

    /**
     * 提示消息
     */
    protected $message = [
        /*'name.require'      => '请填写姓名',
        'name.max'          => '姓名长度最多25个字符',
        'location.require'  => '请填写详细地址',
        'location.min'      => '详细地址最少五个字',
        'location.location' => '详细地址最多六十四个字',
        'mobile.require'    => '请填写手机号',
        'id.require'        => '请传递ID',
        'id.number'         => 'ID 必须是数字',*/
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'create'     => [
            'name',
            'mobile',
            'location'
        ],
        'update'     => [
            'name',
            'mobile',
            'location',
            'id'
        ],
        'delete'     => [
            'id'
        ],
        'setDefault' => [
            'id'
        ],
    ];

    /**
     * AddressValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'location'   => __('Location'),
            'mobile'     => __("Mobile"),
            'name'       => __('Name'),
            'id'         => __('Address Id'),
        ];
        parent::__construct($rules, $message, $field);
    }
}