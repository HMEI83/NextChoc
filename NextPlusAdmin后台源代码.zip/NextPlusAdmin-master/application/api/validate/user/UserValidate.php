<?php

namespace app\api\validate\user;

use think\Validate;

/**
 * Class UserValidate
 *
 * @package app\api\validate\user
 */
class UserValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'email'            => 'require|email',
        'code'             => 'require',
        "nickname"         => 'require|max:25',
        "username"         => 'require|max:25',
        "mobile"           => 'require',
        "password"         => 'require|max:25',
        "confirm_password" => 'require|max:25',
        "validation_type"  => "require",
        "gender"           => "require",
        "area"             => "require",
        "address"          => "require",
        "access_token"     => "require",
        "account"          => "require",
    ];

    /**
     * 提示消息
     */
    protected $message = [

    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'registerByEmail'  => [
            'email',
            'code',
            "password",
            "nickname",
        ],
        'registerByMobile' => [
            "mobile",
            "code",
            "password",
            "nickname",
        ],
        "loginByCode"      => [
            'mobile',
            'validation_type',
        ],
        "loginByEmailOrMobilePassword"  => [
            "account",
            "password",
        ],
        "loginByEmailOrMobileCode" => [
            "account",
            "code",
        ],
        "facebookLogin"  => [
            "access_token",
        ],
        "googleLogin"  => [
            "access_token",
        ],
    ];

    /**
     * CardValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'email'            => __('Email'),
            'account'          => __('Account'),
            'code'             => __("Code"),
            'nickname'         => __("Nickname"),
            'username'         => __("Username"),
            'mobile'           => __("Mobile"),
            'password'         => __("Password"),
            'confirm_password' => __("ConfirmPassword"),
            "validation_type"  => __("ValidationType"),
            "gender"           => __("Gender"),
            "hobby_sport"      => __("HobbySport"),
            "area"             => __("Area"),
            "address"          => __("Address"),
            "id_card_image"          => __("IdCard"),
            "self_portrait_image"    => __("SelfPortrait"),
        ];
        parent::__construct($rules, $message, $field);
    }
}