<?php

namespace app\api\validate\user;

use think\Validate;

/**
 * Class CardValidate
 *
 * @package app\api\validate\user
 */
class CardValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'number' => 'require|number|length:16,16',
        'date'   => 'require|dateFormat:m/y|dateValidate',
        'name'   => 'require|max:25',
        'id'     => 'require|number',
    ];

    /**
     * 提示消息
     */
    protected $message = [
        /*'number.require'  => '请填写卡号',
        'date.require'    => '请填写日期',
        'name.require'    => '请填写姓名',
        'number.number'   => '卡号必须是数字',
        'name.max'        => '姓名长度最多25个字符',
        'date.dateFormat' => '日期格式有误',
        'number.length'   => '卡号长度有误',
        'id.require'      => '请传递ID',
        'id.number'       => 'ID 必须是数字',*/
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'create' => [
            'number',
            'date',
            'name'
        ],
        'update' => [
            'number',
            'date',
            'name',
            'id'
        ],
        'delete' => [
            'id'
        ],
        'setDefault' => [
            'id'
        ],
    ];

    /**
     * CardValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'number'  => __('Number'),
            'date'    => __("Date"),
            'name'    => __('Name'),
            'id'      => __('Card Id'),
        ];
        parent::__construct($rules, $message, $field);
    }

    /**
     * 日期验证
     *
     * @param $value string 客户端传过来的值
     * @param $rule  string 验证规则
     * @param $data  array  请求参数
     */
    protected function dateValidate($value, $rule, $data)
    {
        $date = date("m/y");
        if ($value < $date) {
            return __("Invalid date");
        }

        return true;
    }
}