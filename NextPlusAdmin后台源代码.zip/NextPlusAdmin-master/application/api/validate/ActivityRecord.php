<?php

namespace app\api\validate;

use think\Validate;

class ActivityRecord extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'sport'        => 'require',
        'date'         => 'require',
        'time'         => 'require',
        "waiting_time" => 'require',
        "address"      => "require",
        "invitee_id"   => "require",
        "id"           => "require",
        "type"         => "require",
        "score"        => "require"
    ];

    /**
     * 提示消息
     */
    protected $message = [

    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'create' => [
            "sport",
            "time",
            "waiting_time",
            "address",
            "invitee_id",
        ],
        "handle" => [
            "id",
            "type"
        ],
        "evaluation" => [
            "id",
            "score",
        ],
    ];

    /**
     * OrderValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'sport'        => __('Sport'),
            'time'         => __("Time"),
            'waiting_time' => __('Waiting time'),
            'address'      => __('Address'),
            'invitee_id'   => __('Invitee id'),
            "id"           => __("id"),
            "type"         => __("Type"),
            "score"        => __("Score"),
        ];
        parent::__construct($rules, $message, $field);
    }
}