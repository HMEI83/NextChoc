<?php

namespace app\api\validate;

use think\Validate;

class GoodsValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'content'  => 'require|max:255',
        'id'       => 'require|number',
    ];

    /**
     * 提示消息
     */
    protected $message = [

    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'content'     => [
            'id',
            'content',
        ],
        'detail' => [
            'id'
        ],
    ];

    /**
     * AddressValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'content'    => __('Content'),
            'id'         => __('Id'),
        ];
        parent::__construct($rules, $message, $field);
    }
}