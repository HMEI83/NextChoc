<?php

namespace app\api\validate\topic;

use think\Validate;

/**
 * Class TopicCommentValidate
 */
class TopicCommentValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        "id"       => "require|number",
        "topic_id" => "require|number",
        "content"  => 'require|max:1000|min:1',
    ];

    /**
     * 提示消息
     */
    protected $message = [
        /*"id.require"       => "请传递评论ID",
        "id.number"        => "评论ID 必须为数字",
        "topic_id.require" => "请传递话题ID",
        "topic_id.number"  => "话题ID 必须为数字",
        'content.require'  => '请填写评论内容',
        'content.min'      => '评论内容最少十个字',
        'content.max'      => '评论内容最多一千个字',*/
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'create' => [
            "content",
            "topic_id"
        ],
        'update' => [
            "content",
            "id"
        ],
        'delete' => [
            "id"
        ],
        'like'   => [
            "id"
        ],
        'unlike'   => [
            "id"
        ],
    ];

    /**
     * TopicCommentValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'content'  => __("Content"),
            'topic_id' => __('Topic id'),
            'id'       => __('Comment Id'),
        ];
        parent::__construct($rules, $message, $field);
    }
}