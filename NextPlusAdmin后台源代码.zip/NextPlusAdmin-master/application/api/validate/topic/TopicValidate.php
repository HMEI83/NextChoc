<?php

namespace app\api\validate\topic;

use think\Validate;

/**
 * Class TopicValidate
 */
class TopicValidate extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        "id"      => "require|number",
        'title'   => 'require|max:100|min:1',
        "content" => 'require|max:1000|min:10',
    ];

    /**
     * 提示消息
     */
    protected $message = [
        /*"id.require"      => "请传递话题ID",
        "id.number"       => "话题ID 必须为数字",
        'title.require'   => '请填写话题标题',
        'title.min'       => '话题标题最少一个字',
        'title.max'       => '话题标题最多一百个字',
        'content.require' => '请填写话题内容',
        'content.min'     => '话题内容最少十个字',
        'content.max'     => '话题内容最多一千个字',*/
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'create' => [
            "title",
            "content"
        ],
        'update' => [
            "title",
            "content",
            "id"
        ],
        'delete' => [
            "id"
        ],
    ];

    /**
     * TopicValidate constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'content' => __('Content'),
            'title'   => __('Title'),
            'id'      => __('Topic Id'),
        ];
        parent::__construct($rules, $message, $field);
    }
}