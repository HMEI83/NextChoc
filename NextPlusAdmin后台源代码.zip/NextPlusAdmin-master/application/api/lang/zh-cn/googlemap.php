<?php

return [
    "Keyword cannot be empty" => "关键字不能为空",
    "Place Id cannot be empty" => "关键字不能为空",
    "Google Map Api call failed" => "Google Map Api 调用失败",
    "Inverse encoding of latitude and longitude failed" => "经纬度逆编码失败",
    "Lack of latitude and longitude" => "缺少经度或纬度",
    "The latitude and longitude are out of operation range" => "经纬度超出操作范围",
];