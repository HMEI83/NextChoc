<?php

return [
    'Address id'      => '地址 ID',
    'Name'            => '收货人姓名',
    'Mobile'          => '收货人联系方式',
    'Location'        => '收货地址',
];
