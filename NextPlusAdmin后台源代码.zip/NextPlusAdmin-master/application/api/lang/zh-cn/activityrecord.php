<?php

return [
    "Failed to create an offer"                       => "创建邀约失败",
    "Activity record not found"                       => "活动记录不存在",
    "Sport"                                           => "运动",
    "Date"                                            => "日期",
    "Time"                                            => "时间",
    "Waiting time"                                    => "等待时间",
    "Address"                                         => "地址",
    "Invitee id"                                      => "邀约人ID",
    "id"                                              => "ID",
    "Type"                                            => "操作类型",
    "Score"                                           => "评分",
    "You can only rate activities you create"         => "只能给自己创建的活动进行评分",
    "You can only rate activities you accept"         => "只能给自己接受的活动进行评分",
    "Score must be between 1 and 5"                   => "评分必须在1到5之间",
    "You can only operate on activities that wait"    => "你只能对等待的活动进行操作",
    "Invalid parameter"                               => "无效的参数",
    "Please improve the user information first"       => "请先完善用户信息",
    "The longitude or dimension cannot be empty"      => "经度或维度不能为空",
    "Please give a reasonable latitude and longitude" => "请提供一个合理的纬度和经度",
];