<?php

return [
    'Card id'      => '信用卡 ID',
    'Number'       => '信用卡号',
    'Date'         => '信用卡有效期',
    'Cvc'          => '信用卡安全码',
    'Name'         => '姓名',
    'Brand'        => '品牌名',
    'Country'      => '国家',
    'Invalid date' => '有效日期不能小于当前月份',
    "Card number already exists" => "卡号已经存在",
];
