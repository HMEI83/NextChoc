<?php

return [
    "Content"         => "内容",
    "Id"              => "商品 ID",
    "Type 1"          => "健身器材",
    "Type 2"          => "课程",
    "Goods not found" => "商品不存在",
];
