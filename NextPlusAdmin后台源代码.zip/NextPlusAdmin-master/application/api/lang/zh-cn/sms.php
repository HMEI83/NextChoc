<?php

return [
    "The phone number cannot be empty"                                           => "手机号不能为空",
    "The area code cannot be empty"                                           => "区号不能为空",
    "Please try again later"   => "请稍后再试",
    "The phone number have been registered"           => "该手机号已被注册",
    "The phone number have been occupied"             => "该手机号已被占用",
    "The phone number is not yet registered"             => "该手机号尚未注册",
    "Verification Code is Incorrect"  => "验证码不正确",
    "Verification Code has expired"  => "验证码已过期",
];