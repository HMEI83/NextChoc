<?php

return [
    'Topic id'          => '话题 ID',
    'Username'          => '用户名',
    'Title'             => '标题',
    'Content'           => '内容',
    'Sort type require' => '请传递排序方式',
];
