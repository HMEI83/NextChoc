<?php

return [
    "The email cannot be empty"  => "邮箱不能为空",
    "Please try again later"   => "请稍后再试",
    "The email have been registered"           => "该邮箱已被注册",
    "The email have been occupied"             => "该邮箱已被占用",
    "The email is not yet registered"             => "该邮箱尚未注册",
    "Verification Code is Incorrect"  => "验证码不正确",
    "Verification Code has expired"  => "验证码已过期",
];