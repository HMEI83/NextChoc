<?php

return [
    'Comment_id' => '评论 ID',
    'Topic_id'   => '话题 ID',
    'Content'    => '评论内容',
];
