<?php

return [
    "Merchant does not exist" => "商铺不存在",
    "Merchant ID cannot be empty" => "商铺ID不能为空",
    "The merchant already exists, please do not repeat the collection" => "商铺已存在，请勿重复收藏",
    "The longitude or dimension cannot be empty"      => "经度或维度不能为空",
    "Please give a reasonable latitude and longitude" => "请提供一个合理的纬度和经度",
    "The radius cannot be empty"    => "半径不能为空",
    "The radius must be a number"   => "半径必须是数字",
];