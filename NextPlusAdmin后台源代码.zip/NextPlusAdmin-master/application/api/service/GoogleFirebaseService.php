<?php

namespace app\api\service;

use Kreait\Firebase\Factory;
use Kreait\Firebase\Http\HttpClientOptions;
use think\Env;
use think\Log;

class GoogleFirebaseService
{
    /**
     * @param $uid
     *
     * @return bool|mixed
     */
    public function checkSms($uid)
    {
        try {
            // 创建一个 GuzzleHttp 客户端
            // 设置请求超时时间，最多等待 5s
            $option = HttpClientOptions::default()->withTimeout("5");

            $factory = (new Factory)
                ->withServiceAccount('./firebase/nextchoc-firebase-adminsdk-pggm5-312b47f64d.json')
                ->withDatabaseUri('https://nextchoc-default-rtdb.asia-southeast1.firebasedatabase.app/')
                ->withHttpClientOptions($option);

            $database = $factory->createDatabase();
            $reference = $database->getReference('users/' . $uid);
            $snapshot = $reference->getSnapshot();
            $value = $snapshot->getValue();
            if (!$value) {
                return false;
            }
            return $value;
        } catch (\Exception $exception) {
            Log::error("Firebase API 请求失败：" . $exception->getMessage());

            return false;
        }
    }
}