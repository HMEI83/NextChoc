<?php

namespace app\api\service;

class OrderService
{
    /**
     * 获取积分配置
     *
     * @return float|int
     */
    public function getIntegralConfig()
    {
        $config = config('site.integral_deduction_order');
        $config = explode(":", $config);
        if (empty($config) || count($config) != 2) {
            // 如果获取配置失败，默认按 100:1 赠送，100  积分抵扣 1 金额
            $config = [100, 1];
        }

        return $config[1] / $config[0];
    }

    /**
     * 获取订单配置
     *
     * @return float|int
     */
    public function getOrderConfig()
    {
        $config = config('site.order_giving_integral');
        $config = explode(":", $config);
        if (empty($config) || count($config) != 2) {
            // 如果获取配置失败，默认按 1:1 赠送
            $config = [1, 1];
        }

        return $config[1] / $config[0];
    }
}