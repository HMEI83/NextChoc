<?php

namespace app\api\service\payment;

/**
 * Class PaymentContext
 *
 * @method pay($orderInfo, $otherInfo) 支付
 * @method execute($payload) PayPal 同步回调
 * @method webhook($payload, $headers) 异步回调
 * @method refund($payload) 退款
 * @package app\api\service\payment
 */
class PaymentContext
{
    /**
     * @var \app\api\service\payment\PaymentStrategy
     */
    private $strategy;

    /**
     * PaymentContext constructor.
     *
     * @param \app\api\service\payment\PaymentStrategy $strategy
     */
    public function __construct(PaymentStrategy $strategy)
    {
        $this->strategy = $strategy;
    }

    /**
     * @param $name
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($name, $arguments)
    {
        return $this->strategy->$name(...$arguments);
    }
}