<?php

namespace app\api\service\payment;

use app\api\service\payment\strategy\PaypalStrategy;
use app\api\service\payment\strategy\StripeStrategy;

/**
 * Class PaymentFactory
 *
 * @package app\api\service\payment
 */
class PaymentFactory
{
    /**
     * @param $payType
     *
     * @return \app\api\service\payment\strategy\StripeStrategy
     * @throws \Exception
     */
    public static function strategy($payType)
    {
        $map = [
            "stripe" => new StripeStrategy(),
            "paypal" => new PaypalStrategy(),
            // 新增其他支付策略
        ];

        if (isset($map[$payType])) {
            return $map[$payType];
        }

        throw new \Exception("支付方式错误");
    }
}