<?php

namespace app\api\service\payment;

/**
 * 支付接口
 *
 * Interface PaymentStrategy
 *
 * @package app\api\service\payment
 */
interface PaymentStrategy
{
    /**
     * 支付
     *
     * @param $orderInfo     array 订单信息
     * @param $paymentParams array 支付参数
     *
     * @return mixed
     */
    public function pay(array $orderInfo, array $paymentParams);

    public function webhook($payload, $headers);

    public function refund($orderInfo);
}