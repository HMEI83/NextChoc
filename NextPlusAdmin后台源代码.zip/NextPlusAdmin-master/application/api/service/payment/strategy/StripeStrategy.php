<?php

namespace app\api\service\payment\strategy;

use app\admin\model\balnace\Merchantbalancelog;
use app\admin\model\balnace\Systembalancelog;
use app\admin\model\goods\Goods;
use app\admin\model\merchant\Merchant;
use app\api\service\payment\PaymentStrategy;
use app\common\enum\balance\BalanceChangeTypeEnum;
use app\common\enum\balance\BalanceSourceTypeEnum;
use app\common\enum\order\OrderCancelTypeEnum;
use app\common\enum\order\OrderPaymentStatusEnum;
use app\common\enum\order\OrderStatusEnum;
use app\common\enum\payment\PaymentStatusEnum;
use app\common\model\FailWebhook;
use app\common\model\Message;
use app\common\model\Order;
use app\common\model\OrderGoods;
use app\common\model\PayRecord as PayRecordModel;
use Stripe\Checkout\Session;
use Stripe\Event;
use Stripe\Exception\ApiErrorException;
use Stripe\Refund;
use Stripe\Stripe;
use Stripe\StripeClient;
use think\Db;
use think\Env;
use think\Log;

/**
 * Stripe 支付策略
 *
 * Class StripeStrategy
 *
 * @package app\api\service\payment\strategy
 */
class StripeStrategy implements PaymentStrategy
{
    /**
     * Stripe 私钥
     * @var string
     */
    private $stripeSecretKey = "";

    /**
     * 公钥
     * @var string
     */
    private $stripePublishableKey = "";

    /**
     * @var string
     */
    private $currency;

    public function __construct()
    {
        $this->stripeSecretKey = Env::get('stripe.STRIPE_SECRET_KEY', '');
        $this->stripePublishableKey = Env::get('stripe.STRIPE_PUBLISHABLE_KEY', '');
        $this->currency = Env::get("app.currency", "USD");
    }

    // 创建 Stripe 产品
    public function createProduct($name, $desc, $amount)
    {
        // $stripeSecretKey = Env::get('stripe.STRIPE_SECRET_KEY', '');
        $stripe = new StripeClient($this->stripeSecretKey);

        $product = $stripe->products->create([
            'name'        => $name,
            'description' => $desc,
        ]);

        $price = $stripe->prices->create([
            'unit_amount' => $amount,
            'currency'    => 'usd',
            'recurring'   => ['interval' => 'month'],
            'product'     => $product['id'],
        ]);

        return [
            "product_id" => $product->id,
            "price_id"   => $price->id,
        ];
    }

    // 使用预设结账页面，创建 Stripe 支付订单
    public function createPayOrderByCheckout($priceId)
    {
        $host = "http://". $this->request->host() . "/stripedemo";

        try {
            Stripe::setApiKey($this->stripeSecretKey);
            $checkoutSession = Session::create([
                'line_items' => [[
                    'price' => $priceId,
                    'quantity' => 1,
                 ]],
                'mode' => 'payment',
                'success_url' => $host . '/success.html',
                'cancel_url' => $host . '/cancel.html',
            ]);

            return [
                "url"   => $checkoutSession->url,
                "id"    => $checkoutSession->id
            ];
        } catch (\Stripe\Exception\ApiErrorException $exception) {
            return $exception->getMessage();
        }
    }

    /**
     * 支付
     *
     * @param array $orderInfo
     * @param array $paymentParams
     *
     * @return array
     * @throws \Exception
     */
    public function pay(array $orderInfo, array $paymentParams)
    {
        try {
            $stripe = new StripeClient($this->stripeSecretKey);

            // 创建 PaymentIntent
            $paymentIntent = $stripe->paymentIntents->create([
                // 支付金额（Stripe 做了参数验证，不能直接传浮点数）
                'amount'   => $orderInfo['payment_amount'] * 100,
                // 币种
                'currency' => $this->currency,
                // 将 order_no 作为与Stripe 关联依据
                'metadata' => [
                    'order_no' => $orderInfo['order_no']
                ],
                /*'automatic_payment_methods' => [
                    'enabled' => 'true',
                ],*/
            ]);

            // 返回支付信息给客户端，拉起支付
            return [
                "third_order_no"     => $paymentIntent->id,
                'client_secret'      => $paymentIntent->client_secret,  // PaymentIntent 客户端密钥
                'publishable_key'    => $this->stripePublishableKey     // Stripe 公钥
            ];
        } catch (ApiErrorException $exception) {
            throw new \Exception($exception->getMessage());
        }
    }

    /**
     * App 支付回调
     *
     * @param $payload
     *
     * @return bool
     */
    public function webhook($payload, $headers)
    {
        Stripe::setApiKey($this->stripePublishableKey);
        $remark = "";

        // 本地回调密钥签名
        // $endpointSecret = Env::get('stripe.ENDPOINT_SECRET', '');

        if (empty($payload)) {
            return false;
        }
        $event = null;
        try {
            $event = Event::constructFrom(
                json_decode($payload, true)
            );
        } catch(\UnexpectedValueException $e) {
            $remark = "webhook 解析请求失败";
            FailWebhook::record($remark, "stripe");

            return false;
        } catch(\Stripe\Exception\SignatureVerificationException $e) {
            $remark = "webhook 签名验证失败";
            FailWebhook::record($remark, "stripe");

            return false;
        }

        Db::startTrans();
        try {
            // 处理回调事件
            switch ($event->type) {
                // 创建支付成功
                case 'payment_intent.created':
                    FailWebhook::record("创建支付成功", "stripe", 1, "payment_intent.created");

                    Db::commit();
                    return true;

                case 'payment_intent.succeeded':
                    // 收款成功
                    $paymentIntent = $event->data->object;
                    // 订单号
                    $thirdOrderNo = $paymentIntent->id;
                    $order = Order::where("third_order_no", $thirdOrderNo)->find();
                    if (empty($order)) {
                        $remark = "订单号查询失败：". $thirdOrderNo;
                        FailWebhook::record($remark, "stripe", 1, "payment_intent.succeeded");
                        return false;
                    }

                    // 变更订单状态
                    $order->payer_id = $event->data->object->latest_charge;
                    $order->status = OrderStatusEnum::USER_HAS_PAID;
                    $order->payment_status = OrderPaymentStatusEnum::PAID;
                    $order->payment_time = time();

                    $commission = bcmul($order->payment_amount, $order->commissionrate/100, 2);
                    $order->commission = $commission;
                    $order->save();

                    // 更新店鋪盲盒庫存
                    $orderGoods = OrderGoods::where("order_id", $order->id)->select();
                    foreach ($orderGoods as $_orderGoods) {
                        $goods = Goods::find($_orderGoods->goods_id);

                        $goods->count -= $_orderGoods->count;
                        $goods->ordercount += 1;
                        if ($goods->count <= 0) {
                            $goods->count= 0;
                            $goods->shelfswitch = 0;
                        }
                        $goods->save();
                    }

                    // 记录支付记录
                    PayRecordModel::create([
                        "user_id"         => $order->user_id,
                        "order_no"        => $order->order_no,
                        "payment_amount"  => $order->payment_amount,
                        "payment_type"    => "stripe",
                        "payment_time"    => time(),
                        "status"          => PaymentStatusEnum::PAY_SUCCESS,
                        "callback_params" => json_encode($event)
                    ]);

                    Db::commit();
                    return true;

                case 'payment_intent.canceled':
                    // 支付取消
                    $paymentIntent = $event->data->object;
                    // 订单号
                    $thirdOrderNo = $paymentIntent->id;
                    $order = Order::where("third_order_no", $thirdOrderNo)->find();
                    if (empty($order)) {
                        $remark = "订单号查询失败：". $thirdOrderNo;
                        FailWebhook::record($remark, "stripe", 1, "payment_intent.canceled");
                        return false;
                    }

                    // 变更订单状态
                    $order->cancel_time = time();
                    $order->cancel_type = OrderCancelTypeEnum::UNPAID_CANCEL;
                    $order->status = OrderStatusEnum::ORDER_CANCEL;
                    $order->payment_status = OrderPaymentStatusEnum::UNPAID;
                    $order->save();

                    Db::commit();
                    return true;

                // 其他事件 https://stripe.com/docs/api/events/types
                default:
                    $remark = '未知的事件类型' . $event->type;
                    FailWebhook::record($remark, "stripe", 1, $event->type);

                    Db::commit();
                    return false;
            }
        } catch (\Exception $e) {
            Db::rollback();
            Log::error("订单回调处理异常" . $e->getMessage());

            $remark = "订单回调处理异常" . $e->getMessage();
            FailWebhook::record($remark, "stripe");
            return false;
        }
    }

    /**
     * Stripe 退款
     *
     * @link https://stripe.com/docs/api/refunds
     * @throws \Stripe\Exception\ApiErrorException
     */
    public function refund($orderInfo)
    {
        Stripe::setApiKey($this->stripeSecretKey);
        $refund = \Stripe\Refund::create([
            // 原始付款对象ID
            'charge' => $orderInfo['payer_id'],
            // 退款金额，单位为分
            "amount" => $orderInfo['payment_amount'] * 100
        ]);

        if ($refund->status === "succeeded") {
            return true;
        }

        return $refund->failure_reason;
    }
}