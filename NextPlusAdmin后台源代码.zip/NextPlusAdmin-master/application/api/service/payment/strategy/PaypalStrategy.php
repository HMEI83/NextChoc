<?php

namespace app\api\service\payment\strategy;

use app\admin\model\balnace\Merchantbalancelog;
use app\admin\model\balnace\Systembalancelog;
use app\admin\model\goods\Goods;
use app\admin\model\merchant\Merchant;
use app\api\service\payment\PaymentStrategy;
use app\common\enum\balance\BalanceChangeTypeEnum;
use app\common\enum\balance\BalanceSourceTypeEnum;
use app\common\enum\order\OrderCancelTypeEnum;
use app\common\enum\order\OrderPaymentStatusEnum;
use app\common\enum\order\OrderStatusEnum;
use app\common\enum\payment\PaymentStatusEnum;
use app\common\model\FailWebhook;
use app\common\model\Message;
use app\common\model\Order as OrderModel;
use app\common\model\OrderGoods;
use app\common\model\PayRecord as PayRecordModel;
use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Refund;
use PayPal\Api\RefundRequest;
use PayPal\Api\Sale;
use PayPal\Api\VerifyWebhookSignature;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use think\Db;
use think\Env;
use think\Log;

/**
 * Paypal 支付策略
 *
 * Class PaypalStrategy
 *
 * @package app\api\service\payment\strategy
 */
class PaypalStrategy implements PaymentStrategy
{
    /**
     * PayPal Client Id
     *
     * @var string
     */
    private $clientId;

    /**
     * PayPal Client Secret
     *
     * @var string
     */
    private $clientSecret;

    /**
     * Paypal 环境变量
     *
     * @var string
     */
    private $environment;

    /**
     * @var string 币种
     */
    private $currency;

    /**
     * @var \PayPal\Rest\ApiContext
     */
    private $apiContext;

    /**
     * @var string
     */
    private $redirectUrl;

    /**
     * PaypalStrategy constructor.
     */
    public function __construct()
    {
        $this->clientId = Env::get("paypal.CLIENT_ID");
        $this->clientSecret = Env::get("paypal.CLIENT_SECRET");
        $this->currency = Env::get("app.currency", "USD");

        $this->apiContext = new ApiContext(
            new OAuthTokenCredential(
                $this->clientId,
                $this->clientSecret
            )
        );

        // 本地调试，无需 https
        $env = Env::get("app.app_env");
        if ($env === "development") {
            $this->redirectUrl = "https://".Env::get("app.app_url") . "/api/order/paypalExecute";
        } else {
            $this->redirectUrl = "https://".Env::get("app.app_url") . "/api/order/paypalExecute";
        }

        if ($env === "production") {
            $this->apiContext->setConfig([
                'mode' => 'live',         // 设置为生产环境
            ]);
        }
    }

    /**
     * 支付
     *
     * @param array $orderInfo
     * @param array $paymentParams
     *
     * @link https://developer.paypal.com/docs/api/payments/#payment_create
     * @return string[]
     * @throws \Exception
     */
    public function pay(array $orderInfo, array $paymentParams)
    {
        $payer = new \PayPal\Api\Payer();
        $payer->setPaymentMethod('paypal');

        $item = new Item();
        $item->setName("NextPlus-" . $orderInfo['order_no'])
            ->setCurrency($this->currency)
            // 设置数量
            ->setQuantity(1)
            ->setPrice($orderInfo['payment_amount']);

        $itemList = new ItemList();
        $itemList->setItems([$item]);

        $amount = new \PayPal\Api\Amount();
        // 设置总价
        $amount->setTotal($orderInfo['payment_amount'])
            ->setCurrency($this->currency);

        $transaction = new \PayPal\Api\Transaction();
        $transaction->setAmount($amount)
            ->setItemList($itemList)
            ->setDescription("Next Plus 消费费用")
            ->setInvoiceNumber($orderInfo['order_no']);

        // 设置授权成功之后，重定向地址
        $redirectUrls = new RedirectUrls();
        $redirectUrls->setReturnUrl($this->redirectUrl . "?success=true")
            ->setCancelUrl($this->redirectUrl . "?success=false");

        $payment = new Payment();
        $payment->setIntent('sale')
            ->setPayer($payer)
            ->setTransactions(array($transaction))
            ->setRedirectUrls($redirectUrls);

        try {
            // 创建交易
            $payment->create($this->apiContext);
            return [
                // Paypal payment id
                "third_order_no" => $payment->id,
                // Paypal 授权地址
                "approval_url"   => $payment->getApprovalLink(),
            ];
        } catch (\PayPal\Exception\PayPalConnectionException $exception) {
            throw new \Exception($exception->getData());
        }
    }

    /**
     * 同步支付回调（确认用户是否付款）
     *
     * @param $payload
     *
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function execute($payload)
    {
        // 是否取消支付标识
        $success = $payload['success'] ?? false;
        // 支付ID
        $paymentId = $payload['paymentId'] ?? "";
        // 支付人ID
        $payerId = $payload['PayerID'] ?? "";

        if (empty($paymentId) || empty($payerId)) {
            // 支付失败
            return "fail";
        }

        if (false === $success) {
            // 取消支付
            $order = OrderModel::where("third_order_no", $paymentId)->find();

            if (empty($order)) {
                $remark = "订单号查询失败：". $paymentId;
                FailWebhook::record($remark);
                return "fail";
            }

            // 变更订单状态
            $order->cancel_time = time();
            $order->cancel_type = OrderCancelTypeEnum::UNPAID_CANCEL;
            $order->status = OrderStatusEnum::ORDER_CANCEL;
            $order->payment_status = OrderPaymentStatusEnum::UNPAID;
            $order->save();

            return "cancel";
        }

        $payment = Payment::get($paymentId, $this->apiContext);
        $execute = new PaymentExecution();
        $execute->setPayerId($payerId);
        try {
            // 确认支付
            $payment->execute($execute, $this->apiContext);
        } catch (\Exception $e) {
            // 支付失败
            return "fail";
        }
        // 支付成功
        return "success";
    }

    /**
     * 异步支付回调（处理业务逻辑）
     *
     * @param $payload
     */
    public function webhook($payload, $headers)
    {
        $payload = json_decode($payload, true);
        if (empty($payload)) {
            $remark = "回调参数解析失败";
            FailWebhook::record($remark, "paypal");
            return false;
        }

        // 验签
        /*$headers = array_change_key_case($headers, CASE_UPPER);

        $signatureVerification = new VerifyWebhookSignature();
        $signatureVerification->setAuthAlgo($headers['PAYPAL-AUTH-ALGO']);
        $signatureVerification->setTransmissionId($headers['PAYPAL-TRANSMISSION-ID']);
        $signatureVerification->setCertUrl($headers['PAYPAL-CERT-URL']);
        // Note that the Webhook ID must be a currently valid Webhook that you created with your client ID/secret.
        $signatureVerification->setWebhookId("9XL90610J3647323C");
        $signatureVerification->setTransmissionSig($headers['PAYPAL-TRANSMISSION-SIG']);
        $signatureVerification->setTransmissionTime($headers['PAYPAL-TRANSMISSION-TIME']);*/

        Db::startTrans();
        try {
            switch ($payload['event_type']) {
                // 支付订单创建成功
                case "PAYMENTS.PAYMENT.CREATED":
                    $paymentId = $payload['resource']['id'] ?? "-";
                    $order = OrderModel::where("third_order_no", $paymentId)->find();
                    if (empty($order)) {
                        $remark = "订单号查询失败：". $paymentId;
                        FailWebhook::record($remark, "paypal", 1,"PAYMENTS.PAYMENT.CREATED");
                        return false;
                    }

                    // 变更订单状态
                    $order->payer_id = $payload['resource']['transactions'][0]['related_resources'][0]['sale']['id'] ?? "-";
                    $order->status = OrderStatusEnum::USER_HAS_PAID;
                    $order->payment_status = OrderPaymentStatusEnum::PAID;
                    $order->payment_time = time();

                    $commission = bcmul($order->payment_amount, $order->commissionrate/100, 2);
                    $order->commission = $commission;
                    $order->save();

                    // 更新店鋪盲盒庫存
                    $orderGoods = OrderGoods::where("order_id", $order->id)->select();
                    foreach ($orderGoods as $_orderGoods) {
                        $goods = Goods::find($_orderGoods->goods_id);

                        $goods->count -= $_orderGoods->count;
                        $goods->ordercount += 1;
                        if ($goods->count <= 0) {
                            $goods->count= 0;
                            $goods->shelfswitch = 0;
                        }
                        $goods->save();
                    }

                    // 记录支付记录
                    PayRecordModel::create([
                        "user_id"         => $order->user_id,
                        "order_no"        => $order->order_no,
                        "payment_amount"  => $order->payment_amount,
                        "payment_type"    => "paypal",
                        "payment_time"    => time(),
                        "status"          => PaymentStatusEnum::PAY_SUCCESS,
                        "request_params"  => NULL,
                        "callback_params" => json_encode($payload)
                    ]);

                    Db::commit();
                    return true;

                // 买家完成支付
                /**
                 *
                 * 通过 PayPal 进行付款时，触发的初始 Webhook 事件通常是“付款已创建”。 首次创建付款且完成之前会触发此事件。
                 * 付款完成后，PayPal 将发送另一个事件类型为“付款销售已完成”的 Webhook 事件，以通知商家付款已成功处理。 该事件表示支付已完成，资金已转入商户账户。
                 * 如果您没有收到“付款销售已完成”webhook 事件，可能有多种原因导致发生这种情况。 以下是一些常见原因：
                 * 1. 延迟处理：有时，“付款销售完成”事件的处理可能会出现延迟。 这可能是由于多种因素造成的，例如网络连接问题或 PayPal 服务器上的高流量。
                 * 2. Webhook 配置不正确：您可能未收到“付款销售完成”事件的另一个原因可能是由于 Webhook 配置不正确。 确保您的 Webhook URL 正确，并且您已在 PayPal Webhook 设置中启用“付款销售完成”事件。
                 * 3. 付款未完成：如果付款未完成，则不会触发“付款销售完成”事件。 在预期事件被触发之前，请确保付款已成功处理。
                 *
                 */
                case "PAYMENT.SALE.COMPLETED":
                    $paymentId = $payload['resource']['parent_payment'] ?? "-";
                    $order = OrderModel::where("third_order_no", $paymentId)->find();
                    if (empty($order)) {
                        $remark = "订单号查询失败：". $paymentId;
                        FailWebhook::record($remark, "paypal", 1, "PAYMENT.SALE.COMPLETED");
                        return false;
                    }

                    // 记录支付记录
                    PayRecordModel::where("order_no", $order->order_no)->update([
                        "remark" => "PAYMENT.SALE.COMPLETED 事件回调成功"
                    ]);

                    // 变更订单状态
                    $order->payer_id = $payload['resource']['id'] ?? "-";
                    $order->save();

                    // 更新店鋪盲盒庫存
                    /*$orderGoods = OrderGoods::where("order_id", $order->id)->select();
                    foreach ($orderGoods as $_orderGoods) {
                        $goods = Goods::find($_orderGoods->goods_id);
                        $goods->ordercount += 1;
                        if ($goods->count >= $_orderGoods->count) {
                            $goods->count -= $_orderGoods->count;
                            $goods->save();
                        } else {
                            $goods->shelfswitch = 0;
                            $goods->save();
                        }
                    }

                    // 商鋪增加餘額、更新完成訂單數量
                    // todo 余额更新方式需要优化
                    $merchant = Merchant::find($order->merchant_id);
                    $commission = bcmul($order->payment_amount, $order->commissionrate/100, 2);
                    $_merchantBalance = bcsub($order->payment_amount, $commission, 2);

                    $order->commission = $commission;
                    $order->merchant_balance = $_merchantBalance;
                    $order->save();

                    $balance = bcadd($merchant->balance, $_merchantBalance, 2);
                    $merchant->balance = $balance;
                    $merchant->salesvolume += 1;
                    $merchant->save();

                    // 記錄商户餘額變動
                    Merchantbalancelog::create([
                        "merchant_id"   => $order->merchant_id,
                        "order_id"      => $order->id,
                        "before_amount" => $merchant->balance,
                        "amount"        => $_merchantBalance,
                        "after_amount"  => $balance,
                        "type"          => BalanceChangeTypeEnum::ADD,
                        "sourcetype"    => BalanceSourceTypeEnum::USER_PAY,
                    ]);

                    // 獲取最新一條記錄
                    $systemBalance = Systembalancelog::order("id", "desc")->find();

                    $systemBeforeBalance = $systemBalance->after_amount ?? 0;
                    $systemAfterBalance = bcadd($systemBeforeBalance, $commission, 2);
                    // 記錄系統餘額變動
                    Systembalancelog::create([
                        "merchant_id"   => $order->merchant_id,
                        "before_amount" => $systemBeforeBalance,
                        "amount"        => $commission,
                        "after_amount"  => $systemAfterBalance,
                        "type"          => BalanceChangeTypeEnum::ADD,
                        "sourcetype"    => BalanceSourceTypeEnum::COMMISSION,
                    ]);

                    // 记录支付记录
                    PayRecordModel::create([
                        "user_id"         => $order->user_id,
                        "order_no"        => $order->order_no,
                        "payment_amount"  => $order->payment_amount,
                        "payment_type"    => "paypal",
                        "payment_time"    => time(),
                        "status"          => PaymentStatusEnum::PAY_SUCCESS,
                        "request_params"  => NULL,
                        "callback_params" => json_encode($payload)
                    ]);*/

                    Db::commit();
                    return true;

                default:
                    $remark = '未知的事件类型' . $payload['event_type'];
                    FailWebhook::record($remark, "paypal", 1, $payload['event_type']);
                    Db::commit();
                    return false;
            }
        } catch (\Exception $e) {
            Log::error("订单回调处理异常" . $e->getMessage());

            $remark = "订单回调处理异常" . $e->getMessage();
            FailWebhook::record($remark, "paypal");

            Db::rollback();
            return false;
        }
    }

    /**
     * Paypal 退款
     */
    public function refund($orderInfo)
    {
        try {
            $amount = new Amount();
            $amount->setCurrency($this->currency)
                ->setTotal($orderInfo['payment_amount']);

            $refundRequest = new RefundRequest();
            $refundRequest->setAmount($amount);

            $sale = new Sale();
            // 付款人 ID
            $sale->setId($orderInfo['payer_id']);

            $result = $sale->refundSale($refundRequest, $this->apiContext);
        } catch (\Exception $e) {
            // 退款失败
            return $e->getMessage();
        }
        // 退款完成
        return true;
    }
}