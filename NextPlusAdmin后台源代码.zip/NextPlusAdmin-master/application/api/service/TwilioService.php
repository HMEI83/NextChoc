<?php

namespace app\api\service;

use think\Env;
use think\Log;
use Twilio\Exceptions\ConfigurationException;
use Twilio\Exceptions\TwilioException;

class TwilioService
{
    public function sendSms($to, $code)
    {
        $sid = Env::get("twilio.SID");; // Your Account SID from www.twilio.com/console
        $token = Env::get("twilio.TOKEN");; // Your Auth Token from www.twilio.com/console
        $serviceSid = Env::get("twilio.SERVICE_SID");

        $content = "【NextChoc】Your verification code is $code";

        try {
            $twilio = new \Twilio\Rest\Client($sid, $token);

            $message = $twilio->messages
                ->create($to,
                    array(
                        "messagingServiceSid" => $serviceSid,
                        "body" => $content
                    )
                );

            return $message;
        } catch (ConfigurationException|TwilioException $e) {
            Log::error("短信發送失败：" . $e->getMessage());
            return false;
        }
    }
}