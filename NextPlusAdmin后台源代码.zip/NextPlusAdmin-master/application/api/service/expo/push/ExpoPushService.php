<?php

namespace app\api\service\expo\push;

use app\common\model\ExpoPushRecord;
use ExpoSDK\Expo;
use ExpoSDK\ExpoMessage;
use think\Exception;
use think\Log;

/**
 * Expo 推送服务
 *
 * Class ExpoPushService
 */
class ExpoPushService
{
    /**
     * 向一个或者多个用户推送通知消息
     *
     * @param string $title         推送标题
     * @param string $body          推送内容
     * @param array  $users
     *
     * @return \ExpoSDK\ExpoResponse|false
     */
    public function push(string $title, string $body, array $users, $eventType = "", $pushData = [])
    {
        $exception = "";
        $result = null;

        $userTokens = array_values($users);

        if (empty($userTokens)) {
            Log::error("推送失败：没有有效的ExpoPushToken");
            return false;
        }

        $messages = [
            new ExpoMessage([
                'title' => $title,
                'body'  => $body,
                "data"  => is_array($pushData) ? $pushData : json_decode($pushData),
            ]),
        ];

        $successCount = 0;
        try {
            foreach ($userTokens as $userToken) {
                $successCount += 1;
                $result = (new Expo)->send($messages)->to($userToken)->push();
            }

            $isSuccess = true;
        } catch (\ExpoSDK\Exceptions\ExpoException | \ExpoSDK\Exceptions\InvalidTokensException | Exception $e) {
            Log::error("推送失败：" . $e->getMessage());
            $isSuccess = false;
            $exception = $e->getMessage();
        }

        return $isSuccess > 0 ? $successCount : 0;
    }
}