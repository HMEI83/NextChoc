<?php

namespace app\admin\controller\order;

use app\common\controller\Backend;

/**
 * 订单评价
 *
 * @icon fa fa-circle-o
 */
class Evaluate extends Backend
{

    /**
     * Evaluate模型对象
     * @var \app\admin\model\order\Evaluate
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\order\Evaluate;

    }

    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        //如果发送的来源是 Selectpage，则转发到 Selectpage
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }

        $merchant = $this->auth->getUserInfo();

        [$where, $sort, $order, $offset, $limit] = $this->buildparams();
        $list = $this->model
            ->where($where)
            ->where(function ($query) use ($merchant) {
                if (!$merchant['adminswitch']) {
                    // 不是管理员
                    if (!$merchant['pid']) {
                        $query->where("merchant_id", $merchant['id']);
                    } else {
                        $query->where("merchant_id", $merchant['pid']);
                    }
                }
            })
            ->order($sort, $order)
            ->paginate($limit);

        $result = ['total' => $list->total(), 'rows' => $list->items()];
        return json($result);
    }

}
