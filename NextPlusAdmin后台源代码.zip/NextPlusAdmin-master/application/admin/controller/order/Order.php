<?php

namespace app\admin\controller\order;

use app\admin\model\balnace\Merchantbalancelog;
use app\admin\model\balnace\Systembalancelog;
use app\admin\model\goods\Goods;
use app\admin\model\merchant\Merchant;
use app\admin\model\order\OrderRefund as OrderRefundModel;
use app\api\service\expo\push\ExpoPushService;
use app\api\service\payment\PaymentContext;
use app\api\service\payment\PaymentFactory;
use app\common\controller\Backend;
use app\common\enum\balance\BalanceChangeTypeEnum;
use app\common\enum\balance\BalanceSourceTypeEnum;
use app\common\enum\order\OrderCancelTypeEnum;
use app\common\enum\order\OrderPaymentStatusEnum;
use app\common\enum\order\OrderRefundAuditStatusEnum;
use app\common\enum\order\OrderRefundStatusEnum;
use app\common\enum\order\OrderStatusEnum;
use app\common\model\OrderGoods;
use app\common\model\User;
use think\Db;
use think\Exception;
use think\Log;

/**
 * 订单管理
 *
 * @icon fa fa-circle-o
 */
class Order extends Backend
{
    protected $noNeedLogin = ['getOrderNumbers'];

    /**
     * Order模型对象
     * @var \app\admin\model\order\Order
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\order\Order;
        $this->view->assign("paymentStatusList", $this->model->getPaymentStatusList());
        $this->view->assign("cancelTypeList", $this->model->getCancelTypeList());
        $this->view->assign("statusList", $this->model->getStatusList());
        $this->view->assign("isEvaluateList", $this->model->getIsEvaluateList());
        $this->view->assign("isAutoCheckList", $this->model->getIsAutoCheckList());
    }

    public function getOrderNumbers()
    {
        $merchant = $this->auth->getUserInfo();
        $numbers = 0;
        if (!empty($merchant)) {
            if ($merchant['adminswitch'] == 0) {
                // 不是管理员
                if (!$merchant['pid']) {
                    $numbers = $this->model->where("merchant_id", $merchant['id'])
                        ->where("status", OrderStatusEnum::USER_HAS_PAID)
                        ->count();
                } else {
                    $numbers = $this->model->where("merchant_id", $merchant['pid'])
                        ->where("status", OrderStatusEnum::USER_HAS_PAID)
                        ->count();
                }
            } else {
                // 是管理员
                $numbers = $this->model->where("status", OrderStatusEnum::USER_HAS_PAID)
                    ->count();
            }
        }

        $result['num'] = $numbers;
        $this->success("", "", $result);
    }

    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        //如果发送的来源是 Selectpage，则转发到 Selectpage
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }

        $merchant = $this->auth->getUserInfo();

        [$where, $sort, $order, $offset, $limit] = $this->buildparams();
        $list = $this->model
            ->where($where)
            ->where("status", "<>", OrderStatusEnum::WAIT_USER_PAYMENT)
            ->where(function ($query) use ($merchant) {
                if (!$merchant['adminswitch']) {
                    // 不是管理员
                    if (!$merchant['pid']) {
                        $query->where("merchant_id", $merchant['id']);
                    } else {
                        $query->where("merchant_id", $merchant['pid']);
                    }
                }
            })
            ->order($sort, $order)
            ->paginate($limit);

        foreach ($list as $item) {
            $item->commissionrate = ($item->commissionrate) . " %";
        }

        $result = ['total' => $list->total(), 'rows' => $list->items()];
        return json($result);
    }

    // 订单核销
    public function pack($ids)
    {
        $order = $this->model->find($ids);
        if (empty($order)) {
            $this->error(__("Order does not exist"));
        }

        if ($order->status == OrderStatusEnum::SUCCESS_CHECK) {
            $this->error(__("The order has been check, Do not repeat operation"));
        }

        if ($order->status == OrderStatusEnum::SUCCESS_PACK) {
            $this->error(__("The order has been pack, Do not repeat operation"));
        }

        if ($order->status != OrderStatusEnum::USER_HAS_PAID) {
            $this->error(__("Please complete the payment first"));
        }

        $order->status = OrderStatusEnum::SUCCESS_PACK;
        $order->pack_time = time();
        $order->save();
        $this->success(__("Operation successful"));
    }

    // 订单核销
    public function check($ids)
    {
        $order = $this->model->find($ids);
        if (empty($order)) {
            $this->error(__("Order does not exist"));
        }

        if ($order->status == OrderStatusEnum::SUCCESS_CHECK) {
            $this->error(__("The order has been check, Do not repeat operation"));
        }

        if ($order->status == OrderStatusEnum::WAIT_USER_PAYMENT) {
            $this->error(__("Please complete the payment first"));
        }

        if ($order->status == OrderStatusEnum::ORDER_CANCEL) {
            $this->error(__("The order has been cancel"));
        }

        if ($order->status != OrderStatusEnum::USER_HAS_PAID
            && $order->status != OrderStatusEnum::SUCCESS_PACK
        ) {
            $this->error(__("Order status has changed, please refresh the page"));
        }

        Db::startTrans();
        try {
            $order->status = OrderStatusEnum::SUCCESS_CHECK;
            $order->check_time = time();

            // 商鋪增加餘額、更新完成訂單數量
            // todo 余额更新方式需要优化
            $merchant = Merchant::find($order->merchant_id);
            $commission = bcmul($order->payment_amount, $order->commissionrate/100, 2);
            $_merchantBalance = bcsub($order->payment_amount, $commission, 2);

            $order->commission = $commission;
            $order->merchant_balance = $_merchantBalance;
            $order->save();

            $beforeMerchantBalance = $merchant->balance;
            $balance = bcadd($merchant->balance, $_merchantBalance, 2);
            $merchant->balance = $balance;
            $merchant->salesvolume += 1;
            $merchant->save();

            // 記錄商户餘額變動
            Merchantbalancelog::create([
                "merchant_id"   => $order->merchant_id,
                "order_id"      => $order->id,
                "before_amount" => $beforeMerchantBalance,
                "amount"        => $_merchantBalance,
                "after_amount"  => $balance,
                "type"          => BalanceChangeTypeEnum::ADD,
                "sourcetype"    => BalanceSourceTypeEnum::USER_PAY,
            ]);

            // 獲取最新一條記錄
            $systemBalance = Systembalancelog::order("id", "desc")->find();

            $systemBeforeBalance = $systemBalance->after_amount ?? 0;
            $systemAfterBalance = bcadd($systemBeforeBalance, $commission, 2);
            // 記錄系統餘額變動
            Systembalancelog::create([
                "merchant_id"   => $order->merchant_id,
                "before_amount" => $systemBeforeBalance,
                "amount"        => $commission,
                "after_amount"  => $systemAfterBalance,
                "type"          => BalanceChangeTypeEnum::ADD,
                "sourcetype"    => BalanceSourceTypeEnum::COMMISSION,
            ]);

            Db::commit();
        } catch (\Exception $e) {
            Log::error("核验失败：". $e->getMessage());
            Db::rollback();
            $this->error(__("Operation failed"));
        }

        $this->success(__("Operation successful"));
    }

    // 订单取消
    public function cancel($ids)
    {
        $order = $this->model->find($ids);
        if (empty($order)) {
            $this->error(__("Order does not exist"));
        }

        if ($order->status == OrderStatusEnum::ORDER_CANCEL) {
            $this->error(__("The order has been cancel, Do not repeat operation"));
        }

        if ($order->status == OrderStatusEnum::WAIT_USER_PAYMENT) {
            $this->error(__("Please complete the payment first"));
        }

        Db::startTrans();
        try {
            $paymentStrategy = PaymentFactory::strategy($order->payment_type);
            $result = (new PaymentContext($paymentStrategy))->refund($order->toArray());

            if ($result !== true) {
                Log::error("退款失败：" . $result);
                $this->error(__("Refund failed"));
            }

            $order->payment_status = OrderPaymentStatusEnum::APPLY_REFUND;
            $order->status = OrderStatusEnum::ORDER_CANCEL;
            $order->cancel_type = OrderCancelTypeEnum::PLATFORM_CANCEL;
            $order->cancel_time = time();
            $order->is_refund = 1;
            $order->save();

            // 更新店鋪盲盒庫存
            $orderGoods = OrderGoods::where("order_id", $order->id)->select();
            foreach ($orderGoods as $_orderGoods) {
                $goods = Goods::find($_orderGoods->goods_id);

                $goods->count += $_orderGoods->count;
                $goods->save();
            }

            OrderRefundModel::create([
                "order_id"     => $order->id,
                "user_id"      => $order->user_id,
                "merchant_id"  => $order->merchant_id,
                "status"       => OrderRefundAuditStatusEnum::NO_AUDIT,
                "refundtime"   => time(),
                "refundstatus" => OrderRefundStatusEnum::SUCCESS,
            ]);

            Db::commit();
        } catch (\Stripe\Exception\ApiErrorException $e) {
            Db::rollback();

            Log::error("退款失敗：" . $e->getMessage());
            $this->error($e->getMessage());
        } catch (\Exception $e) {
            Db::rollback();

            Log::error("退款失敗：" . $e->getMessage());
            $this->error(__("Operation failed"));
        }

        // 推送
        $users = User::field("exponent_push_token")
            ->where("is_allow_push_notify", 1)
            ->where("id", $order->user_id)
            ->column("exponent_push_token", "id");

        $pushData = [
            "type" => 2,
            "url"  => "order"
        ];
        (new ExpoPushService())->push("NextChoc App", "Order canceled successfully", $users, "order_cancel", $pushData);

        $this->success(__("Operation successful"));
    }

    // 订单退款
    public function refund($ids)
    {
        $order = $this->model->find($ids);
        if (empty($order)) {
            $this->error(__("Order does not exist"));
        }

        if ($order->status == OrderStatusEnum::ORDER_CANCEL) {
            $this->error(__("The order has been cancel, Do not repeat operation"));
        }

        if ($order->status == OrderStatusEnum::WAIT_USER_PAYMENT) {
            $this->error(__("Please complete the payment first"));
        }

        if ($order->status != OrderStatusEnum::SUCCESS_PACK) {
            $this->error(__("Only ready orders can be refunded"));
        }

        Db::startTrans();
        try {
            $paymentStrategy = PaymentFactory::strategy($order->payment_type);
            $result = (new PaymentContext($paymentStrategy))->refund($order->toArray());

            if ($result !== true) {
                Log::error("退款失败：" . $result);
                $this->error(__("Refund failed"));
            }

            $order->payment_status = OrderPaymentStatusEnum::APPLY_REFUND;
            $order->status = OrderStatusEnum::ORDER_CANCEL;
            $order->cancel_type = OrderCancelTypeEnum::APPLY_REFUND;
            $order->cancel_time = time();
            $order->is_refund = 1;
            $order->save();

            // 更新店鋪盲盒庫存
            $orderGoods = OrderGoods::where("order_id", $order->id)->select();
            foreach ($orderGoods as $_orderGoods) {
                $goods = Goods::find($_orderGoods->goods_id);

                $goods->count += $_orderGoods->count;
                $goods->save();
            }

            OrderRefundModel::create([
                "order_id"     => $order->id,
                "user_id"      => $order->user_id,
                "merchant_id"  => $order->merchant_id,
                "status"       => OrderRefundAuditStatusEnum::NO_AUDIT,
                "refundtime"   => time(),
                "refundstatus" => OrderRefundStatusEnum::SUCCESS,
            ]);

            Db::commit();
        } catch (\Stripe\Exception\ApiErrorException $e) {
            Db::rollback();

            Log::error("退款失敗：" . $e->getMessage());
            $this->error($e->getMessage());
        } catch (\Exception $e) {
            Db::rollback();

            Log::error("退款失敗：" . $e->getMessage());

            $this->error(__("Operation failed"));
        }

        // 推送
        $users = User::field("exponent_push_token")
            ->where("is_allow_push_notify", 1)
            ->where("id", $order->user_id)
            ->column("exponent_push_token", "id");

        $pushData = [
            "type" => 2,
            "url"  => "order"
        ];
        (new ExpoPushService())->push("NextChoc App", "Order canceled successfully", $users, "order_cancel", $pushData);

        $this->success(__("Operation successful"));
    }
}
