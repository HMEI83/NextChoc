<?php

namespace app\admin\controller\activity;

use app\admin\model\User;
use app\api\service\expo\push\ExpoPushService;
use app\common\controller\Backend;
use app\common\model\ExpoPushRecord;
use think\Db;
use think\Exception;
use think\exception\PDOException;
use think\exception\ValidateException;

/**
 * 活动推送记录
 *
 * @icon fa fa-circle-o
 */
class Activitypush extends Backend
{

    /**
     * Activitypush模型对象
     * @var \app\admin\model\activity\Activitypush
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\activity\Activitypush;
        $this->view->assign("typeList", $this->model->getTypeList());
    }

    public function add()
    {
        ini_set('memory_limit', '-1');
        if (false === $this->request->isPost()) {
            return $this->view->fetch();
        }
        $params = $this->request->post('row/a');
        if (empty($params)) {
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $params = $this->preExcludeFields($params);

        if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
            $params[$this->dataLimitField] = $this->auth->id;
        }

        if (!empty($params['data'])) {
            /*if (empty(json_decode($params['data']))) {
                $this->error(__("Please enter a valid JSON string"));
            }*/
            $preg = "/http[s]?:\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is";

            if(!preg_match($preg, $params['data'])){
                $this->error(__("Please enter a valid URL"));
            }
        }

        $pushData = [
            "type" => $params['type'],
            "url"  => $params['data']
        ];
        $params['data'] = json_encode($pushData, 256);
        $result = false;
        Db::startTrans();
        try {
            //是否采用模型验证
            if ($this->modelValidate) {
                $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                $this->model->validateFailException()->validate($validate);
            }
            $result = $this->model->allowField(true)->save($params);

            $_data = [];
            /*$_users = User::field("exponent_push_token")->column("exponent_push_token", "id");
            foreach ($_users as $_uid => $_token) {
                $_data[] = [
                    "user_id"           => $_uid,
                    "exponentpushtoken" => $_token ?? "",
                    "eventtype"         => "activity_push",
                    "title"             => $params['title'],
                    "body"              => $params['content'],
                    "successswitch"     => 1,
                    "exception"         => "",
                ];
            }
            (new ExpoPushRecord())->saveAll($_data);*/

            Db::commit();

            // 遍歷所有用户 push
            $users = User::field("exponent_push_token")
                ->where("is_allow_promot_notify", 1)
                ->where("exponent_push_token", "<>", "")
                ->column("exponent_push_token", "id");

            $count = (new ExpoPushService())->push($params['title'], $params['content'], $users, "activity_push", $pushData);
        } catch (\Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        if ($result === false) {
            $this->error(__('No rows were inserted'));
        }
        $this->success(__("Successfully pushed to %d users", $count));
    }
}
