<?php

namespace app\admin\controller\goods;

use app\admin\model\Admin;
use app\common\controller\Backend;
use think\exception\DbException;
use think\response\Json;

/**
 * 商品分类管理
 *
 * @icon fa fa-circle-o
 */
class Category extends Backend
{
    protected $noNeedLogin = ['getCategoryOne', 'getCategoryTwo'];

    protected $noNeedRight = '*';

    /**
     * Category模型对象
     * @var \app\admin\model\goods\Category
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\goods\Category;
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    public function getCategoryOne()
    {
        if ($this->request->request('keyField')) {
            $this->whereData['goods_category_id'] = ["=", "0"];
            return $this->selectpage();
        }

        $keyValue = $this->request->request('keyValue');

        if ($keyValue === '0') {
            return json([
                "total" => 0, "list" => [
                    []
                ]
            ]);
        }

        if (!empty($keyValue)) {
            return json([
                "total" => 1, "list" => [
                    [
                        "id"    => $keyValue,
                        "goods_category_name" => \app\admin\model\goods\Category::where("id", $keyValue)->value("goods_category_name"),
                    ]
                ]
            ]);
        }

        list($where, $sort, $order, $offset, $limit) = $this->buildparams();

        $list = \app\admin\model\goods\Category::field('id, goods_category_name')
            // ->where("goods_category_id",0)
            ->where("status", "1")
            ->where($where)
            ->paginate($limit);

        return json(array("total" => $list->total(), "list" => $list->items()));
    }

    public function getCategoryTwo()
    {
        //如果发送的来源是 Selectpage，则转发到 Selectpage
        if ($this->request->request('keyField')) {
            $this->whereData['goods_category_id'] = ["<>", "0"];
            return $this->selectpage();
        }

        $keyValue = $this->request->request('keyValue');

        if ($keyValue === '0') {
            return json([
                "total" => 0, "list" => [
                    []
                ]
            ]);
        }

        if (!empty($keyValue)) {
            return json([
                "total" => 1, "list" => [
                    [
                        "id"    => $keyValue,
                        "goods_category_name" => \app\admin\model\goods\Category::where("id", $keyValue)->value("goods_category_name"),
                    ]
                ]
            ]);
        }

        list($where, $sort, $order, $offset, $limit) = $this->buildparams();

        $list = \app\admin\model\goods\Category::field('id, goods_category_name')
            ->where("goods_category_id", "<>",0)
            ->where("status", "1")
            ->where($where)
            ->paginate($limit);

        return json(array("total" => $list->total(), "list" => $list->items()));
    }

    public function getCategoryIdByAdminId()
    {
        $adminId = $this->request->param("admin_id");

        return Admin::where("id", $adminId)->value("category_id", 0);
    }

    /**
     * 查看
     *
     * @return string|Json
     * @throws \think\Exception
     * @throws DbException
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        //如果发送的来源是 Selectpage，则转发到 Selectpage
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }
        [$where, $sort, $order, $offset, $limit] = $this->buildparams();
        $list = $this->model
            ->where("goods_category_id", 0)
            ->where($where)
            ->order($sort, $order)
            ->paginate($limit);

        $result = ['total' => $list->total(), 'rows' => $list->items()];
        return json($result);
    }
}
