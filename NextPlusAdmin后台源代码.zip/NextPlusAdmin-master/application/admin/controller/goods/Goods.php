<?php

namespace app\admin\controller\goods;

use app\admin\model\AuthGroupAccess;
use app\admin\model\merchant\Merchant;
use app\admin\model\order\OrderGoods;
use app\common\controller\Backend;
use fast\Random;
use think\Db;
use think\exception\DbException;
use think\exception\PDOException;
use think\exception\ValidateException;
use think\response\Json;

/**
 * 盲盒管理
 *
 * @icon fa fa-circle-o
 */
class Goods extends Backend
{

    /**
     * Goods模型对象
     * @var \app\admin\model\goods\Goods
     */
    protected $model = null;

    /**
     * Multi方法可批量修改的字段
     */
    protected $multiFields = 'shelfswitch';

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\goods\Goods;
        $this->view->assign("statusList", $this->model->getShelfswitchList());
    }

    /**
     * 添加
     *
     * @return string
     * @throws \think\Exception
     */
    public function add()
    {
        if (false === $this->request->isPost()) {
            return $this->view->fetch();
        }
        $params = $this->request->post('row/a');
        if (empty($params)) {
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $params = $this->preExcludeFields($params);

        if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
            $params[$this->dataLimitField] = $this->auth->id;
        }
        $result = false;
        Db::startTrans();
        try {
            $params['bagginghours'] = Merchant::where("id", $params['admin_id'])->value("businesshours");

            //是否采用模型验证
            if ($this->modelValidate) {
                $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                $this->model->validateFailException()->validate($validate);
            }
            $result = $this->model->allowField(true)->save($params);
            Db::commit();
        } catch (ValidateException|PDOException|Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        if ($result === false) {
            $this->error(__('No rows were inserted'));
        }
        $this->success();
    }

    /**
     * 编辑
     *
     * @param $ids
     * @return string
     * @throws DbException
     * @throws \think\Exception
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds) && !in_array($row[$this->dataLimitField], $adminIds)) {
            $this->error(__('You have no permission'));
        }
        if (false === $this->request->isPost()) {
            $businesshours = explode("-", $row['bagginghours']);
            $row['openinghours'] = $businesshours[0];
            $row['closinghours'] = $businesshours[1];

            $this->view->assign('row', $row);
            return $this->view->fetch();
        }
        $params = $this->request->post('row/a');
        if (empty($params)) {
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $params = $this->preExcludeFields($params);
        $result = false;
        Db::startTrans();
        try {
            $params['bagginghours'] = Merchant::where("id", $params['merchant_id'])->value("businesshours");

            //是否采用模型验证
            if ($this->modelValidate) {
                $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                $row->validateFailException()->validate($validate);
            }
            $result = $row->allowField(true)->save($params);
            Db::commit();
        } catch (ValidateException|PDOException|Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        if (false === $result) {
            $this->error(__('No rows were updated'));
        }
        $this->success();
    }

    /**
     * 查看
     *
     * @return string|Json
     * @throws \think\Exception
     * @throws DbException
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        //如果发送的来源是 Selectpage，则转发到 Selectpage
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }
        [$where, $sort, $order, $offset, $limit] = $this->buildparams();

        $merchant = $this->auth->getUserInfo();

        $list = $this->model
            ->with([
                "admin",
                "goodsCategoryOne",
                "goodsCategoryOne",
            ])
            ->where($where)
            ->where(function ($query) use ($merchant) {
                if (!$merchant['adminswitch']) {
                    // 不是管理员
                    if (!$merchant['pid']) {
                        $query->where("admin_id", $merchant['id']);
                    } else {
                        $query->where("admin_id", $merchant['pid']);
                    }
                }
            })
            ->order($sort, $order)
            ->paginate($limit);

        foreach ($list as $item) {
            $item->merchant_name = $item->admin->username;
            $item->goods_category_one_name = $item->goods_category_one->goods_category_name;
            $item->goods_category_two_name = $item->goods_category_two->goods_category_name;
        }

        $result = ['total' => $list->total(), 'rows' => $list->items()];
        return json($result);
    }

    /**
     * 商品详情
     *
     * @param $ids
     *
     * @return string
     */
    public function detail($ids)
    {
        $rows = OrderGoods::where("order_id", $ids)
            ->select();

        foreach ($rows as $row) {
            $row->cover_image = cdnurl($row->cover_image, true);
        }

        $this->view->assign("rows", $rows);
        return $this->view->fetch();
    }

    /**
     * 复制盲盒
     *
     * @return void
     * @throws \think\Exception
     */
    public function duplicateGoods()
    {
        $id = $this->request->post("id");
        // 复制盲盒
        $goods = \app\admin\model\goods\Goods::find($id);
        if (empty($goods)) {
            $this->error(__("No Results were found"));
        }

        $data = $goods->toArray();
        $data['createtime'] = $data['updatetime'] =time();
        $data['ordercount'] = 0;
        unset($data['id']);
        $result = $this->model->allowField(true)->save($data);
        if ($result === false) {
            $this->error(__('No rows were inserted'));
        }

        $this->success();
    }
}
