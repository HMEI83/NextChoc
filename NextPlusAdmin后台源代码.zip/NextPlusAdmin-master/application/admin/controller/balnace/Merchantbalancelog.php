<?php

namespace app\admin\controller\balnace;

use app\common\controller\Backend;

/**
 * 商铺金额变动管理
 *
 * @icon fa fa-circle-o
 */
class Merchantbalancelog extends Backend
{

    /**
     * Merchantbalancelog模型对象
     * @var \app\admin\model\balnace\Merchantbalancelog
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\balnace\Merchantbalancelog;
        $this->view->assign("typeList", $this->model->getTypeList());
        $this->view->assign("sourcetypeList", $this->model->getSourcetypeList());
    }

    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        //如果发送的来源是 Selectpage，则转发到 Selectpage
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }

        $merchant = $this->auth->getUserInfo();

        [$where, $sort, $order, $offset, $limit] = $this->buildparams();
        $list = $this->model
            ->where($where)
            ->where(function ($query) use ($merchant) {
                if (!$merchant['adminswitch']) {
                    // 不是管理员
                    if (!$merchant['pid']) {
                        $query->where("merchant_id", $merchant['id']);
                    } else {
                        $query->where("merchant_id", $merchant['pid']);
                    }
                }
            })
            ->order($sort, $order)
            ->paginate($limit);

        $balance = 0;
        foreach ($list as $item) {
            $balance = bcadd($balance, $item->amount,2);
        }
        $totalBalance = $this->model
            ->where($where)
            ->where(function ($query) use ($merchant) {
                if (!$merchant['adminswitch']) {
                    // 不是管理员
                    if (!$merchant['pid']) {
                        $query->where("merchant_id", $merchant['id']);
                    } else {
                        $query->where("merchant_id", $merchant['pid']);
                    }
                }
            })
            ->sum("amount");

        $result = ['total' => $list->total(), 'rows' => $list->items(), "extend" => ['balance' => $balance, 'totalBalance' => $totalBalance]];
        return json($result);
    }
}
