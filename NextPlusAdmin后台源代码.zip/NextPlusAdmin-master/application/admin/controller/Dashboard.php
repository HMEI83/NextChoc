<?php

namespace app\admin\controller;

use app\admin\model\Admin;
use app\admin\model\attendance\Attendance;
use app\admin\model\balnace\Merchantbalancelog;
use app\admin\model\balnace\Systembalancelog;
use app\admin\model\order\Order;
use app\admin\model\User;
use app\common\controller\Backend;
use app\common\enum\order\OrderCancelTypeEnum;
use app\common\enum\order\OrderStatusEnum;
use app\common\model\Attachment;
use fast\Date;
use think\Db;

/**
 * 控制台
 *
 * @icon   fa fa-dashboard
 * @remark 用于展示当前系统中的统计数据、统计报表及重要实时数据
 */
class Dashboard extends Backend
{

    /**
     * 查看
     */
    public function index()
    {
        try {
            \think\Db::execute("SET @@sql_mode='';");
        } catch (\Exception $e) {

        }
        $column = [];
        $starttime = Date::unixtime('day', -6);
        $endtime = Date::unixtime('day', 0, 'end');
        $joinlist = Db("user")->where('jointime', 'between time', [$starttime, $endtime])
            ->field('jointime, status, COUNT(*) AS nums, DATE_FORMAT(FROM_UNIXTIME(jointime), "%Y-%m-%d") AS join_date')
            ->group('join_date')
            ->select();
        for ($time = $starttime; $time <= $endtime;) {
            $column[] = date("Y-m-d", $time);
            $time += 86400;
        }
        $userlist = array_fill_keys($column, 0);
        foreach ($joinlist as $k => $v) {
            $userlist[$v['join_date']] = $v['nums'];
        }

        $dbTableList = Db::query("SHOW TABLE STATUS");
        $addonList = get_addon_list();
        $totalworkingaddon = 0;
        $totaladdon = count($addonList);
        foreach ($addonList as $index => $item) {
            if ($item['state']) {
                $totalworkingaddon += 1;
            }
        }

        $months = Date::getMonth();
        $startMonth = $months['startTime'];
        $endMonth = $months['endTime'];

        // 获取过去一个月的订单数量
        $totalOrders = Order::field("count(*) as count, FROM_UNIXTIME(createtime, '%Y-%m-%d') as date")
            ->where("status", "<>",OrderStatusEnum::WAIT_USER_PAYMENT)
            ->where('createtime', 'between', [$startMonth, $endMonth])
            ->group("date")
            ->select();
        $totalOrders = collection($totalOrders)->column("count", "date");

        // 平台盈利
        $totalBalance = Systembalancelog::field("sum(amount) as amount, FROM_UNIXTIME(createtime, '%Y-%m-%d') as date")
            ->where('createtime', 'between', [$startMonth, $endMonth])
            ->group("date")
            ->select();
        $totalBalance = collection($totalBalance)->column("amount", "date");

        // 平台盈利
        $merchantTotalBalance = Merchantbalancelog::field("sum(amount) as amount, FROM_UNIXTIME(createtime, '%Y-%m-%d') as date")
            ->where('createtime', 'between', [$startMonth, $endMonth])
            ->group("date")
            ->select();
        $merchantTotalBalance = collection($merchantTotalBalance)->column("amount", "date");

        $month = array();
        for ($i = $startMonth; $i <= Date::unixtime("day", 0, "end"); $i += 60 * 60 * 24) {
            $month[] = date('Y-m-d', $i);
        }

        foreach ($month as $_month) {
            if (!isset($totalOrders[$_month])) {
                $totalOrders[$_month] = 0;
            }

            if (!isset($totalBalance[$_month])) {
                $totalBalance[$_month] = 0;
            }

            if (!isset($merchantTotalBalance[$_month])) {
                $merchantTotalBalance[$_month] = 0;
            }
        }
        ksort($totalOrders);
        ksort($totalBalance);
        ksort($merchantTotalBalance);

        $this->view->assign([
            // 当月总订单数
            "total_orders_of_the_month" => Order::where("createtime", "between time", [$startMonth, $endMonth])->where("status", "<>",OrderStatusEnum::WAIT_USER_PAYMENT)->count(),
            "wait_orders_of_the_month" => Order::where("createtime", "between time", [$startMonth, $endMonth])->where("status",OrderStatusEnum::USER_HAS_PAID)->count(),
            "checked_orders_of_the_month" => Order::where("createtime", "between time", [$startMonth, $endMonth])->where("status", OrderStatusEnum::SUCCESS_CHECK)->count(),
            "apply_refund_orders_of_the_month" => Order::where("createtime", "between time", [$startMonth, $endMonth])->where("status", OrderStatusEnum::ORDER_CANCEL)
                ->where("cancel_type", OrderCancelTypeEnum::APPLY_REFUND)
                ->count(),
            "cancel_orders_of_the_month" => Order::where("createtime", "between time", [$startMonth, $endMonth])->where("status", OrderStatusEnum::ORDER_CANCEL)
                ->where("cancel_type", OrderCancelTypeEnum::PLATFORM_CANCEL)
                ->count(),

            "total_orders_of_the_day" => Order::whereTime("createtime", "today")->where("status", "<>",OrderStatusEnum::WAIT_USER_PAYMENT)->count(),
            "wait_orders_of_the_day" => Order::whereTime("createtime", "today")->where("status",OrderStatusEnum::USER_HAS_PAID)->count(),
            "checked_orders_of_the_day" => Order::whereTime("createtime", "today")->where("status", OrderStatusEnum::SUCCESS_CHECK)->count(),
            "apply_refund_orders_of_the_day" => Order::whereTime("createtime", "today")->where("status", OrderStatusEnum::ORDER_CANCEL)
                ->where("cancel_type", OrderCancelTypeEnum::APPLY_REFUND)
                ->count(),
            "cancel_orders_of_the_day" => Order::whereTime("createtime", "today")->where("status", OrderStatusEnum::ORDER_CANCEL)
                ->where("cancel_type", OrderCancelTypeEnum::PLATFORM_CANCEL)
                ->count(),

            // 当日平台盈利
            "platform_profit_day" => Systembalancelog::whereTime("createtime", "today")->sum("amount"),

            // 当日商户盈利
            "merchant_profit_day" => Merchantbalancelog::whereTime("createtime", "today")->sum("amount"),

            // 当月平台盈利
            "platform_profit_month" => Systembalancelog::where("createtime", "between time", [$startMonth, $endMonth])->sum("amount"),

            // 当月商户盈利
            "merchant_profit_month" => Merchantbalancelog::where("createtime", "between time", [$startMonth, $endMonth])->sum("amount"),

            'totaluser'         => User::count(),
            'totaladdon'        => $totaladdon,
            'totaladmin'        => Admin::where("adminswitch", "1")->count(),
            "totalmerchant"     => Admin::where("adminswitch", "0")->where("pid", 0)->count(),
            'totalcategory'     => \app\common\model\Category::count(),
            'todayusersignup'   => User::whereTime('jointime', 'today')->count(),
            'todayuserlogin'    => User::whereTime('logintime', 'today')->count(),
            'sevendau'          => User::whereTime('jointime|logintime|prevtime', '-7 days')->count(),
            'thirtydau'         => User::whereTime('jointime|logintime|prevtime', '-30 days')->count(),
            'threednu'          => User::whereTime('jointime', '-3 days')->count(),
            'sevendnu'          => User::whereTime('jointime', '-7 days')->count(),
            'dbtablenums'       => count($dbTableList),
            'dbsize'            => array_sum(array_map(function ($item) {
                return $item['Data_length'] + $item['Index_length'];
            }, $dbTableList)),
            'totalworkingaddon' => $totalworkingaddon,
            'attachmentnums'    => Attachment::count(),
            'attachmentsize'    => Attachment::sum('filesize'),
            'picturenums'       => Attachment::where('mimetype', 'like', 'image/%')->count(),
            'picturesize'       => Attachment::where('mimetype', 'like', 'image/%')->sum('filesize'),
        ]);

        $this->assignconfig('column', array_keys($userlist));
        $this->assignconfig('month', array_values($month));
        $this->assignconfig('userdata', array_values($userlist));

        $this->assignconfig('total_orders', array_values($totalOrders));
        $this->assignconfig('total_balance', array_values($totalBalance));
        $this->assignconfig('merchant_total_balance', array_values($merchantTotalBalance));

        return $this->view->fetch();
    }

}
