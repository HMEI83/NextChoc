<?php

namespace app\admin\controller\user;

use app\common\controller\Backend;

/**
 * 用户地址管理
 *
 * @icon fa fa-circle-o
 */
class Address extends Backend
{
    protected $searchFields = "location";

    /**
     * Address模型对象
     * @var \app\admin\model\user\Address
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\user\Address;
    }
}
