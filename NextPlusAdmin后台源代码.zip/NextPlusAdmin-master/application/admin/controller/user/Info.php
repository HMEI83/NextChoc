<?php

namespace app\admin\controller\user;

use app\common\controller\Backend;
use think\Db;

/**
 * 用户信息
 *
 * @icon fa fa-circle-o
 */
class Info extends Backend
{
    /**
     * Info模型对象
     * @var \app\admin\model\user\Info
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\user\Info;
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    /**
     * @param $ids
     *
     * @return string
     * @throws \think\Exception
     * @throws \think\exception\DbException
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        $this->modelValidate = true;
        if (!$row) {
            $this->error(__('No Results were found'));
        }

        if ($this->request->isAjax()) {
            Db::startTrans();
            try {
                $params = $this->request->post('row/a');

                // 记录操作人
                $row->admin_id = $this->auth->id;
                $row->admin_name = $this->auth->username;
                $row->audit_time = time();
                $row->status = $params['status'];
                $row->save();

                if ($params['status'] == 1) {
                    \app\admin\model\User::where("id", $row->user_id)->update(["is_auth_success" => 1]);
                }
                Db::commit();
            } catch (\Exception $e) {

                Db::rollback();
                $this->error("Operation failed");
            }
        }

        return parent::edit($ids);
    }
}
