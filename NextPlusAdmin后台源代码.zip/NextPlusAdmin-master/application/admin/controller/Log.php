<?php

namespace app\admin\controller;

use app\admin\model\AdminLog;
use app\common\controller\Backend;

class Log extends Backend
{
    /**
     * Merchant模型对象
     * @var \app\admin\model\merchant\Merchant
     */
    protected $model = null;

    protected $childrenGroupIds = [];
    protected $childrenAdminIds = [];
    protected $merchantChildrenIds = [];

    public function _initialize()
    {
        parent::_initialize();
        $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
        $this->childrenGroupIds = $this->auth->getChildrenGroupIds(true);
        $this->merchantChildrenIds = $this->auth->getMerchantChildrenIds();

        $this->model = new AdminLog;
    }

    /**
     * 商户管理日志
     *
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\DbException
     */
    public function merchant()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);

        $merchant = $this->auth->getUserInfo();
        if ($this->request->isAjax()) {
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $list = $this->model
                ->where($where)
                ->where(function ($query) use ($merchant) {
                    if (!$merchant['adminswitch']) {
                        // 不是管理员
                        $query->where('admin_id', 'in', $this->merchantChildrenIds);
                    } else {
                        $query->where('admin_id', 'in', $this->childrenAdminIds);
                    }
                })
                ->where("url", "like", "%merchant%")
                ->order($sort, $order)
                ->paginate($limit);

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }

    /**
     * 訂單管理日誌
     *
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\DbException
     */
    public function order()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);

        $merchant = $this->auth->getUserInfo();
        if ($this->request->isAjax()) {
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $list = $this->model
                ->where($where)
                ->where(function ($query) use ($merchant) {
                    if (!$merchant['adminswitch']) {
                        // 不是管理员
                        $query->where('admin_id', 'in', $this->merchantChildrenIds);
                    } else {
                        $query->where('admin_id', 'in', $this->childrenAdminIds);
                    }
                })
                ->where("url", "like", "%order%")
                ->order($sort, $order)
                ->paginate($limit);

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }

    /**
     * 商品管理日誌
     *
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\DbException
     */
    public function goods()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);

        $merchant = $this->auth->getUserInfo();
        if ($this->request->isAjax()) {
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $list = $this->model
                ->where($where)
                ->where(function ($query) use ($merchant) {
                    if (!$merchant['adminswitch']) {
                        // 不是管理员
                        $query->where('admin_id', 'in', $this->merchantChildrenIds);
                    } else {
                        $query->where('admin_id', 'in', $this->childrenAdminIds);
                    }
                })
                ->where("url", "like", "%goods%")
                ->order($sort, $order)
                ->paginate($limit);

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }
}