<?php

namespace app\admin\controller\merchant;

use app\admin\model\AuthGroupAccess;
use app\admin\model\balnace\Systembalancelog;
use app\admin\model\balnace\Merchantbalancelog;
use app\admin\model\balnace\Withdraw;
use app\api\library\Redis;
use app\common\controller\Backend;
use app\common\enum\balance\BalanceChangeTypeEnum;
use app\common\enum\balance\BalanceSourceTypeEnum;
use fast\Random;
use Stripe\Exception\ApiErrorException;
use think\Db;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Env;
use think\Exception;
use think\exception\DbException;
use think\exception\PDOException;
use think\exception\ValidateException;
use think\response\Json;

/**
 * 管理员管理
 *
 * @icon fa fa-circle-o
 */
class Merchant extends Backend
{
    /**
     * Merchant模型对象
     * @var \app\admin\model\merchant\Merchant
     */
    protected $model = null;

    protected $geoMerchantKey = "";

    protected $merchantKey = "";

    public function _initialize()
    {
        parent::_initialize();

        $this->geoMerchantKey = config("app.geo_merchant_key");
        $this->merchantKey = config("app.merchant_key");

        $this->model = new \app\admin\model\merchant\Merchant;
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    /**
     * 查看
     *
     * @return string|Json
     * @throws \think\Exception
     * @throws DbException
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        //如果发送的来源是 Selectpage，则转发到 Selectpage
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }

        $merchant = $this->auth->getUserInfo();

        [$where, $sort, $order, $offset, $limit] = $this->buildparams();
        $list = $this->model
            ->where("adminswitch", 0)
            ->where("pid", "=", 0)
            ->where($where)
            ->where(function ($query) use ($merchant) {
                if (!$merchant['adminswitch']) {
                    // 不是管理员
                    if (!$merchant['pid']) {
                        $query->where("id", $merchant['id']);
                    } else {
                        $query->where("id", $merchant['pid']);
                    }
                }
            })
            ->order($sort, $order)
            ->paginate($limit);

        foreach ($list as $k => $v) {
            $v->commissionrate_format = $v->commissionrate. " %";
        }

        $result = ['total' => $list->total(), 'rows' => $list->items()];
        return json($result);
    }

    /**
     * 添加
     *
     * @return string
     * @throws \think\Exception
     */
    public function add()
    {
        if (false === $this->request->isPost()) {
            return $this->view->fetch();
        }
        $params = $this->request->post('row/a');
        if (empty($params)) {
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $params = $this->preExcludeFields($params);

        if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
            $params[$this->dataLimitField] = $this->auth->id;
        }

        $redis = Redis::instance()->redis;
        $result = false;
        Db::startTrans();
        try {
            $params['salt'] = Random::alnum();
            $params['password'] = md5(md5($params['password']) . $params['salt']);

            $params['openinghours'] = date('H:i', strtotime($params['openinghours']));
            $params['closinghours'] = date('H:i', strtotime($params['closinghours']));

            $params['businesshours'] = $params['openinghours'] . "-" . $params['closinghours'];
            $params['endtime'] = strtotime($params['endtime']);

            //是否采用模型验证
            if ($this->modelValidate) {
                $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                $this->model->validateFailException()->validate($validate);
            }
            $result = $this->model->allowField(true)->save($params);

            $uid = $this->model->getLastInsID();

            // 将经纬度存入Redis
            $redis->geoAdd($this->geoMerchantKey, $params['lng'], $params['lat'], $this->merchantKey.$uid);

            // 注册权限
            AuthGroupAccess::create([
                "uid" => $uid,
                // 商户组分组 ID
                "group_id" => 6,
            ]);
            Db::commit();
        } catch (ValidateException|PDOException|Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        if ($result === false) {
            $this->error(__('No rows were inserted'));
        }
        $this->success();
    }

    /**
     * 编辑
     *
     * @param $ids
     * @return string
     * @throws DbException
     * @throws \think\Exception
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds) && !in_array($row[$this->dataLimitField], $adminIds)) {
            $this->error(__('You have no permission'));
        }
        if (false === $this->request->isPost()) {
            $businesshours = explode("-", $row['businesshours']);
            $row['openinghours'] = $businesshours[0];
            $row['closinghours'] = $businesshours[1];

            $this->view->assign('row', $row);
            return $this->view->fetch();
        }
        $params = $this->request->post('row/a');
        if (empty($params)) {
            $this->error(__('Parameter %s can not be empty', ''));
        }
        // 覆盖经纬度
        $redis = Redis::instance()->redis;
        $params = $this->preExcludeFields($params);
        $result = false;
        Db::startTrans();
        try {
            if (!empty($params['password'])) {
                $params['salt'] = Random::alnum();
                $params['password'] = md5(md5($params['password']) . $params['salt']);
            } else {
                unset($params['password']);
            }
            $params['openinghours'] = date('H:i', strtotime($params['openinghours']));
            $params['closinghours'] = date('H:i', strtotime($params['closinghours']));

            $params['businesshours'] = $params['openinghours'] . "-" . $params['closinghours'];
            $params['endtime'] = strtotime($params['endtime']);

            // 将经纬度存入Redis
            $redis->geoAdd($this->geoMerchantKey, $params['lng'], $params['lat'], $this->merchantKey.$ids);

            //是否采用模型验证
            if ($this->modelValidate) {
                $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                $row->validateFailException()->validate($validate);
            }
            $result = $row->allowField(true)->save($params);
            Db::commit();
        } catch (ValidateException|PDOException|Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        if (false === $result) {
            $this->error(__('No rows were updated'));
        }
        $this->success();
    }

    /**
     * 删除
     *
     * @param $ids
     * @return void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function del($ids = null)
    {
        if (false === $this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        if (empty($ids)) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $pk = $this->model->getPk();
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            $this->model->where($this->dataLimitField, 'in', $adminIds);
        }
        $list = $this->model->where($pk, 'in', $ids)->select();

        $count = 0;
        Db::startTrans();
        try {
            foreach ($list as $item) {
                $count += $item->delete();
            }
            Db::commit();
        } catch (PDOException|Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        if ($count) {
            $this->success();
        }
        $this->error(__('No rows were deleted'));
    }

    // 子账号列表
    public function subaccount($ids = 0)
    {
        // 设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if (false === $this->request->isAjax()) {
            if (!empty($ids)) {
                $row = $this->model->get(['id' => $ids]);
                $this->view->assign("pid", $row->id);
            }
            return $this->view->fetch();
        }

        $pid = $this->request->param("pid");
        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        $list = $this->model
            ->where("pid", $pid)
            ->where($where)
            ->order($sort, $order)
            ->paginate($limit);
        $result = array("total" => $list->total(), "rows" => $list->items());

        return json($result);
    }

    /**
     * @return string
     */
    public function connect()
    {
        $id = $this->request->param("ids");
        $target = $this->model->find($id);
        if (empty($target)) {
            $this->error(__("Not found Merchant"));
        }

        $this->view->assign("merchant", $target->toArray());
        return $this->view->fetch();
    }

    // 创建 Stripe Connect
    public function createStripeConnect()
    {
        /**
         * 1. 创建 stripe connect
         * 2. 添加银行卡
         * 3. 同意协议
         * 4. 完善信息
         * 5. 申请提现
         */

        /**
         * 创建 Stripe Connect 需要哪些信息？
         * 1. 邮箱
         */
        $id = $this->request->param("id");
        $merchant = \app\admin\model\merchant\Merchant::find($id);
        if (empty($merchant)) {
            $this->error(__("Not found Merchant"));
        }

        if ($merchant['iscreatestripeconnect']) {
            $this->error(__("The merchant already created Stripe Connect"));
        }

        $stripeApiKey = Env::get('stripe.STRIPE_SECRET_KEY', '');
        $currency = Env::get("app.currency", "USD");

        $email = $this->request->param("email");
        // 验证邮箱有效性
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error(__("Please input correct email"));
        }

        // 设置 Stripe API 密钥
        \Stripe\Stripe::setApiKey($stripeApiKey);

        // 创建 Stripe Connect 账户
        try {
            $account = \Stripe\Account::create([
                // 账户类型
                'type'                   => 'custom',
                // 国家
                'country'                => 'AU',
                // 邮箱
                'email'                  => $email,
                // 需要的功能
                'requested_capabilities' => ['card_payments', 'transfers'],
            ]);

            // 将 Connect 账户与 Stripe_Customer 关联
            $customer = \Stripe\Customer::create([
                // 描述
                'description'            => 'NextPlus App Merchant:' . $this->auth->id,
                // Email
                'email'    => $email,
                // 用于测试的信用卡令牌
                // 'source' => 'tok_visa',
                // 关联 Stripe Customer
                'metadata' => [
                    'account_id' => $account->id,
                ],
            ]);

            // 创建与银行账户相关的令牌（银行卡直接去 Stripe 后台添加）
            /*$bankToken = \Stripe\Token::create([
                // 添加银行卡信息
                'bank_account' => [
                    // 国家
                    'country' => 'US',
                    // 货币
                    'currency' => 'usd',
                    // 持卡人名称
                    'account_holder_name' => 'Test3 User',
                    // 持卡人类型：个人
                    'account_holder_type' => 'individual',
                    // 银行账户的路由转接号码
                    'routing_number' => '110000000',
                    // 银行帐户的帐号，采用字符串形式。 必须是支票账户。
                    'account_number' => '003123456789',
                ],
            ]);*/

            // 将银行账户提现方法添加到 Connect 账户中
            /*$bankAccount = $account->external_accounts->create([
                'external_account' => $bankToken->id,
            ]);*/

            // 通过 Api 同意协议
            $stripe = new \Stripe\StripeClient($stripeApiKey);

            $result = $stripe->accounts->update(
                $account->id,
                [
                    'tos_acceptance' => [
                        'date' => time(),
                        'ip' => $this->request->ip(),
                    ],
                ]
            );

            \app\admin\model\merchant\Merchant::where("id", $merchant['id'])->update([
                "stripe_connect_email"  => $email,
                "stripe_account"        => $account->id,
                "iscreatestripeconnect" => 1,
            ]);

            $this->success(__("Operation successful"));
        } catch (ApiErrorException $e) {
            \think\Log::error("创建Stripe Connect 失败：" . $e->getMessage());
            $this->error(__("Creation failure"));
        }
    }

    public function withdraw()
    {
        $id = $this->request->param("ids");
        $merchant = \app\admin\model\merchant\Merchant::find($id);
        if (empty($merchant)) {
            $this->error(__("Not found Merchant"));
        }

        if (empty($merchant->stripe_account)) {
            $this->error(__("Please create Stripe Connect first"));
        }

        if (empty($merchant->balance) || $merchant->balance <= 1) {
            $this->error(__("Insufficient merchant balance"));
        }

        $stripeApiKey = Env::get('stripe.STRIPE_SECRET_KEY', '');
        $currency = Env::get("app.currency", "USD");
        $stripe = new \Stripe\StripeClient($stripeApiKey);

        Db::startTrans();
        try {
            $result = $stripe->payouts->create(
                [
                    'amount'   => $merchant->balance * 100,
                    'currency' => $currency,
                ],
                ['stripe_account' => $merchant->stripe_account]
            );

            $merchant->balance = 0;
            $merchant->save();

            Merchantbalancelog::create([
                "merchant_id"   => $id,
                "order_id"      => 0,
                "before_amount" => $merchant->balance,
                "amount"        => $merchant->balance,
                "after_amount"  => 0,
                "type"          => BalanceChangeTypeEnum::REDUCE,
                "sourcetype"    => BalanceSourceTypeEnum::WITHDRAW,
            ]);

            Withdraw::create([
                "merchant_id"      => $id,
                "amount"           => $merchant->balance,
                "stripe_account"   => $merchant->stripe_account,
                "status"           => 1,
                "reason"           => "",
            ]);

            Db::commit();
        } catch (ApiErrorException|\Exception $e) {
            Db::rollback();
            Withdraw::create([
                "merchant_id"      => $id,
                "amount"           => $merchant->balance,
                "stripe_account"   => $merchant->stripe_account,
                "status"           => 0,
                "reason"           => $e->getMessage(),
            ]);

            \think\Log::error("提现失败:" . $e->getMessage());
            $this->error(__("Withdrawal failure"));
        }

        $this->success();
    }
}
