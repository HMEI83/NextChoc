<?php

return [
    'Id'                => 'ID',
    'Platform'          => '平台',
    'Platform  android' => '安卓',
    'Platform ios'      => '苹果',
    'Oldversion'        => '旧版本号',
    'Newversion'        => '新版本号',
    'Packagesize'       => '包大小',
    'Content'           => '升级内容',
    'Downloadurl'       => '下载地址',
    'Enforceswitch'     => '强制更新',
    'Weigh'             => '排序',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间'
];
