<?php

return [
    'Answer'     => '问题',
    'Question'   => '答案',
    'Createtime' => '創建時間',
    'Updatetime' => '更新時間',
    'Deletetime' => '刪除時間'
];
