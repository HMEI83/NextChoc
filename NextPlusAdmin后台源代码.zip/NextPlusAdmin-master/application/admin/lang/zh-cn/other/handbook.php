<?php

return [
    'Title'      => '标题',
    'Content'    => '手册内容',
    'Updatetime' => '更新时间'
];
