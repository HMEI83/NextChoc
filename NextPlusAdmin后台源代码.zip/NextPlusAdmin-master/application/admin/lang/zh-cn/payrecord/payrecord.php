<?php

return [
    'Id'              => '主键 ID',
    'User_id'         => '用户 ID',
    'Order_no'        => '订单编号',
    'Payment_amount'  => '支付金额',
    'Payment_type'    => '支付方式',
    'Payment_time'    => '支付时间',
    'Status'          => '状态',
    'Status 1'        => '支付成功',
    'Status 2'        => '开始退款',
    'Status 3'        => '已到账',
    'Status 4'        => '退款失败',
    'Request_params'  => '请求参数',
    'Callback_params' => '回调参数',
    'Remark'          => '备注',
    'Createtime'      => '创建时间',
    'Updatetime'      => '更新时间'
];
