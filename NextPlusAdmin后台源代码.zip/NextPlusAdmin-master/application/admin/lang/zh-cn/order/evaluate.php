<?php

return [
    'merchant_id' => '商户 ID',
    'User_id'    => '用户 ID',
    'Nickname'   => '用户名称',
    'Order_id'   => '订单 ID',
    'Score'      => '评分（1-5 分）',
    'Content'    => '评价内容',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
