<?php

return [
    'Merchant_id'  => '商户 ID',
    'Order_id'    => '订单 ID',
    'User_id'     => '用户 ID',
    'Goods_id'    => '商品 ID',
    'Goods_name'  => '商品名称',
    'Cover_image' => '相框封面图',
    'Price'       => '商品价格',
    'Count'       => '加购数量',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间'
];
