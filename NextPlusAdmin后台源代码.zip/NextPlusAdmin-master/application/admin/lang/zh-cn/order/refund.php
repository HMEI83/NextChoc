<?php

return [
    'User_id'        => '用户 ID',
    'Merchant_id'    => '商户 ID',
    'Order_id'       => '订单 ID',
    'Status'         => '审核状态',
    'Status 0'       => '等待审核',
    'Status 1'       => '审核通过',
    'Status 2'       => '审核驳回',
    'Status 3'       => '无需审核',
    'Audit_id'       => '审核人 ID',
    'Audittime'      => '审核时间',
    'Refundstatus'   => '退款状态',
    'Refundstatus 0' => '无需退款',
    'Refundstatus 1' => '等待退款',
    'Refundstatus 2' => '已退款',
    'Refundstatus 3' => '退款失败',
    'Refundtime'     => '退款时间',
    'Reason'         => '失败原因',
    'Remark'         => '备注',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间'
];
