<?php

return [
    'User_id'    => '用户 ID',
    'Number'     => '信用卡号',
    'Date'       => '信用卡有效期',
    'Cvc'        => '信用卡安全码',
    'Name'       => '姓名',
    'Brand'      => '品牌名',
    'Country'    => '国家',
    'Status'     => '状态',
    'Status 0'   => '禁用',
    'Status 1'   => '正常',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];
