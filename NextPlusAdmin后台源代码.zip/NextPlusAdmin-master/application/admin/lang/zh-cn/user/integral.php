<?php

return [
    'User_id'        => '用户 ID',
    'Beforeintegral' => '累计积分之前的分值',
    'Incintegral'    => '变动分值',
    'Afterintegral'  => '累计积分之后的分值',
    'Sourcetype'     => '分值来源类型',
    'Source_id'      => '来源 ID',
    'Changetype'     => '分值变动类型',
    'Changetype 1'   => '增加',
    'Changetype 2'   => '减少',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间'
];
