<?php

return [
    'User_id'         => '用户 ID',
    'Name'            => '收货人姓名',
    'Mobile'          => '收货人联系方式',
    'Location'        => '收货地址',
    'Defaultswitch'   => '是否默认',
    'Defaultswitch 0' => '不是默认',
    'Defaultswitch 1' => '默认',
    'Createtime'      => '创建时间',
    'Updatetime'      => '更新时间',
    'Deletetime'      => '删除时间'
];
