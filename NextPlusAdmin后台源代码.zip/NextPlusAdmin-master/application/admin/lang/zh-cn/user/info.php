<?php

return [
    'User_id'             => '用户 ID',
    'Username'            => '姓名',
    'Nickname'            => '昵称',
    'Mobile'              => '手机号',
    'Gender'              => '性别',
    'Gender man'          => '男人',
    'Gender woman'        => '女人',
    'Hobby_sport'         => '喜欢的运动',
    'Area'                => '地区',
    'Address'             => '居住地址',
    'Id_card_image'       => '身份证',
    'Self_portrait_image' => '自拍照',
    'Status'              => '审核状态',
    'Status 0'            => '等待审核',
    'Status 1'            => '审核通过',
    'Status 2'            => '审核驳回',
    'Admin_id'            => '管理员 ID',
    'Admin_name'          => '管理员名称',
    'Createtime'          => '创建时间',
    'Updatetime'          => '更新时间'
];
