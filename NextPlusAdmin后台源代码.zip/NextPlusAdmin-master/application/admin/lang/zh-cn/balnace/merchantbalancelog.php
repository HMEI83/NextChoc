<?php

return [
    'Merchant_id'         => '商户 ID',
    'Order_id'            => '订单 ID',
    'Before_amount'       => '变更之前的余额',
    'Amount'              => '变更金额',
    'After_amount'        => '变更之后的余额',
    'Type'                => '变更类型',
    'Type 1'              => '增加',
    'Type 2'              => '减少',
    'Sourcetype'          => '金额来源类型',
    'Sourcetype user_pay' => '用户支付',
    'Sourcetype withdraw' => '商铺提现',
    'Createtime'          => '创建时间',
    'Updatetime'          => '更新时间'
];
