<?php

return [
    'Merchant_id'    => '商户 ID',
    'Stripe_account' => '商户 Stripe Connect',
    'Admin_id'       => '管理员 ID',
    'Amount'         => '提现金额',
    'Status'         => '是否提现成功',
    'Status 0'       => '失败',
    'Status 1'       => '成功',
    'Reason'         => '失败原因',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间'
];
