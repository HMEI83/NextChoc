<?php

return [
    'Title'      => '推送标题',
    'Content'    => '推送内容',
    'Data'       => 'Data(非必填)',
    'Type'       => 'Data类型',
    'Type 1'     => '无点击事件',
    'Type 2'     => '外链',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    "Please enter a valid JSON string" => "请输入合法的 JSON 字符串",
    "Successfully pushed to %d users" => "成功推送给 %d 个用户",
    "Please enter a valid URL" => "請輸入一個有效的 URL",
];
