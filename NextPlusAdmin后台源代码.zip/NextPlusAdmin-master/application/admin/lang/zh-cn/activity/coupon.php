<?php

return [
    'Code'            => '折扣码',
    'Is_used'         => '是否已用',
    'Is_used 0'       => '未使用',
    'Is_used 1'       => '已使用',
    'Used_amount'     => '使用金额(使用门槛)',
    'Discount_amount' => '抵扣金额',
    'Expiretime'      => '过期时间',
    'Createtime'      => '创建时间',
    'Updatetime'      => '更新时间'
];
