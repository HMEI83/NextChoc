<?php

return [
    'Coverimage' => '封面图',
    'Content'    => '内容',
    'category_type'    => '首页分类类型',
    'Type'       => 'Banner类型',
    'Type 1'     => '无点击事件',
    'Type 2'     => '外链',
    'Type 3'     => '商铺',
    'Sort'       => '排序',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    "Please enter a valid URL" => "請輸入一個有效的 URL",
    "Please enter a valid merchant id"  => "請輸入一個有效的商鋪 ID"
];
