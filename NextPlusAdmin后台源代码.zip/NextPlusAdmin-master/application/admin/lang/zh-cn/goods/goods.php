<?php

return [
    'Admin_id'              => '商户 ID',
    'merchant_name'              => '商户名称',

    'Goods_category_one_id' => '商户类别 ID',
    'Goods_category_one_name' => '商户类别',

    'Goods_category_two_id' => '盲盒类别 ID',
    'Goods_category_two_name' => '盲盒类别',

    'Goodsname'             => '盲盒名称',
    'Coverimage'            => '盲盒封面图',
    'Shelfswitch'           => '上架状态',
    'Shelfswitch 0'         => '下架',
    'Shelfswitch 1'         => '上架',
    'Bagginghours'          => '取袋时间',
    'Count'                 => '数量',
    'Price'                 => '价格',
    'Discountprice'         => '折扣价',
    'Ordercount'            => '购买次数',
    'Allergyinfo'           => '过敏信息',
    'Description'           => '盲盒描述',
    'Sort'                  => '排序',
    'Createtime'            => '创建时间',
    'Updatetime'            => '更新时间',
    'Deletetime'            => '删除时间',
    "Opening hours"         => "取袋起始时间",
    "Closing hours"         => "取袋结束时间",
    "Duplicate blind box"   => "複製盲盒",
];
