<?php

return [
    'Goods_category_id'   => '商户分类 ID',
    'Merchant category name' => '商户分类名称',
    'goods_category_name'        => '分类名称',
    'Coverimage'        => '封面图',
    'Sort'              => '排序',
    'Status'            => '状态',
    'Status 0'          => '隐藏',
    'Status 1'          => '正常',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间'
];
