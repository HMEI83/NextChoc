<?php

return [
    'Goods category id'   => '商户分类 ID',
    'Merchant category name' => '商户分类名称',
    'Goods category name'        => '盲盒分类名称',
    'Coverimage'        => '封面图',
    'Sort'              => '排序',
    'Status'            => '状态',
    'Status 0'          => '隐藏',
    'Status 1'          => '正常',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间'
];
