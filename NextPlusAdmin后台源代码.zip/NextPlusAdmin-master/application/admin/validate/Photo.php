<?php

namespace app\admin\validate;

use think\Validate;

/**
 * Class Photo
 *
 * @package app\admin\validate
 */
class Photo extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'photoname' => 'require',
    ];

    /**
     * 字段描述
     */
    protected $field = [
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [],
        'edit' => ['photoname'],
    ];

    /**
     * Photo constructor.
     *
     * @param array $rules
     * @param array $message
     * @param array $field
     */
    public function __construct(array $rules = [], $message = [], $field = [])
    {
        $this->field = [
            'photoname' => __('Photoname'),
        ];
        parent::__construct($rules, $message, $field);
    }

}