<?php

namespace app\admin\model\goods;

use app\admin\model\Admin;
use think\Model;
use traits\model\SoftDelete;

class Goods extends Model
{

    use SoftDelete;

    // 表名
    protected $name = 'goods';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = 'deletetime';

    // 追加属性
    protected $append = [

    ];

    public function getShelfswitchList()
    {
        return ['0' => __('Shelfswitch 0'), '1' => __('Shelfswitch 1')];
    }

    public function admin()
    {
        return $this->belongsTo(Admin::class, "admin_id", "id");
    }

    public function goodsCategoryOne()
    {
        return $this->belongsTo(Goodscategory::class, "goods_category_one_id", "id");
    }

    public function goodsCategoryTwo()
    {
        return $this->belongsTo(Goodscategory::class, "goods_category_two_id", "id");
    }
}
