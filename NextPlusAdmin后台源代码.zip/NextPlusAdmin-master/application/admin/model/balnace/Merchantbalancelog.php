<?php

namespace app\admin\model\balnace;

use think\Model;


class Merchantbalancelog extends Model
{

    

    

    // 表名
    protected $name = 'merchant_balance_log';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'type_text',
        'sourcetype_text'
    ];
    

    
    public function getTypeList()
    {
        return ['1' => __('Type 1'), '2' => __('Type 2')];
    }

    public function getSourcetypeList()
    {
        return ['user_pay' => __('Sourcetype user_pay'), 'withdraw' => __('Sourcetype withdraw')];
    }


    public function getTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['type']) ? $data['type'] : '');
        $list = $this->getTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getSourcetypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['sourcetype']) ? $data['sourcetype'] : '');
        $list = $this->getSourcetypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
