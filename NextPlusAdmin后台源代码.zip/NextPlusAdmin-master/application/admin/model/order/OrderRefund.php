<?php

namespace app\admin\model\order;

use think\Model;

/**
 * 退款记录模型
 *
 * Class OrderRefund
 *
 * @package app\common\model
 */
class OrderRefund extends Model
{
    // 表名
    protected $name = 'order_refund';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'status_text',
        'audittime_text',
        'refundstatus_text',
        'refundtime_text'
    ];

    public function getStatusList()
    {
        return ['0' => __('Status 0'), '1' => __('Status 1'), '2' => __('Status 2')];
    }

    public function getRefundstatusList()
    {
        return ['0' => __('Refundstatus 0'), '1' => __('Refundstatus 1'), '2' => __('Refundstatus 2'), '3' => __('Refundstatus 3')];
    }

    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getAudittimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['audittime']) ? $data['audittime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    public function getRefundstatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['refundstatus']) ? $data['refundstatus'] : '');
        $list = $this->getRefundstatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getRefundtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['refundtime']) ? $data['refundtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setAudittimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setRefundtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }
}
