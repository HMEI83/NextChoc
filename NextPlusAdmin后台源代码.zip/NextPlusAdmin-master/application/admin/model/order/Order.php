<?php

namespace app\admin\model\order;

use think\Model;


class Order extends Model
{

    // 表名
    protected $name = 'order';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'payment_status_text',
        'cancel_type_text',
        'payment_time_text',
        'check_time_text',
        'pack_time_text',
        'cancel_time_text',
        'status_text',
        'is_evaluate_text'
    ];
    

    
    public function getPaymentStatusList()
    {
        return ['0' => __('Payment_status 0'), '1' => __('Payment_status 1'), '2' => __('Payment_status 2')];
    }

    public function getCancelTypeList()
    {
        return ['user_cancel' => __('Cancel_type user_cancel'), 'platform_cancel' => __('Cancel_type platform_cancel'), "apply_refund" => __('Cancel_type apply_refund')];
    }

    public function getStatusList()
    {
        return ['1' => __('Status 1'), '2' => __('Status 2'), '4' => __('Status 4'), '3' => __('Status 3')];
    }

    public function getIsAutoCheckList()
    {
        return ['0' => __('Is_auto_check 0'), '1' => __('Is_auto_check 1')];
    }

    public function getIsEvaluateList()
    {
        return ['0' => __('Is_evaluate 0'), '1' => __('Is_evaluate 1')];
    }

    public function getIsRefundList()
    {
        return ['0' => __('Is_refund 0'), '1' => __('Is_refund 1')];
    }

    public function getPaymentStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['payment_status']) ? $data['payment_status'] : '');
        $list = $this->getPaymentStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getCancelTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['cancel_type']) ? $data['cancel_type'] : '');
        $list = $this->getCancelTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPaymentTimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['payment_time']) ? $data['payment_time'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getCheckTimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['check_time']) ? $data['check_time'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getPackTimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['pack_time']) ? $data['pack_time'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getCancelTimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['cancel_time']) ? $data['cancel_time'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getIsEvaluateTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_evaluate']) ? $data['is_evaluate'] : '');
        $list = $this->getIsEvaluateList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getIsAutoCheckTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_auto_check']) ? $data['is_auto_check'] : '');
        $list = $this->getIsAutoCheckList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    protected function setPaymentTimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setCheckTimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setPackTimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setCancelTimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }


}
