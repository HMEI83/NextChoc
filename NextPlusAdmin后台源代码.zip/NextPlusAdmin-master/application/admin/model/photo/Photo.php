<?php


namespace app\admin\model\photo;

use think\Model;
use traits\model\SoftDelete;

/**
 * 相册模型
 *
 * Class Photo
 *
 * @package app\admin\model\photo
 */
class Photo extends Model
{
    use SoftDelete;

    protected $name = 'photo';

    protected $autoWriteTimestamp = "int";

    protected $createTime = "createtime";

    protected $updateTime = "updatetime";

    protected $deleteTime = 'deletetime';

    // 追加属性
    protected $append = [
        "create_time_format",
        "update_time_format",
    ];

    public function getCreateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['createtime'] ?? null);

        return datetime($value);
    }

    public function getUpdateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['updatetime'] ?? null);

        return datetime($value);
    }
}