<?php

namespace app\admin\model\photo;

use think\Model;
use traits\model\SoftDelete;

/**
 * 相册模型
 *
 * Class Album
 *
 * @package app\admin\model\photo
 */
class Album extends Model
{
    use SoftDelete;

    // 表名
    protected $name = 'album';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = 'deletetime';

    // 追加属性
    protected $append = [

    ];

}
