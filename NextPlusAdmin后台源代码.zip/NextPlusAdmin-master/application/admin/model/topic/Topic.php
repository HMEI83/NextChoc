<?php

namespace app\admin\model\topic;

use app\admin\model\topic\Comment as TopicCommentModel;
use think\Model;
use traits\model\SoftDelete;

/**
 * Class Topic
 *
 * @package app\admin\model\topic
 */
class Topic extends Model
{

    use SoftDelete;

    // 表名
    protected $name = 'topic';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = 'deletetime';

    // 追加属性
    protected $append = [
        "create_time_format",
        "update_time_format",

    ];

    public function getCreateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['createtime'] ?? null);

        return datetime($value);
    }

    public function getUpdateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['updatetime'] ?? null);

        return datetime($value);
    }

    /**
     * @return \think\model\relation\HasMany
     */
    public function hasComment()
    {
        // 首次获取 100 条，加载完之后，再次获取
        return $this->hasMany(
            TopicCommentModel::class,
            "topic_id",
            "id"
        )
            ->limit(100);
    }
}
