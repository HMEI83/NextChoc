<?php

namespace app\admin\model\merchant;

use think\Model;
use traits\model\SoftDelete;

class UserFavorite extends Model
{
    use SoftDelete;

    // 表名
    protected $name = 'user_favorite_merchant';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = 'deletetime';

    // 追加属性
    protected $append = [

    ];

    public function Goods()
    {
        return $this->hasOne("Merchant", "id", "merchant_id");
    }
}