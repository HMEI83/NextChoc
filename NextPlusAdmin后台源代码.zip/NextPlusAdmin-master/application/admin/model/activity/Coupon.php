<?php

namespace app\admin\model\activity;

use think\Model;


class Coupon extends Model
{

    

    

    // 表名
    protected $name = 'coupon';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'is_used_text',
        'expiretime_text'
    ];
    

    
    public function getIsUsedList()
    {
        return ['0' => __('Is_used 0'), '1' => __('Is_used 1')];
    }


    public function getIsUsedTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_used']) ? $data['is_used'] : '');
        $list = $this->getIsUsedList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getExpiretimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['expiretime']) ? $data['expiretime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setExpiretimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }


}
