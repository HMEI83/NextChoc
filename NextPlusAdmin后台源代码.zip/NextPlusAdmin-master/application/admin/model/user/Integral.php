<?php

namespace app\admin\model\user;

use think\Model;

/**
 * Class Integral
 *
 * @package app\admin\model\user
 */
class Integral extends Model
{

    // 表名
    protected $name = 'user_integral_log';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'changetype_text'
    ];

    public function getChangetypeList()
    {
        return ['1' => __('Changetype 1'), '2' => __('Changetype 2')];
    }

    public function getChangetypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['changetype']) ? $data['changetype'] : '');
        $list = $this->getChangetypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }
}
