<?php

namespace app\admin\model\user;

use think\Model;
use traits\model\SoftDelete;

/**
 * 卡包模型
 *
 * Class Card
 *
 * @package app\admin\model\user
 */
class Card extends Model
{
    use SoftDelete;

    // 表名
    protected $name = 'credit_card';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'integer';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = 'deletetime';

    // 追加属性
    protected $append = [
        'status_text',
        "create_time_format",
        "update_time_format",
    ];

    public function getCreateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['createtime'] ?? null);

        return datetime($value);
    }

    public function getUpdateTimeFormatAttr($value, $data)
    {
        $value = $value ?: ($data['updatetime'] ?? null);

        return datetime($value);
    }
    
    public function getStatusList()
    {
        return ['0' => __('Status 0'), '1' => __('Status 1')];
    }

    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }
}
