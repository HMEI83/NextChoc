<?php 
 return array (
  'table_name' => '',
  'self_path' => '',
  'update_data' => '',
);