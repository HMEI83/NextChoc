<?php
/**
 * 菜单配置文件
 */

return array (
);