<?php
namespace addons\convert\library;

/**
 * 汉字转换，繁体转简体或简体转繁体
 *
 * 如需还有未收录的字库，请打开addons\convert\library\Dict.php文件添加
 *
 */
class Convert
{
    private static $dict;//繁体->简体数组
    private static $reverseDict;//简体->繁体数组

    /**
     * 执行文字转换
     *
     * @param string $str 需要转换的字符串
     * @param boolean $isSc2tc 是否是简体转繁体
     * @return string 转换后的字符串
     */
    public static function convert($str, $isSc2tc = true)
    {
        //检查输入参数
        if (empty($str)) {
            return $str;
        }

        //初始化字库
        self::initConvert($isSc2tc);

        //开始处理
        $strArr = preg_split('/(?<!^)(?!$)/u', $str);//将字符串转成数组
        array_walk($strArr, function (&$value) use ($isSc2tc) {//循环处理字符
            if ($isSc2tc) {//如果是简体转繁体
                $value = isset(self::$reverseDict[$value]) ? self::$reverseDict[$value] : $value;
            } else {
                $value = isset(self::$dict[$value]) ? self::$dict[$value] : $value;
            }
        });
        return implode('', $strArr);//将数组合并成字符串
    }

    /**
     * 递归数组执行文字转换
     *
     * @param array $arr 需要转换的数组
     * @param boolean $isSc2tc 是否是简体转繁体
     * @return array 转换后的数组
     */
    public static function arrConvert($arr,$isSc2tc = true){
        //检查输入参数
        if (empty($arr)) {
            return $arr;
        }

        //初始化字库
        self::initConvert($isSc2tc);
        if(is_array($arr)){
            foreach ($arr as $key => $value){
                if(is_array($value)){
                    $arr[$key] = self::arrConvert($value,$isSc2tc);
                }else{
                    $arr[$key] = self::convert($value,$isSc2tc);
                }
            }
        }
        return $arr;
    }

    /**
     * 初始化中文转换
     *
     * @param boolean $isSC2tc 是否是简体转繁体
     *
     */
    public static function initConvert($isSC2tc = true)
    {
        if ($isSC2tc) {
            if (empty(self::$reverseDict)) {
                self::$reverseDict = require('Dict.php');
                self::$reverseDict = array_flip(self::$reverseDict);//繁简体数组翻转
            }
        } else {
            if (empty(self::$dict)) {
                self::$dict = require('Dict.php');
            }
        }
    }

}

