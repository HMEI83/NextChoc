<?php

namespace addons\convert\controller;

use addons\convert\library\Convert;
use think\addons\Controller;

class Index extends Controller
{

    public function index()
    {
        return $this->view->fetch();
    }


    public function api(){
        $text = $this->request->post('text');
        $event = $this->request->post('event');
        if(!$text){
            $this->error('请输入转换文本');
        }
        $isSc2tc = true;
        if($event == 'tc2sc'){
            $isSc2tc = false;
        }
        $afterText = \addons\convert\library\Convert::convert($text,$isSc2tc);
        $this->success('操作成功','',['afterText' => $afterText]);
    }
}
