
# NextPlusAdmin

## 环境变量
* DEV (development)：开发环境
* TEST（test）：测试环境
* PROD（production）：生产环境

## env 配置

```bash
$ cp example.env .env
```