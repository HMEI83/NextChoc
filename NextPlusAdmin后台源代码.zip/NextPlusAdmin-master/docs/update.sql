/* 6:12:24 PM localhost fastadmin */ ALTER TABLE `fa_attachment` ADD `realfilename` VARCHAR(100)  NULL  DEFAULT ''  COMMENT '真实文件名称'  AFTER `filename`;

CREATE TABLE `fa_photo` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户 ID',
    `album_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '相册 ID',
    `photoname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相片名称',
    `photourl` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相片地址',
    `photopath` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相片本地路径',
    `date` date NOT NULL COMMENT '上传日期',
    `size` int(11) NOT NULL DEFAULT '0' COMMENT '相片大小',
    `weight` mediumint(6) NOT NULL COMMENT '宽',
    `height` mediumint(6) NOT NULL COMMENT '高',
    `suffix` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件后缀类型',
    `createtime` bigint(16) NOT NULL COMMENT '创建时间',
    `updatetime` bigint(16) NOT NULL COMMENT '更新时间',
    `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='相片表';

CREATE TABLE `fa_fail_webhook` (
   `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
   `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户 ID',
   `paytime` int(11) NOT NULL COMMENT '支付时间',
   `request` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '支付回调参数',
   `remark` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
   `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
   `updatetime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付回调失败记录';

CREATE TABLE `fa_request_record` (
     `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
     `url` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '请求地址',
     `ip` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'IP',
     `path` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '路径',
     `headers` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '请求头',
     `query` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '请求参数',
     `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户 ID',
     `longitude` decimal(10,7) NOT NULL DEFAULT '0.0000000' COMMENT '经度',
     `latitude` decimal(10,7) NOT NULL DEFAULT '0.0000000' COMMENT '维度',
     `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
     `updatetime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
     PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='请求记录表';

/* 2:03:48 PM localhost fastadmin */ ALTER TABLE `fa_user` DROP `bio`;

/* 2:04:44 PM localhost fastadmin */ ALTER TABLE `fa_user` DROP `birthday`;

/* 2:05:02 PM localhost fastadmin */ ALTER TABLE `fa_user` DROP `gender`;

/* 2:03:04 PM localhost fastadmin */ ALTER TABLE `fa_user` ADD `deletetime` BIGINT(16)  NULL  DEFAULT NULL  COMMENT '删除时间'  AFTER `updatetime`;

/* 2:33:46 PM localhost fastadmin */ ALTER TABLE `fa_user` ADD `facebook` VARCHAR(32)  NOT NULL  DEFAULT ''  COMMENT 'Facebook 账号'  AFTER `verification`;

/* 2:35:20 PM localhost fastadmin */ ALTER TABLE `fa_user` ADD `instagram` VARCHAR(32)  NOT NULL  DEFAULT ''  COMMENT 'Instagram 账号'  AFTER `facebook`;

/* 9:53:26 AM localhost fastadmin */ ALTER TABLE `fa_user` ADD `device` VARCHAR(8)  NOT NULL  DEFAULT ''  COMMENT '设备'  AFTER `token`;

/* 12:10:15 PM localhost fastadmin */ ALTER TABLE `fa_user` ADD `exponentpushtoken` VARCHAR(50)  NOT NULL  DEFAULT ''  COMMENT 'Expo Push Token'  AFTER `token`;

/* 9:55:35 AM localhost fastadmin */ ALTER TABLE `fa_user` ADD `member_id` CHAR(8)  NOT NULL  DEFAULT ''  COMMENT '会员 ID'  AFTER `group_id`;

CREATE TABLE `fa_credit_card` (
      `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
      `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户 ID',
      `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '信用卡号',
      `date` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '信用卡有效期',
      `cvc` mediumint(6) NOT NULL DEFAULT '0' COMMENT '信用卡安全码',
      `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '姓名',
      `brand` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '品牌名',
      `country` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '国家',
      `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=正常',
      `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
      `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
      `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
      PRIMARY KEY (`id`),
      KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户卡包';

/* 2:23:30 PM localhost fastadmin */ ALTER TABLE `fa_credit_card` ADD `defaultswitch` TINYINT(1)  NOT NULL  DEFAULT '0'  COMMENT '是否是默认信用卡'  AFTER `country`;

CREATE TABLE `fa_album` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户 ID',
    `albumname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相册名称',
    `albumcover` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相册封面',
    `createtime` bigint(16) NOT NULL COMMENT '创建时间',
    `updatetime` bigint(16) NOT NULL COMMENT '更新时间',
    `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='相册表';

CREATE TABLE `fa_product` (
      `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '相框 ID',
      `productname` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相框名称',
      `coverimage` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相框封面图',
      `sliderimages` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '相框轮播图',
      `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
      `totalcount` mediumint(6) NOT NULL DEFAULT '0' COMMENT '总数量',
      `remaincount` mediumint(6) NOT NULL DEFAULT '0' COMMENT '剩余数量',
      `detailinfo` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '详情描述',
      `productswitch` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否上架:0=未上架,1=上架',
      `sort` smallint(3) NOT NULL DEFAULT '0' COMMENT '排序',
      `createtime` bigint(16) NOT NULL DEFAULT '0' COMMENT '创建时间',
      `updatetime` bigint(16) NOT NULL DEFAULT '0' COMMENT '更新时间',
      `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
      PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品表（相框表）';

CREATE TABLE `fa_order` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户 ID',
    `cart_ids` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '购物车 ID',
    `orderno` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单号',
    `expressno` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '物流单号',
    `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单金额',
    `paymentamount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际付款金额',
    `couponcode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '折扣码',
    `couponprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠金额',
    `paymenttype` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '支付方式',
    `paymentstatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态:0=未支付,1=支付成功',
    `paymenttime` int(11) DEFAULT NULL COMMENT '支付时间',
    `receipttime` int(11) DEFAULT NULL COMMENT '用户收货时间',
    `deliverytime` int(11) DEFAULT NULL COMMENT '平台发货时间',
    `settletime` int(11) DEFAULT NULL COMMENT '订单成交时间',
    `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单状态:0=等待用户付款,1=等待平台发货,2=等待用户收货,3=用户确认收货,4=用户申请退款',
    `refundswitch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否发起退款:0=未发起退款,1=已发起退款',
    `remark` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
    `createtime` bigint(16) NOT NULL COMMENT '创建时间',
    `updatetime` bigint(16) NOT NULL COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';

CREATE TABLE `fa_order_refund` (
       `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
       `user_id` int(11) NOT NULL COMMENT '用户 ID',
       `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单 ID',
       `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '审核状态:0=等待审核,1=审核通过,2=审核驳回',
       `audit_id` int(11) NOT NULL DEFAULT '0' COMMENT '审核人 ID',
       `audittime` int(11) DEFAULT NULL COMMENT '审核时间',
       `refundstatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '退款状态:0=无需退款,1=等待退款,2=已退款,3=退款失败',
       `refundtime` int(11) DEFAULT NULL COMMENT '退款时间',
       `remark` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
       `createtime` bigint(16) NOT NULL COMMENT '创建时间',
       `updatetime` bigint(16) NOT NULL COMMENT '更新时间',
       PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='退款记录表';

CREATE TABLE `fa_order_product` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单 ID',
    `user_id` int(11) NOT NULL COMMENT '用户 ID',
    `product_id` int(11) NOT NULL DEFAULT '0' COMMENT '相框 ID',
    `photo_ids` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '相片 ID',
    `productname` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相框名称',
    `coverimage` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相框封面图',
    `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品价格',
    `createtime` bigint(16) NOT NULL DEFAULT '0' COMMENT '创建时间',
    `updatetime` bigint(16) NOT NULL DEFAULT '0' COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单商品表';

CREATE TABLE `fa_shopping_cart` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户 ID',
    `product_id` int(11) NOT NULL DEFAULT '0' COMMENT '相框 ID',
    `photo_ids` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '相片 ID',
    `productname` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相框名称',
    `coverimage` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '相框封面图',
    `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
    `createtime` bigint(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
    `updatetime` bigint(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
    `deletetime` bigint(11) DEFAULT NULL COMMENT '删除时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='购物车表';

/* 3:18:09 PM localhost fastadmin */ ALTER TABLE `fa_photo` ADD `thumbphotourl` VARCHAR(256)  NOT NULL  DEFAULT ''  COMMENT '缩略图地址'  AFTER `photourl`;

CREATE TABLE `fa_topic` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户 ID',
    `username` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
    `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
    `content` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '内容',
    `commentcount` mediumint(6) NOT NULL COMMENT '评论数量',
    `hiddenswitch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否隐藏',
    `viewcount` int(11) NOT NULL DEFAULT '0' COMMENT '浏览数量',
    `heat` int(11) NOT NULL DEFAULT '0' COMMENT '热度',
    `createtime` bigint(16) NOT NULL COMMENT '创建时间',
    `updatetime` bigint(16) NOT NULL COMMENT '更新时间',
    `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='话题表';

CREATE TABLE `fa_topic_comment` (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `topic_id` int(11) NOT NULL DEFAULT '0' COMMENT '话题 ID',
    `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户 ID',
    `content` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '评论内容',
    `likecount` int(11) NOT NULL DEFAULT '0' COMMENT '点赞数量',
    `createtime` bigint(16) NOT NULL COMMENT '创建时间',
    `updatetime` bigint(16) NOT NULL COMMENT '更新时间',
    `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='话题评论表';